# BookBloom AI

A workspace for residential cleaning businesses: leads, rate-card estimates, message drafts, and follow-up reminders. Tagline: More bookings. Less busywork.

## Architecture

The requested shape was Supabase Auth plus Supabase Postgres. This host does not provision Supabase.

- Email and password, plus Google and X, through Better Auth at `/api/auth/*`.
- Postgres for business records. Deployed apps receive a hosted database. The preview uses embedded Postgres when `DATABASE_URL` is unset.
- Tenant isolation is the server-side `user_id` check. Row Level Security policies exist, but the app connection bypasses them.

Do not add a second auth vendor.

## Schema

`migrations/0001_auth.sql` is the auth schema. Do not edit it.

`migrations/0002_bookbloom.sql` creates `businesses`, `leads`, `quotes`, `follow_ups`, and `ai_usage`.

`migrations/0003_account.sql` creates personal profiles, notification preferences, deletion requests, and `admin_role_assignments`. That role table has no client insert policy and ships with no administrator.

Sample rows are flagged `is_sample`.

## Environment

Do not commit secrets. The host injects these on publish. Nothing in the browser should see the non-public ones. Do not create a `.env` file.

```
DATABASE_URL=          # Postgres connection string. Injected on deploy. Unset in this preview.
XAI_API_KEY=           # Optional, server-only. When absent, drafts are labeled demo templates.
RESEND_API_KEY=        # Server-only. Never use a VITE_ name.
MAIL_FROM=             # Server-only. BookBloom AI <noreply@thebookbloom.com>
BETTER_AUTH_URL=       # Server-only. https://thebookbloom.com
```

There is no Stripe secret. Billing is not connected. Visiting `/billing/success` does not grant a subscription.

## Accounts

- Creating an account does not start a subscription.
- Verification uses `/api/auth/verify-email`, then `/email-verified`. Tokens expire in one hour and are single-use. The address is marked verified only after the token is accepted. Verification does not assign Super Admin.
- Password reset uses the same Resend sender. A reset link expires in one hour and works once.
- Personal settings are under `/account`. They are separate from business rates.
- Authenticator MFA is not enabled. `/admin` stays locked.

## Deployment status (checked 2026-11-04)

The application is built for Vercel. This workspace is the Grok preview, not a live Vercel project: `VERCEL`, `VERCEL_URL`, and `DATABASE_URL` are unset, and there is no linked project id. Publishing is done from the app host. This session cannot attach `thebookbloom.com` or create the hosted database.

The preview database is embedded Postgres (PGLite) in the dev-server process memory. It is not a file and not Neon. Restarting the preview wipes every account. `bookbloomservices@yahoo.com` was present in that memory earlier and is not there now. No other database was found, so that account cannot be recovered. Do not create a replacement in the preview. Register once on the published site after `DATABASE_URL` is injected.

`thebookbloom.com` uses nameservers `ns1.hosting.businessidentity.llc` and `ns2.hosting.businessidentity.llc`. Authoritative DNS currently has no A or AAAA record for the apex or `www`, so the site does not open. Leave these mail records in place:

- `resend._domainkey.thebookbloom.com` TXT (Resend DKIM)
- `send.thebookbloom.com` CNAME `send.forge.rmta.net`

Do not point the website at `send.thebookbloom.com`. After the domain is added to the published Vercel project, copy the records that project displays. Vercel documents that each project has its own CNAME target. Do not reuse another project's records, and do not guess an IP address.

The preview secret file is not deployed. On publish, set `RESEND_API_KEY`, `MAIL_FROM`, `BETTER_AUTH_URL`, and the injected `DATABASE_URL` in the host environment.

Publish from the app host. The build applies `migrations/*.sql` to the hosted database. After publish, create an account on `https://thebookbloom.com`, confirm a lead and an estimate save, and confirm `/billing/success` does not change the account.

Super Admin stays unassigned until that production user is verified, its user id is written on the server into `admin_role_assignments`, and MFA is actually available. Email matching is not enough. MFA is not available yet, so `/admin` remains locked.
