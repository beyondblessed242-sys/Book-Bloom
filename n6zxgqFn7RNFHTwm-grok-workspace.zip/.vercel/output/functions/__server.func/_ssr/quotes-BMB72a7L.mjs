import { t as QuotesPanel } from "./quotes-panel-D8RoUOKk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quotes-BMB72a7L.js
var SplitComponent = QuotesPanel;
//#endregion
export { SplitComponent as component };
