import { Q as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Notice } from "./field-DYRyux0t.mjs";
import { t as SiteHeader } from "./site-header-CWiOJRzR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/billing.success-Hnac_NK7.js
var import_jsx_runtime = require_jsx_runtime();
function BillingSuccess() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid max-w-xl gap-4 px-4 py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Nothing was purchased"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
				tone: "warn",
				children: "BookBloom does not treat this address as a successful payment. No subscription was started, and no paid access was granted. Stripe is not connected."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "btn btn-secondary",
					children: "Back home"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/app/billing",
					className: "btn btn-primary",
					children: "View the plan"
				})]
			})
		]
	})] });
}
//#endregion
export { BillingSuccess as component };
