import { Q as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/logo-CQuIplpX.js
var import_jsx_runtime = require_jsx_runtime();
function Logo({ to = "/" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "inline-flex items-center gap-2.5 no-underline",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 32 32",
			className: "size-8",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "10",
				className: "fill-accent"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 6.5c1.8 2.6 2.2 4.6.2 7.2-2.2-2.4-2.6-4.4-.2-7.2zm0 11.6c1.8 2.6 2.2 4.6.2 7.2-2.2-2.4-2.6-4.4-.2-7.2zM6.5 16c2.6-1.8 4.6-2.2 7.2-.2-2.4 2.2-4.4 2.6-7.2.2zm11.8 0c2.6-1.8 4.6-2.2 7.2-.2-2.4 2.2-4.4 2.6-7.2.2z",
				className: "fill-bg"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "font-display text-xl tracking-tight text-ink",
			children: ["BookBloom ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-accent",
				children: "AI"
			})]
		})]
	});
}
//#endregion
export { Logo as t };
