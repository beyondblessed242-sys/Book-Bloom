import { r as createServerFn } from "./ssr.mjs";
import { r as getSql } from "./db-B1wBuzWH.mjs";
import { t as authMiddleware } from "./middleware-3dIwojxy.mjs";
import { f as explainQuote, h as frequencyById, l as buildSample, m as formatMoney, n as DEFAULT_SERVICES, t as DEFAULT_EXTRAS, u as calculateQuote } from "./sample-CJS8dzaP.mjs";
import { a as followDoneSchema, c as idSchema, d as quoteSchema, f as quoteStatusSchema, i as firstName, l as leadSchema, m as stripMoney, n as clip, o as followUpSchema, p as renderDemoDraft, r as draftSchema, s as hasUnexpectedPrice, t as businessSchema, u as parseInput } from "./messages-DV8Zo0Sx.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bookbloom-CmJ_-CzT.js
var DAILY_DRAFT_LIMIT = 40;
function asObject(value) {
	if (typeof value === "string") try {
		return JSON.parse(value);
	} catch {
		return null;
	}
	return value;
}
function asServices(value) {
	const parsed = asObject(value);
	if (!Array.isArray(parsed) || parsed.length === 0) return DEFAULT_SERVICES.map((item) => ({ ...item }));
	return parsed;
}
function asExtras(value) {
	const parsed = asObject(value);
	if (!Array.isArray(parsed)) return [];
	return parsed;
}
function asBreakdown(value) {
	return asObject(value);
}
function mapBusiness(row) {
	return {
		id: row.id,
		companyName: row.companyName,
		ownerName: row.ownerName,
		email: row.email,
		phone: row.phone,
		serviceArea: row.serviceArea,
		hours: row.hours,
		tone: row.tone,
		services: asServices(row.services),
		extras: asExtras(row.extras),
		sampleLoaded: row.sampleLoaded
	};
}
function mapLead(row) {
	return { ...row };
}
function mapQuote(row) {
	return {
		...row,
		breakdown: asBreakdown(row.breakdown)
	};
}
function mapFollow(row) {
	return { ...row };
}
async function ensureBusiness(sql, userId) {
	await sql`
    insert into businesses (
      id, user_id, company_name, owner_name, email, phone, service_area, hours, tone, services, extras
    ) values (
      ${crypto.randomUUID()},
      ${userId},
      '',
      '',
      '',
      '',
      '',
      'Mon–Fri 8:00–17:00',
      'warm',
      ${JSON.stringify(DEFAULT_SERVICES)}::jsonb,
      ${JSON.stringify(DEFAULT_EXTRAS)}::jsonb
    )
    on conflict (user_id) do nothing
  `;
	const row = (await sql`
    select
      id,
      company_name as "companyName",
      owner_name as "ownerName",
      email,
      phone,
      service_area as "serviceArea",
      hours,
      tone,
      services,
      extras,
      sample_loaded as "sampleLoaded"
    from businesses
    where user_id = ${userId}
  `)[0];
	if (!row) throw new Error("Could not open your workspace.");
	return mapBusiness(row);
}
async function readWorkspace(sql, userId) {
	return {
		business: await ensureBusiness(sql, userId),
		leads: (await sql`
      select
        id, name, email, phone,
        service_id as "serviceId",
        service_label as "serviceLabel",
        rooms, sqft, frequency, notes, status,
        last_contact as "lastContact",
        is_sample as "isSample",
        updated_at::text as "updatedAt"
      from leads
      where user_id = ${userId}
      order by updated_at desc
      limit 300
    `).map(mapLead),
		quotes: (await sql`
      select
        q.id,
        q.lead_id as "leadId",
        l.name as "leadName",
        q.breakdown,
        q.total_cents as "totalCents",
        q.explanation,
        q.status,
        q.is_sample as "isSample",
        q.updated_at::text as "updatedAt"
      from quotes q
      left join leads l on l.id = q.lead_id and l.user_id = ${userId}
      where q.user_id = ${userId}
      order by q.updated_at desc
      limit 300
    `).map(mapQuote),
		followUps: (await sql`
      select
        f.id,
        f.lead_id as "leadId",
        l.name as "leadName",
        f.title,
        f.due_date as "dueDate",
        f.notes,
        f.done,
        f.is_sample as "isSample"
      from follow_ups f
      left join leads l on l.id = f.lead_id and l.user_id = ${userId}
      where f.user_id = ${userId}
      order by f.done asc, f.due_date asc
      limit 300
    `).map(mapFollow),
		aiLive: Boolean(process.env.XAI_API_KEY)
	};
}
function uniqueIds(ids, label) {
	if (new Set(ids).size !== ids.length) throw new Error(`Each ${label} needs its own id.`);
}
async function ownedLead(sql, userId, leadId) {
	if (!leadId) return null;
	const rows = await sql`
    select id from leads where id = ${leadId} and user_id = ${userId}
  `;
	if (!rows[0]) throw new Error("That lead is not in your workspace.");
	return rows[0].id;
}
var getWorkspace_createServerFn_handler = createServerRpc({
	id: "c82b597bbd9cc90d6bf96a0a7d8c4d14056c09c0302a2c4c6a1135093ef60613",
	name: "getWorkspace",
	filename: "src/server/bookbloom.ts"
}, (opts) => getWorkspace.__executeServer(opts));
var getWorkspace = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getWorkspace_createServerFn_handler, async ({ context }) => {
	return readWorkspace(await getSql(), context.userId);
});
var saveBusiness_createServerFn_handler = createServerRpc({
	id: "1a98d9eee6bc99a2419c8cd632bcba146914a6ea03cfc76d41438745c8020a42",
	name: "saveBusiness",
	filename: "src/server/bookbloom.ts"
}, (opts) => saveBusiness.__executeServer(opts));
var saveBusiness = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(businessSchema, data)).handler(saveBusiness_createServerFn_handler, async ({ context, data }) => {
	uniqueIds(data.services.map((item) => item.id), "service");
	uniqueIds(data.extras.map((item) => item.id), "extra");
	const sql = await getSql();
	await ensureBusiness(sql, context.userId);
	await sql`
      update businesses set
        company_name = ${data.companyName},
        owner_name = ${data.ownerName},
        email = ${data.email},
        phone = ${data.phone},
        service_area = ${data.serviceArea},
        hours = ${data.hours},
        tone = ${data.tone},
        services = ${JSON.stringify(data.services)}::jsonb,
        extras = ${JSON.stringify(data.extras)}::jsonb,
        updated_at = now()
      where user_id = ${context.userId}
    `;
	return readWorkspace(sql, context.userId);
});
var upsertLead_createServerFn_handler = createServerRpc({
	id: "3623226e5ae01fc1b59ba9b759beaf7d1618e1052ddd33db9bd71efda6e0f66f",
	name: "upsertLead",
	filename: "src/server/bookbloom.ts"
}, (opts) => upsertLead.__executeServer(opts));
var upsertLead = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(leadSchema, data)).handler(upsertLead_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const service = (await ensureBusiness(sql, context.userId)).services.find((item) => item.id === data.serviceId);
	if (!service) throw new Error("Choose a service from your rate card.");
	const lastContact = data.lastContact ? data.lastContact : null;
	if (data.id) {
		if (!(await sql`
        update leads set
          name = ${data.name},
          email = ${data.email},
          phone = ${data.phone},
          service_id = ${service.id},
          service_label = ${service.label},
          rooms = ${data.rooms},
          sqft = ${data.sqft},
          frequency = ${data.frequency},
          notes = ${data.notes},
          status = ${data.status},
          last_contact = ${lastContact},
          updated_at = now()
        where id = ${data.id} and user_id = ${context.userId}
        returning id
      `)[0]) throw new Error("That lead is not in your workspace.");
	} else await sql`
        insert into leads (
          id, user_id, name, email, phone, service_id, service_label, rooms, sqft,
          frequency, notes, status, last_contact, is_sample
        ) values (
          ${crypto.randomUUID()},
          ${context.userId},
          ${data.name},
          ${data.email},
          ${data.phone},
          ${service.id},
          ${service.label},
          ${data.rooms},
          ${data.sqft},
          ${data.frequency},
          ${data.notes},
          ${data.status},
          ${lastContact},
          false
        )
      `;
	return readWorkspace(sql, context.userId);
});
var deleteLead_createServerFn_handler = createServerRpc({
	id: "162e458f6479eb479b6d0cf26174458a3808874196dfff11497cab5f865ba258",
	name: "deleteLead",
	filename: "src/server/bookbloom.ts"
}, (opts) => deleteLead.__executeServer(opts));
var deleteLead = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(idSchema, data)).handler(deleteLead_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (!(await sql`
      delete from leads where id = ${data.id} and user_id = ${context.userId} returning id
    `)[0]) throw new Error("That lead is not in your workspace.");
	return readWorkspace(sql, context.userId);
});
async function writeQuote(sql, userId, data) {
	const business = await ensureBusiness(sql, userId);
	const leadId = await ownedLead(sql, userId, data.leadId);
	let breakdown;
	try {
		breakdown = calculateQuote({
			services: business.services,
			extrasCatalog: business.extras,
			serviceId: data.serviceId,
			rooms: data.rooms,
			sqft: data.sqft,
			frequency: data.frequency,
			extraIds: data.extraIds,
			adjustmentCents: data.adjustmentCents
		});
	} catch (error) {
		throw new Error(error instanceof Error ? error.message : "Could not calculate that estimate.");
	}
	const explanation = data.explanation.trim() || explainQuote(breakdown);
	const payload = JSON.stringify(breakdown);
	if (data.id) {
		if (!(await sql`
      update quotes set
        lead_id = ${leadId},
        breakdown = ${payload}::jsonb,
        total_cents = ${breakdown.totalCents},
        explanation = ${explanation},
        status = ${data.status},
        updated_at = now()
      where id = ${data.id} and user_id = ${userId}
      returning id
    `)[0]) throw new Error("That estimate is not in your workspace.");
		return;
	}
	await sql`
    insert into quotes (
      id, user_id, lead_id, breakdown, total_cents, explanation, status, is_sample
    ) values (
      ${crypto.randomUUID()},
      ${userId},
      ${leadId},
      ${payload}::jsonb,
      ${breakdown.totalCents},
      ${explanation},
      ${data.status},
      false
    )
  `;
}
var upsertQuote_createServerFn_handler = createServerRpc({
	id: "f0b5a6fcd336d55b830850c6319bb57589846022a86c73136c699a6450ccf9dc",
	name: "upsertQuote",
	filename: "src/server/bookbloom.ts"
}, (opts) => upsertQuote.__executeServer(opts));
var upsertQuote = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(quoteSchema, data)).handler(upsertQuote_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await writeQuote(sql, context.userId, data);
	return readWorkspace(sql, context.userId);
});
var setQuoteStatus_createServerFn_handler = createServerRpc({
	id: "619ae72a601b457eb8168e58189eadf66f55ac98feeba65d0d296cdbb7cb2697",
	name: "setQuoteStatus",
	filename: "src/server/bookbloom.ts"
}, (opts) => setQuoteStatus.__executeServer(opts));
var setQuoteStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(quoteStatusSchema, data)).handler(setQuoteStatus_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (!(await sql`
      update quotes set status = ${data.status}, updated_at = now()
      where id = ${data.id} and user_id = ${context.userId}
      returning id
    `)[0]) throw new Error("That estimate is not in your workspace.");
	return readWorkspace(sql, context.userId);
});
var deleteQuote_createServerFn_handler = createServerRpc({
	id: "d9624f7ae0eafa2caf97250931c539226be1c23606898c75cc9a9985ae606eee",
	name: "deleteQuote",
	filename: "src/server/bookbloom.ts"
}, (opts) => deleteQuote.__executeServer(opts));
var deleteQuote = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(idSchema, data)).handler(deleteQuote_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (!(await sql`
      delete from quotes where id = ${data.id} and user_id = ${context.userId} returning id
    `)[0]) throw new Error("That estimate is not in your workspace.");
	return readWorkspace(sql, context.userId);
});
var upsertFollowUp_createServerFn_handler = createServerRpc({
	id: "0f1657fc913af99d613b5c24df3192d8e0c0cc5ab0e512d898a934629a987202",
	name: "upsertFollowUp",
	filename: "src/server/bookbloom.ts"
}, (opts) => upsertFollowUp.__executeServer(opts));
var upsertFollowUp = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(followUpSchema, data)).handler(upsertFollowUp_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const leadId = await ownedLead(sql, context.userId, data.leadId);
	if (data.id) {
		if (!(await sql`
        update follow_ups set
          lead_id = ${leadId},
          title = ${data.title},
          due_date = ${data.dueDate},
          notes = ${data.notes}
        where id = ${data.id} and user_id = ${context.userId}
        returning id
      `)[0]) throw new Error("That reminder is not in your workspace.");
	} else await sql`
        insert into follow_ups (id, user_id, lead_id, title, due_date, notes, done, is_sample)
        values (
          ${crypto.randomUUID()}, ${context.userId}, ${leadId}, ${data.title},
          ${data.dueDate}, ${data.notes}, false, false
        )
      `;
	return readWorkspace(sql, context.userId);
});
var setFollowUpDone_createServerFn_handler = createServerRpc({
	id: "212e562c1ca707a9e7e291cad9c5124d9a2041c6a8aa833259a19438daa76999",
	name: "setFollowUpDone",
	filename: "src/server/bookbloom.ts"
}, (opts) => setFollowUpDone.__executeServer(opts));
var setFollowUpDone = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(followDoneSchema, data)).handler(setFollowUpDone_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (!(await sql`
      update follow_ups set done = ${data.done}
      where id = ${data.id} and user_id = ${context.userId}
      returning id
    `)[0]) throw new Error("That reminder is not in your workspace.");
	return readWorkspace(sql, context.userId);
});
var deleteFollowUp_createServerFn_handler = createServerRpc({
	id: "ef7a0f84010da00437e66ce7ba4352d5f48429fb68323b328c4ec22d8367c4ce",
	name: "deleteFollowUp",
	filename: "src/server/bookbloom.ts"
}, (opts) => deleteFollowUp.__executeServer(opts));
var deleteFollowUp = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(idSchema, data)).handler(deleteFollowUp_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (!(await sql`
      delete from follow_ups where id = ${data.id} and user_id = ${context.userId} returning id
    `)[0]) throw new Error("That reminder is not in your workspace.");
	return readWorkspace(sql, context.userId);
});
var loadSample_createServerFn_handler = createServerRpc({
	id: "43ddd4f79ee908b8cb30aed615d606305463d0207f9dab0fc595b31d2e7aa3f1",
	name: "loadSample",
	filename: "src/server/bookbloom.ts"
}, (opts) => loadSample.__executeServer(opts));
var loadSample = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(loadSample_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const business = await ensureBusiness(sql, context.userId);
	await sql`delete from follow_ups where user_id = ${context.userId} and is_sample = true`;
	await sql`delete from quotes where user_id = ${context.userId} and is_sample = true`;
	await sql`delete from leads where user_id = ${context.userId} and is_sample = true`;
	const profile = business.companyName.trim() ? business : {
		...business,
		companyName: "Harbor & Pine Cleaning",
		ownerName: business.ownerName || "A. Parker",
		email: business.email || "hello@harborpine.example",
		phone: business.phone || "(404) 555-0148",
		serviceArea: business.serviceArea || "Decatur and East Atlanta",
		hours: business.hours || "Mon–Fri 8:00–17:00, Sat 9:00–13:00"
	};
	if (!business.companyName.trim()) await sql`
        update businesses set
          company_name = ${profile.companyName},
          owner_name = ${profile.ownerName},
          email = ${profile.email},
          phone = ${profile.phone},
          service_area = ${profile.serviceArea},
          hours = ${profile.hours},
          sample_loaded = true,
          updated_at = now()
        where user_id = ${context.userId}
      `;
	else await sql`
        update businesses set sample_loaded = true, updated_at = now()
        where user_id = ${context.userId}
      `;
	const sample = buildSample(profile, context.userId);
	for (const lead of sample.leads) await sql`
        insert into leads (
          id, user_id, name, email, phone, service_id, service_label, rooms, sqft,
          frequency, notes, status, last_contact, is_sample
        ) values (
          ${lead.id}, ${context.userId}, ${lead.name}, ${lead.email}, ${lead.phone},
          ${lead.serviceId}, ${lead.serviceLabel}, ${lead.rooms}, ${lead.sqft},
          ${lead.frequency}, ${lead.notes}, ${lead.status}, ${lead.lastContact}, true
        )
      `;
	for (const quote of sample.quotes) await sql`
        insert into quotes (
          id, user_id, lead_id, breakdown, total_cents, explanation, status, is_sample
        ) values (
          ${quote.id}, ${context.userId}, ${quote.leadId}, ${JSON.stringify(quote.breakdown)}::jsonb,
          ${quote.totalCents}, ${quote.explanation}, ${quote.status}, true
        )
      `;
	for (const item of sample.followUps) await sql`
        insert into follow_ups (id, user_id, lead_id, title, due_date, notes, done, is_sample)
        values (
          ${item.id}, ${context.userId}, ${item.leadId}, ${item.title}, ${item.dueDate},
          ${item.notes}, ${item.done}, true
        )
      `;
	return readWorkspace(sql, context.userId);
});
var clearSample_createServerFn_handler = createServerRpc({
	id: "4634d38f18e89d65076c65439681d8c21cbd73db85547cfe69c0bdf398851ce6",
	name: "clearSample",
	filename: "src/server/bookbloom.ts"
}, (opts) => clearSample.__executeServer(opts));
var clearSample = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(clearSample_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await sql`delete from follow_ups where user_id = ${context.userId} and is_sample = true`;
	await sql`delete from quotes where user_id = ${context.userId} and is_sample = true`;
	await sql`delete from leads where user_id = ${context.userId} and is_sample = true`;
	await sql`
      update businesses set sample_loaded = false, updated_at = now()
      where user_id = ${context.userId}
    `;
	return readWorkspace(sql, context.userId);
});
async function draftFromFacts(facts) {
	const demo = renderDemoDraft(facts);
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		mode: "demo",
		text: demo,
		notice: "Demo draft — a live model is not connected. This text is a template filled with your saved business details. It was not written by an AI model."
	};
	const allowed = facts.quoteTotalLabel ? [facts.quoteTotalLabel] : [];
	try {
		const response = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"content-type": "application/json",
				authorization: `Bearer ${apiKey}`
			},
			signal: AbortSignal.timeout(2e4),
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .3,
				max_tokens: 400,
				messages: [{
					role: "system",
					content: "You draft a short customer message for a residential cleaning business. Use only the JSON facts. Do not invent prices, discounts, dates, addresses, phone numbers, or policies. If quoteTotalLabel is present you may mention that exact string and no other amount of money. If it is null, do not mention any dollar amount or number that could be read as a price. Plain text only, under 140 words. Do not claim the message was sent."
				}, {
					role: "user",
					content: JSON.stringify(facts)
				}]
			})
		});
		if (!response.ok) return {
			mode: "demo",
			text: demo,
			notice: "Live draft was unavailable, so this is the demo template instead. Nothing was sent."
		};
		const text = ((await response.json()).choices?.[0]?.message?.content ?? "").trim().slice(0, 1500);
		if (!text || hasUnexpectedPrice(text, allowed)) return {
			mode: "demo",
			text: demo,
			notice: "The live draft mentioned a price that is not on the saved estimate, so BookBloom kept the demo template. Nothing was sent."
		};
		return {
			mode: "grok",
			text,
			notice: "Drafted with Grok from your saved business details. Any price matches the estimate on file. Review it, then copy. BookBloom does not send it."
		};
	} catch {
		return {
			mode: "demo",
			text: demo,
			notice: "Live draft was unavailable, so this is the demo template instead. Nothing was sent."
		};
	}
}
var draftMessage_createServerFn_handler = createServerRpc({
	id: "6954df5632041f916f4c9c439770f517820354401cd696d868b2886e64d261e2",
	name: "draftMessage",
	filename: "src/server/bookbloom.ts"
}, (opts) => draftMessage.__executeServer(opts));
var draftMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(draftSchema, data)).handler(draftMessage_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const business = await ensureBusiness(sql, context.userId);
	const lead = (await sql`
      select
        id, name, email, phone,
        service_id as "serviceId",
        service_label as "serviceLabel",
        rooms, sqft, frequency, notes, status,
        last_contact as "lastContact",
        is_sample as "isSample",
        updated_at::text as "updatedAt"
      from leads
      where id = ${data.leadId} and user_id = ${context.userId}
    `)[0];
	if (!lead) throw new Error("Choose a lead from your workspace.");
	if (((await sql`
      select count(*)::int as n from ai_usage
      where user_id = ${context.userId} and created_at > now() - interval '1 day'
    `)[0]?.n ?? 0) >= DAILY_DRAFT_LIMIT) throw new Error("Daily draft limit reached (40). Try again tomorrow.");
	const quote = (await sql`
      select total_cents as "totalCents", status
      from quotes
      where user_id = ${context.userId} and lead_id = ${lead.id}
      order by updated_at desc
      limit 1
    `)[0];
	const facts = {
		messageType: data.messageType,
		tone: business.tone,
		companyName: clip(stripMoney(business.companyName), 80),
		serviceArea: clip(stripMoney(business.serviceArea), 120),
		hours: clip(stripMoney(business.hours), 160),
		customerFirstName: firstName(lead.name),
		serviceLabel: clip(stripMoney(lead.serviceLabel), 60),
		frequencyLabel: frequencyById(lead.frequency)?.label ?? "One-time",
		notes: clip(stripMoney(lead.notes), 400),
		quoteTotalLabel: quote ? formatMoney(quote.totalCents) : null,
		quoteStatus: quote?.status ?? null
	};
	const inputChars = JSON.stringify(facts).length;
	const result = await draftFromFacts(facts);
	await sql`
      insert into ai_usage (id, user_id, feature, mode, input_chars, output_chars)
      values (
        ${crypto.randomUUID()}, ${context.userId}, 'message_draft', ${result.mode},
        ${inputChars}, ${result.text.length}
      )
    `;
	return {
		mode: result.mode,
		text: result.text,
		label: result.mode === "grok" ? "Drafted with Grok" : "Demo draft — not a live model",
		notice: result.notice
	};
});
//#endregion
export { clearSample_createServerFn_handler, deleteFollowUp_createServerFn_handler, deleteLead_createServerFn_handler, deleteQuote_createServerFn_handler, draftMessage_createServerFn_handler, getWorkspace_createServerFn_handler, loadSample_createServerFn_handler, saveBusiness_createServerFn_handler, setFollowUpDone_createServerFn_handler, setQuoteStatus_createServerFn_handler, upsertFollowUp_createServerFn_handler, upsertLead_createServerFn_handler, upsertQuote_createServerFn_handler };
