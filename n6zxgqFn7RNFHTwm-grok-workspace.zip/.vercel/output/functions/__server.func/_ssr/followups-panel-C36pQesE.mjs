import { o as __toESM } from "../_runtime.mjs";
import { Q as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Field } from "./field-DYRyux0t.mjs";
import { _ as isOverdue, p as formatDay, x as todayISO } from "./sample-CJS8dzaP.mjs";
import { r as useWorkspace } from "./workspace-D4AMri1S.mjs";
import { t as Modal } from "./modal-DyY1WL2E.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/followups-panel-C36pQesE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FollowUpsPanel() {
	const workspace = useWorkspace();
	const today = todayISO();
	const [filter, setFilter] = (0, import_react.useState)("open");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		id: void 0,
		leadId: "",
		title: "",
		dueDate: today,
		notes: ""
	});
	const [formError, setFormError] = (0, import_react.useState)(null);
	const rows = (0, import_react.useMemo)(() => {
		return workspace.followUps.filter((item) => {
			if (filter === "done") return item.done;
			if (filter === "overdue") return isOverdue(item.dueDate, item.done, today);
			if (filter === "upcoming") return !item.done && item.dueDate >= today;
			return !item.done;
		});
	}, [
		workspace.followUps,
		filter,
		today
	]);
	function edit(item) {
		setFormError(null);
		setForm(item ? {
			id: item.id,
			leadId: item.leadId ?? "",
			title: item.title,
			dueDate: item.dueDate,
			notes: item.notes
		} : {
			id: void 0,
			leadId: workspace.leads[0]?.id ?? "",
			title: "",
			dueDate: today,
			notes: ""
		});
		setOpen(true);
	}
	async function save(event) {
		event.preventDefault();
		try {
			await workspace.upsertFollowUp({
				id: form.id,
				leadId: form.leadId || null,
				title: form.title,
				dueDate: form.dueDate,
				notes: form.notes
			});
			setOpen(false);
		} catch (error) {
			setFormError(error instanceof Error ? error.message : "Could not save that reminder.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl",
					children: "Follow-ups"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Reminders stay in this dashboard. BookBloom will not text or email them for you."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-primary",
					onClick: () => edit(),
					children: "Add reminder"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto",
				role: "tablist",
				"aria-label": "Filter reminders",
				children: [
					["open", "Open"],
					["overdue", "Overdue"],
					["upcoming", "Upcoming"],
					["done", "Done"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: filter === id ? "btn btn-primary" : "btn btn-ghost",
					onClick: () => setFilter(id),
					"aria-pressed": filter === id,
					children: label
				}, id))
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Nothing in this filter."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3",
				children: rows.map((item) => {
					const overdue = isOverdue(item.dueDate, item.done, today);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: overdue ? "card bg-warn-soft p-4" : "card p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: item.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted",
									children: [
										item.leadName || "No lead",
										" · ",
										formatDay(item.dueDate),
										item.isSample ? " · Sample" : "",
										overdue ? " · Overdue" : ""
									]
								}),
								item.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm",
									children: item.notes
								}) : null
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-secondary",
									onClick: () => void workspace.setFollowUpDone(item.id, !item.done),
									children: item.done ? "Reopen" : "Mark done"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-ghost",
									onClick: () => edit(item),
									children: "Edit"
								})]
							})]
						})
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				title: form.id ? "Edit reminder" : "Add reminder",
				open,
				onClose: () => setOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-3",
					onSubmit: (event) => void save(event),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Reminder",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field-input",
								required: true,
								value: form.title,
								onChange: (event) => setForm({
									...form,
									title: event.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Lead",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "field-input",
								value: form.leadId,
								onChange: (event) => setForm({
									...form,
									leadId: event.target.value
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "No lead"
								}), workspace.leads.map((lead) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: lead.id,
									children: lead.name
								}, lead.id))]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Due date",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field-input",
								type: "date",
								required: true,
								value: form.dueDate,
								onChange: (event) => setForm({
									...form,
									dueDate: event.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Notes",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: "field-input",
								value: form.notes,
								onChange: (event) => setForm({
									...form,
									notes: event.target.value
								})
							})
						}),
						formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-warn",
							children: formError
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn btn-primary",
								type: "submit",
								disabled: workspace.saving,
								children: workspace.saving ? "Saving…" : "Save reminder"
							}), form.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-warn",
								onClick: () => {
									workspace.deleteFollowUp(form.id).then(() => setOpen(false)).catch((error) => {
										setFormError(error instanceof Error ? error.message : "Could not delete that reminder.");
									});
								},
								children: "Delete"
							}) : null]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { FollowUpsPanel as t };
