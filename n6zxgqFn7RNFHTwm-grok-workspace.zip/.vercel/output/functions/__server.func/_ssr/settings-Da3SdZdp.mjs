import { t as SettingsPanel } from "./settings-panel-CkY6vWnv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-Da3SdZdp.js
var SplitComponent = SettingsPanel;
//#endregion
export { SplitComponent as component };
