import { Q as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as LEAD_STATUSES, g as isDue, p as formatDay, x as todayISO } from "./sample-CJS8dzaP.mjs";
import { r as useWorkspace } from "./workspace-D4AMri1S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/overview-panel-CxxLa52F.js
var import_jsx_runtime = require_jsx_runtime();
function OverviewPanel() {
	const { leads, quotes, followUps, business } = useWorkspace();
	const today = todayISO();
	const due = followUps.filter((item) => isDue(item.dueDate, item.done, today));
	const drafts = quotes.filter((item) => item.status === "draft");
	const max = Math.max(1, ...LEAD_STATUSES.map((status) => leads.filter((lead) => lead.status === status.id).length));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl text-ink",
				children: "Overview"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-muted",
				children: [business.companyName ? business.companyName : "Add your company name in Settings.", " Rates on file are yours to edit. Nothing on this page sends a message."]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Leads",
						value: String(leads.length),
						hint: "In this workspace"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Pending estimates",
						value: String(drafts.length),
						hint: "Still marked draft"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Follow-ups due",
						value: String(due.length),
						hint: "Today or overdue"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Pipeline"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 grid gap-3",
					children: LEAD_STATUSES.map((status) => {
						const count = leads.filter((lead) => lead.status === status.id).length;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "grid grid-cols-[7rem_1fr_2rem] items-center gap-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: status.label }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "h-2 overflow-hidden rounded-full bg-bg",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block h-full rounded-full bg-accent",
										style: { width: `${count / max * 100}%` }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-muted",
									children: count
								})
							]
						}, status.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Reminders"
				}), due.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "No follow-ups due. Add one from the Follow-ups tab when you want a nudge inside the dashboard."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid gap-2",
					children: due.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-baseline justify-between gap-2 rounded-xl bg-bg px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [item.leadName ? `${item.leadName} · ` : "", formatDay(item.dueDate)]
						})]
					}, item.id))
				})]
			})
		]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "card p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-4xl tabular-nums text-ink",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: hint
			})
		]
	});
}
//#endregion
export { OverviewPanel as t };
