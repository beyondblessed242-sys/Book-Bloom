import { Q as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Notice } from "./field-DYRyux0t.mjs";
import { t as foundersPriceLabel } from "./pricing-BvRl-Hpu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/billing-panel-BZuCTGZA.js
var import_jsx_runtime = require_jsx_runtime();
var INCLUDED = [
	"One business profile and rate card",
	"Lead records with search and status",
	"Estimates calculated from your rates",
	"Editable message drafts you copy yourself",
	"Follow-up reminders inside the dashboard"
];
function BillingPanel({ checkout = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Billing"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-2xl text-sm text-muted",
				children: "The Founder’s Plan is a proposed price. Payments are not connected, so this page cannot start a subscription."
			})] }),
			checkout ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
				tone: "warn",
				children: "This page does not activate a subscription. BookBloom has no payment processor connected, so nothing was charged and your account was not upgraded. Visiting a success address does not grant paid access."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "card max-w-xl p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pill",
						children: "Proposed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-3xl",
						children: "Founder’s Plan"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-display text-5xl tabular-nums",
						children: [foundersPriceLabel(), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-2xl text-muted",
							children: "/month"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Shown for planning. Not billed. Not a live checkout."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-5 grid gap-2 text-sm",
						children: INCLUDED.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-b border-line pb-2",
							children: item
						}, item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 rounded-2xl bg-bg p-4 text-sm text-muted",
						children: "Stripe is not configured. There is no card form, no trial, and no upgrade button. When payments are added, they will be tested before any subscription can start."
					})
				]
			})
		]
	});
}
//#endregion
export { BillingPanel as t };
