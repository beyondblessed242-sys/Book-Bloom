import { Q as require_jsx_runtime, g as Outlet, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useCurrentUserState } from "./use-current-user-B7Cbrtsy.mjs";
import { n as LiveWorkspace } from "./workspace-D4AMri1S.mjs";
import { n as Shell, r as sectionFromPath, t as RedirectToSignIn } from "./shell-CNEazurf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-0djBPPEy.js
var import_jsx_runtime = require_jsx_runtime();
function AppLayout() {
	const { user, isPending } = useCurrentUserState();
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center text-muted",
		children: "Checking your session…"
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveWorkspace, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		current: sectionFromPath(pathname),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	}) });
}
//#endregion
export { AppLayout as component };
