import { t as OverviewPanel } from "./overview-panel-CxxLa52F.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-CcDgVBVW.js
var SplitComponent = OverviewPanel;
//#endregion
export { SplitComponent as component };
