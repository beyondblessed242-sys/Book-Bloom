import { Q as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Notice } from "./field-DYRyux0t.mjs";
import { t as Logo } from "./logo-CQuIplpX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-dA_NgALu.js
var import_jsx_runtime = require_jsx_runtime();
function AdminLockedPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto grid min-h-screen max-w-lg place-items-center px-4 py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card w-full p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-6 font-display text-4xl leading-tight",
					children: "Administrator access is locked"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
						tone: "warn",
						children: "Super Admin provisioning has not been completed, and multi-factor authentication is not enabled. This page does not grant access, show customer records, or let an account choose an admin role."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm leading-relaxed text-muted",
					children: "Business owners stay in their own workspace. Support tools are not available. Setup steps for a later server-side assignment are in the operator notes, not here."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/app",
						className: "btn btn-primary",
						children: "Your workspace"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						search: {
							next: "/app",
							mode: "sign-in"
						},
						className: "btn btn-secondary",
						children: "Sign in"
					})]
				})
			]
		})
	});
}
//#endregion
export { AdminLockedPage as component };
