import { o as __toESM } from "../_runtime.mjs";
import { Q as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Notice, t as Field } from "./field-DYRyux0t.mjs";
import { o as MESSAGE_TYPES } from "./sample-CJS8dzaP.mjs";
import { r as useWorkspace } from "./workspace-D4AMri1S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/messages-panel-DUnh6H0f.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MessagesPanel() {
	const workspace = useWorkspace();
	const [leadId, setLeadId] = (0, import_react.useState)(workspace.leads[0]?.id ?? "");
	const [messageType, setMessageType] = (0, import_react.useState)("initial");
	const [text, setText] = (0, import_react.useState)("");
	const [label, setLabel] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	async function generate() {
		setError(null);
		setCopied(false);
		if (!leadId) {
			setError("Add a lead first.");
			return;
		}
		setBusy(true);
		try {
			const result = await workspace.draftMessage(leadId, messageType);
			setText(result.text);
			setLabel(result.label);
			setNotice(result.notice);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not draft that message.");
		} finally {
			setBusy(false);
		}
	}
	async function copy() {
		try {
			await navigator.clipboard.writeText(text);
			setCopied(true);
		} catch {
			setError("Could not copy. Select the text and copy it manually.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Message assistant"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-2xl text-sm text-muted",
				children: "Drafts use the company details, tone, and estimate you saved. They do not include the customer’s email or phone. You copy the text and send it yourself."
			})] }),
			!workspace.aiLive || workspace.mode === "demo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Demo drafts are templates, not a live model. If a server key is connected on a real account, drafts are labeled “Drafted with Grok”." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Grok is available for drafts you request. Prices are limited to the estimate on file. Each draft is logged toward a daily cap of 40." }),
			workspace.leads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card p-6 text-sm text-muted",
				children: "Add a lead before drafting a message."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card grid gap-4 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Lead",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field-input",
								value: leadId,
								onChange: (event) => setLeadId(event.target.value),
								children: workspace.leads.map((lead) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: lead.id,
									children: [lead.name, lead.isSample ? " (sample)" : ""]
								}, lead.id))
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Message type",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field-input",
								value: messageType,
								onChange: (event) => setMessageType(event.target.value),
								children: MESSAGE_TYPES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item.id,
									children: item.label
								}, item.id))
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: MESSAGE_TYPES.find((item) => item.id === messageType)?.hint
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary w-fit",
						disabled: busy,
						onClick: () => void generate(),
						children: busy ? "Drafting…" : "Draft message"
					}),
					label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: label
					}) : null,
					notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: notice }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Draft",
						hint: "Edit before you copy. This box is not sent anywhere.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "field-input",
							value: text,
							onChange: (event) => setText(event.target.value)
						})
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-warn",
						role: "alert",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-secondary",
							disabled: !text,
							onClick: () => void copy(),
							children: copied ? "Copied" : "Copy"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							"aria-live": "polite",
							children: copied ? "On your clipboard. Send it from your own email or phone." : ""
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { MessagesPanel as t };
