import { t as FollowUpsPanel } from "./followups-panel-C36pQesE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/follow-ups-Tn-58-rh.js
var SplitComponent = FollowUpsPanel;
//#endregion
export { SplitComponent as component };
