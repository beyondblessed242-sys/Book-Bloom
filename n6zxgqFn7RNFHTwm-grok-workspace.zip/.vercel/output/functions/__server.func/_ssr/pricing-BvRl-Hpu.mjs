//#region node_modules/.nitro/vite/services/ssr/assets/pricing-BvRl-Hpu.js
/** Founder's Plan display price. Billing is not connected, so this does not charge anyone. */
var FOUNDERS_MONTHLY_CENTS = 4900;
function foundersPriceLabel() {
	const dollars = FOUNDERS_MONTHLY_CENTS / 100;
	return Number.isInteger(dollars) ? `$${dollars}` : `$${(FOUNDERS_MONTHLY_CENTS / 100).toFixed(2)}`;
}
//#endregion
export { foundersPriceLabel as t };
