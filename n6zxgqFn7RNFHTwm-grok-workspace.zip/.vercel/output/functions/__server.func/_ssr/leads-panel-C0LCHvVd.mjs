import { o as __toESM } from "../_runtime.mjs";
import { Q as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Field } from "./field-DYRyux0t.mjs";
import { a as LEAD_STATUSES, b as statusLabel, i as FREQUENCIES, p as formatDay } from "./sample-CJS8dzaP.mjs";
import { r as useWorkspace } from "./workspace-D4AMri1S.mjs";
import { t as Modal } from "./modal-DyY1WL2E.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/leads-panel-C0LCHvVd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var emptyForm = {
	id: void 0,
	name: "",
	email: "",
	phone: "",
	serviceId: "standard",
	rooms: "",
	sqft: "",
	frequency: "one-time",
	notes: "",
	status: "new",
	lastContact: ""
};
function LeadsPanel() {
	const workspace = useWorkspace();
	const [query, setQuery] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("all");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)(emptyForm);
	const [formError, setFormError] = (0, import_react.useState)(null);
	const rows = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return workspace.leads.filter((lead) => {
			if (status !== "all" && lead.status !== status) return false;
			if (!q) return true;
			return [
				lead.name,
				lead.email,
				lead.phone,
				lead.serviceLabel,
				lead.notes
			].join(" ").toLowerCase().includes(q);
		});
	}, [
		workspace.leads,
		query,
		status
	]);
	function edit(lead) {
		setFormError(null);
		if (!lead) setForm({
			...emptyForm,
			serviceId: workspace.business.services[0]?.id ?? "standard"
		});
		else setForm({
			id: lead.id,
			name: lead.name,
			email: lead.email,
			phone: lead.phone,
			serviceId: lead.serviceId,
			rooms: lead.rooms == null ? "" : String(lead.rooms),
			sqft: lead.sqft == null ? "" : String(lead.sqft),
			frequency: lead.frequency,
			notes: lead.notes,
			status: lead.status,
			lastContact: lead.lastContact ?? ""
		});
		setOpen(true);
	}
	async function save(event) {
		event.preventDefault();
		setFormError(null);
		const rooms = form.rooms.trim() === "" ? null : Number(form.rooms);
		const sqft = form.sqft.trim() === "" ? null : Number(form.sqft);
		if (rooms != null && (!Number.isInteger(rooms) || rooms < 0)) {
			setFormError("Rooms must be a whole number.");
			return;
		}
		if (sqft != null && (!Number.isInteger(sqft) || sqft < 0)) {
			setFormError("Square footage must be a whole number.");
			return;
		}
		try {
			await workspace.upsertLead({
				id: form.id,
				name: form.name,
				email: form.email,
				phone: form.phone,
				serviceId: form.serviceId,
				rooms,
				sqft,
				frequency: form.frequency,
				notes: form.notes,
				status: form.status,
				lastContact: form.lastContact || null
			});
			setOpen(false);
		} catch (error) {
			setFormError(error instanceof Error ? error.message : "Could not save that lead.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl",
					children: "Leads"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Contact details stay in your account. BookBloom does not email or text them."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-primary",
					onClick: () => edit(),
					children: "Add lead"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-[1fr_12rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Search",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field-input",
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "Name, phone, service, notes"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Status",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field-input",
						value: status,
						onChange: (event) => setStatus(event.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All statuses"
						}), LEAD_STATUSES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item.id,
							children: item.label
						}, item.id))]
					})
				})]
			}),
			workspace.leads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: "No leads yet."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Add someone you are talking to, or load the fictional sample workspace from Settings."
				})]
			}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No leads match that search."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3",
				children: rows.map((lead) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "card flex w-full flex-col gap-2 p-4 text-left",
					onClick: () => edit(lead),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: lead.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pill",
									children: statusLabel(lead.status)
								}),
								lead.isSample ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pill pill-muted",
									children: "Sample"
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm text-muted",
							children: [
								lead.serviceLabel,
								" · ",
								FREQUENCIES.find((item) => item.id === lead.frequency)?.label,
								lead.rooms != null ? ` · ${lead.rooms} rooms` : "",
								lead.sqft != null ? ` · ${lead.sqft} sq ft` : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm text-muted",
							children: [
								lead.phone || "No phone",
								" · ",
								lead.email || "No email",
								" · Last contact ",
								formatDay(lead.lastContact)
							]
						})
					]
				}) }, lead.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				title: form.id ? "Edit lead" : "Add lead",
				open,
				onClose: () => setOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-3",
					onSubmit: (event) => void save(event),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field-input",
								required: true,
								value: form.name,
								onChange: (event) => setForm({
									...form,
									name: event.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Email",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field-input",
									type: "email",
									value: form.email,
									onChange: (event) => setForm({
										...form,
										email: event.target.value
									})
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Phone",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field-input",
									value: form.phone,
									onChange: (event) => setForm({
										...form,
										phone: event.target.value
									})
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Service",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: "field-input",
									value: form.serviceId,
									onChange: (event) => setForm({
										...form,
										serviceId: event.target.value
									}),
									children: workspace.business.services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: service.id,
										children: service.label
									}, service.id))
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Status",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: "field-input",
									value: form.status,
									onChange: (event) => setForm({
										...form,
										status: event.target.value
									}),
									children: LEAD_STATUSES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: item.id,
										children: item.label
									}, item.id))
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Rooms",
									hint: "Leave blank if unknown",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field-input",
										inputMode: "numeric",
										value: form.rooms,
										onChange: (event) => setForm({
											...form,
											rooms: event.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Square feet",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field-input",
										inputMode: "numeric",
										value: form.sqft,
										onChange: (event) => setForm({
											...form,
											sqft: event.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Frequency",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: "field-input",
										value: form.frequency,
										onChange: (event) => setForm({
											...form,
											frequency: event.target.value
										}),
										children: FREQUENCIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: item.id,
											children: item.label
										}, item.id))
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Last contact",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field-input",
								type: "date",
								value: form.lastContact,
								onChange: (event) => setForm({
									...form,
									lastContact: event.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Notes",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: "field-input",
								value: form.notes,
								onChange: (event) => setForm({
									...form,
									notes: event.target.value
								})
							})
						}),
						formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-warn",
							children: formError
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "btn btn-primary",
								disabled: workspace.saving,
								children: workspace.saving ? "Saving…" : "Save lead"
							}), form.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-warn",
								onClick: () => {
									workspace.deleteLead(form.id).then(() => setOpen(false)).catch((error) => {
										setFormError(error instanceof Error ? error.message : "Could not delete that lead.");
									});
								},
								children: "Delete"
							}) : null]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { LeadsPanel as t };
