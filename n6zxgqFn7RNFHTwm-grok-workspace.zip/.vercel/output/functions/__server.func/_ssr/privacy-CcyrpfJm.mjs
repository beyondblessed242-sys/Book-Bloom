import { Q as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Logo } from "./logo-CQuIplpX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-CcyrpfJm.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-6 font-display text-4xl",
				children: "Privacy Policy"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "An account stores the name, email, and password you submit. The password is stored only as a hash. BookBloom does not show it back to you." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Business records you add — company profile, leads, estimates, drafts, and follow-ups — are stored for that signed-in account. Other business accounts do not receive them. The public demo does not save what you type." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Email verification and password-reset messages are not sent, because email delivery is not configured. Signing in with Google or X uses the connected sign-in service and does not give BookBloom your social password." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Do not rely on this workspace for real customer contact details until you have reviewed access for your own deployment. There is no administrator console that can browse those records." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/terms",
						className: "text-accent",
						children: "Terms of Service"
					}) })
				]
			})
		]
	});
}
//#endregion
export { PrivacyPage as component };
