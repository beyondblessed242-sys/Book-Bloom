import { o as __toESM } from "../_runtime.mjs";
import { Q as require_jsx_runtime, Z as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Notice } from "./field-DYRyux0t.mjs";
import { t as Logo } from "./logo-CQuIplpX.mjs";
import { n as resetPasswordWithToken } from "./email-session-zjx0egTi.mjs";
import { n as Route$10 } from "./router-DJKls-_c.mjs";
import { n as passwordError, r as passwordRules, t as PasswordField } from "./password-policy-COkjUCox.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reset-password-_3i6ONCF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ResetPasswordPage() {
	const { token } = Route$10.useSearch();
	const [password, setPassword] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [showConfirm, setShowConfirm] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [done, setDone] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		setError(null);
		const problem = passwordError(password);
		if (problem) {
			setError(problem);
			return;
		}
		if (confirm !== password) {
			setError("Those passwords do not match.");
			return;
		}
		setBusy(true);
		try {
			await resetPasswordWithToken({
				token,
				newPassword: password
			});
			setDone(true);
		} catch (err) {
			setError(err instanceof Error ? err.message : "This reset link is not valid.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto grid min-h-screen max-w-md place-items-center px-4 py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card w-full p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-6 font-display text-4xl leading-tight",
					children: "Choose a new password"
				}),
				token ? done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Your password was updated. Sign in with the new one. This did not start a subscription." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						search: {
							next: "/app",
							mode: "sign-in"
						},
						className: "btn btn-primary",
						children: "Sign In"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-6 grid gap-4",
					onSubmit: (event) => void submit(event),
					noValidate: true,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordField, {
							label: "New password",
							value: password,
							onChange: setPassword,
							autoComplete: "new-password",
							shown: showPassword,
							onToggle: () => setShowPassword((value) => !value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid gap-1 text-xs",
							"aria-live": "polite",
							children: passwordRules(password).map((rule) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: rule.met ? "text-accent" : "text-muted",
								children: [
									rule.met ? "Met" : "Needed",
									" — ",
									rule.label
								]
							}, rule.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordField, {
							label: "Confirm password",
							value: confirm,
							onChange: setConfirm,
							autoComplete: "new-password",
							shown: showConfirm,
							onToggle: () => setShowConfirm((value) => !value),
							error: confirm && confirm !== password ? "Those passwords do not match." : void 0
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-warn",
							role: "alert",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn btn-primary",
							type: "submit",
							disabled: busy,
							children: busy ? "Updating…" : "Update password"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
						tone: "warn",
						children: "This page needs a reset link. Email delivery is not configured, so BookBloom is not sending those links yet. Your password was not changed."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/forgot-password",
						className: "text-sm text-accent",
						children: "Request a reset"
					})]
				})
			]
		})
	});
}
//#endregion
export { ResetPasswordPage as component };
