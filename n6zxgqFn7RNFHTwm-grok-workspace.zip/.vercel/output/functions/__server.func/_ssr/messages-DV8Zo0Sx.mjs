import { A as boolean, D as _enum, F as object, P as number, R as string, k as array } from "../_libs/@better-auth/core+[...].mjs";
import { a as LEAD_STATUSES, c as TONES, i as FREQUENCIES, o as MESSAGE_TYPES, s as QUOTE_STATUSES } from "./sample-CJS8dzaP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/messages-DV8Zo0Sx.js
var money = number().int().min(0).max(1e7);
var adjustment = number().int().min(-5e5).max(5e5);
var serviceSchema = object({
	id: string().trim().min(1).max(40).regex(/^[a-z0-9-]+$/, "Service id must be a short slug"),
	label: string().trim().min(1, "Service name is required").max(60),
	baseCents: money,
	perRoomCents: money,
	perSqftCents: number().int().min(0).max(500)
});
var extraSchema = object({
	id: string().trim().min(1).max(40).regex(/^[a-z0-9-]+$/, "Extra id must be a short slug"),
	name: string().trim().min(1, "Extra name is required").max(60),
	cents: money
});
var optionalEmail = string().trim().max(120).refine((value) => value === "" || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value), "Enter a valid email or leave it blank");
var businessSchema = object({
	companyName: string().trim().max(80),
	ownerName: string().trim().max(80),
	email: optionalEmail,
	phone: string().trim().max(40),
	serviceArea: string().trim().max(120),
	hours: string().trim().max(160),
	tone: _enum(TONES.map((item) => item.id)),
	services: array(serviceSchema).min(1, "Keep at least one service").max(12),
	extras: array(extraSchema).max(20)
});
var leadSchema = object({
	id: string().trim().min(1).max(80).optional(),
	name: string().trim().min(1, "Name is required").max(80),
	email: optionalEmail,
	phone: string().trim().max(40),
	serviceId: string().trim().min(1).max(40),
	rooms: number().int().min(0).max(40).nullable(),
	sqft: number().int().min(0).max(2e4).nullable(),
	frequency: _enum(FREQUENCIES.map((item) => item.id)),
	notes: string().trim().max(2e3),
	status: _enum(LEAD_STATUSES.map((item) => item.id)),
	lastContact: string().trim().refine((value) => value === "" || /^\d{4}-\d{2}-\d{2}$/.test(value), "Use a real date").nullable()
});
var quoteSchema = object({
	id: string().trim().min(1).max(80).optional(),
	leadId: string().trim().min(1).max(80).nullable(),
	serviceId: string().trim().min(1).max(40),
	rooms: number().int().min(0).max(40),
	sqft: number().int().min(0).max(2e4),
	frequency: _enum(FREQUENCIES.map((item) => item.id)),
	extraIds: array(string().trim().min(1).max(40)).max(20),
	adjustmentCents: adjustment,
	explanation: string().trim().max(2e3),
	status: _enum(QUOTE_STATUSES.map((item) => item.id))
});
var quoteStatusSchema = object({
	id: string().trim().min(1).max(80),
	status: _enum([
		"draft",
		"approved",
		"sent"
	])
});
var followUpSchema = object({
	id: string().trim().min(1).max(80).optional(),
	leadId: string().trim().min(1).max(80).nullable(),
	title: string().trim().min(1, "Add a short reminder").max(140),
	dueDate: string().trim().regex(/^\d{4}-\d{2}-\d{2}$/, "Choose a due date"),
	notes: string().trim().max(1e3)
});
var idSchema = object({ id: string().trim().min(1).max(80) });
var followDoneSchema = object({
	id: string().trim().min(1).max(80),
	done: boolean()
});
var draftSchema = object({
	leadId: string().trim().min(1).max(80),
	messageType: _enum(MESSAGE_TYPES.map((item) => item.id))
});
function parseInput(schema, data) {
	const result = schema.safeParse(data);
	if (!result.success) throw new Error(result.error.issues[0]?.message ?? "Check the form and try again.");
	return result.data;
}
function firstName(fullName) {
	return (fullName.trim().split(/\s+/)[0] ?? "").replace(/[^\p{L}\p{M}'-]/gu, "").slice(0, 40);
}
function clip(value, max) {
	const clean = value.replace(/\s+/g, " ").trim();
	if (clean.length <= max) return clean;
	return `${clean.slice(0, max - 1).trim()}…`;
}
var MONEY = /\$\s?\d{1,3}(?:,\d{3})*(?:\.\d{2})?/g;
function moneyTokens(text) {
	return (text.match(MONEY) ?? []).map((token) => token.replace(/\s/g, ""));
}
function stripMoney(text) {
	return text.replace(MONEY, "").replace(/\s{2,}/g, " ").replace(/\s+([,.])/g, "$1").trim();
}
/** True when the draft mentions a dollar amount other than the saved quote total. */
function hasUnexpectedPrice(text, allowed) {
	const ok = new Set(allowed.map((item) => item.replace(/\s/g, "")));
	return moneyTokens(text).some((token) => !ok.has(token));
}
function renderDemoDraft(facts) {
	const name = stripMoney(facts.customerFirstName) || "there";
	const company = stripMoney(facts.companyName) || "our cleaning team";
	const service = stripMoney(facts.serviceLabel) || "a cleaning";
	const area = facts.serviceArea ? ` We work in ${stripMoney(facts.serviceArea)}.` : "";
	const hours = facts.hours ? ` Hours: ${stripMoney(facts.hours)}.` : "";
	const price = facts.quoteTotalLabel ? `The estimate on file is ${facts.quoteTotalLabel}.` : "I will price it from our rate card once the details are confirmed, so I am not quoting a number in this note.";
	const noteSource = stripMoney(facts.notes);
	const note = noteSource ? ` I have this note: ${clip(noteSource, 180)}` : "";
	return draftBody(facts.messageType, facts.tone, {
		name,
		company,
		service,
		area,
		hours,
		price,
		note,
		frequency: facts.frequencyLabel
	});
}
function draftBody(type, tone, b) {
	if (tone === "concise") return concise(type, b);
	if (tone === "professional") return professional(type, b);
	return warm(type, b);
}
function warm(type, b) {
	switch (type) {
		case "initial": return `Hi ${b.name}, this is ${b.company}. Thanks for asking about ${b.service} (${b.frequency}).${b.note} ${b.price}${b.area}${b.hours} Reply with a day that works and I will hold it.`;
		case "estimate_followup": return `Hi ${b.name}, just circling back from ${b.company} on the ${b.service}. ${b.price} Happy to adjust rooms or add-ons if something changed. No payment is taken in this message — tell me if you want the time.`;
		case "unanswered": return `Hi ${b.name}, ${b.company} again. I still have your ${b.service} inquiry and I have not heard back.${b.note} ${b.price} If now is not a fit, a quick no is welcome so I can close the note.`;
		case "thank_you": return `Hi ${b.name}, thank you for choosing ${b.company}. It was good to take care of the ${b.service}. If anything was missed, reply and I will make it right.${b.area}`;
	}
}
function professional(type, b) {
	switch (type) {
		case "initial": return `Hello ${b.name}, this is ${b.company}. Thank you for your inquiry about ${b.service} on a ${b.frequency.toLowerCase()} schedule.${b.note} ${b.price}${b.area}${b.hours} Please reply with a preferred day and I will confirm availability.`;
		case "estimate_followup": return `Hello ${b.name}, I am following up from ${b.company} regarding ${b.service}. ${b.price} The figure uses the rate card saved on the account. Let me know if the scope should change before you decide.`;
		case "unanswered": return `Hello ${b.name}, I am writing from ${b.company} because your ${b.service} inquiry is still open.${b.note} ${b.price} Kindly let me know whether you would like to proceed.`;
		case "thank_you": return `Hello ${b.name}, thank you for scheduling with ${b.company}. We appreciate the chance to complete your ${b.service}. Please contact us if any detail needs attention.${b.area}`;
	}
}
function concise(type, b) {
	switch (type) {
		case "initial": return `Hi ${b.name} — ${b.company}. ${b.service}, ${b.frequency}.${b.note} ${b.price}${b.hours} Reply with a day if you want it booked.`;
		case "estimate_followup": return `Hi ${b.name}, following up on ${b.service}. ${b.price} Say if you want changes or a time.`;
		case "unanswered": return `Hi ${b.name}, still holding your ${b.service} inquiry at ${b.company}. ${b.price} A yes or no is enough.`;
		case "thank_you": return `Hi ${b.name}, thank you from ${b.company} for the ${b.service}. Message me if anything needs a fix.`;
	}
}
//#endregion
export { followDoneSchema as a, idSchema as c, quoteSchema as d, quoteStatusSchema as f, firstName as i, leadSchema as l, stripMoney as m, clip as n, followUpSchema as o, renderDemoDraft as p, draftSchema as r, hasUnexpectedPrice as s, businessSchema as t, parseInput as u };
