//#region node_modules/.nitro/vite/services/ssr/assets/safe-next-vDyqGKPg.js
/** Only in-app business paths. Blocks open redirects and admin URLs. */
function safeNextPath(value) {
	if (!value || !value.startsWith("/") || value.startsWith("//")) return "/app";
	if (value === "/app" || value.startsWith("/app/") || value === "/demo") return value;
	return "/app";
}
function postLoginPath(input) {
	input.role;
	return safeNextPath(input.requested);
}
//#endregion
export { safeNextPath as n, postLoginPath as t };
