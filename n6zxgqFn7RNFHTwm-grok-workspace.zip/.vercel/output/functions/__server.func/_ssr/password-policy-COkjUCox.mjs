import { Q as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Field } from "./field-DYRyux0t.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/password-policy-COkjUCox.js
var import_jsx_runtime = require_jsx_runtime();
function PasswordField({ label, value, onChange, autoComplete, shown, onToggle, error, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label,
		hint,
		error,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "password-field",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field-input",
				type: shown ? "text" : "password",
				autoComplete,
				required: true,
				value,
				"aria-invalid": error ? true : void 0,
				onChange: (event) => onChange(event.target.value)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "password-toggle",
				"aria-pressed": shown,
				onClick: onToggle,
				children: shown ? "Hide" : "Show"
			})]
		})
	});
}
function passwordRules(password) {
	return [
		{
			id: "length",
			label: "At least 8 characters",
			met: password.length >= 8 && password.length <= 128
		},
		{
			id: "letter",
			label: "At least one letter",
			met: /[A-Za-z]/.test(password)
		},
		{
			id: "number",
			label: "At least one number",
			met: /[0-9]/.test(password)
		}
	];
}
function passwordError(password) {
	if (password.length > 128) return "Use 128 characters or fewer.";
	const missing = passwordRules(password).filter((rule) => !rule.met);
	if (missing.length === 0) return null;
	return `Password needs: ${missing.map((rule) => rule.label.toLowerCase()).join(", ")}.`;
}
//#endregion
export { passwordError as n, passwordRules as r, PasswordField as t };
