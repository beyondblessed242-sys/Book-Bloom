import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-3dIwojxy.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { t as postLoginPath } from "./safe-next-vDyqGKPg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/entry-8QNH1MHw.js
/** Where a verified session may go. The client cannot supply a role. */
var resolveWorkspaceEntry_createServerFn_handler = createServerRpc({
	id: "c7435ec54f7c341712c03725e772398516a9caf2ac5625403a27d36e7fcc4ff1",
	name: "resolveWorkspaceEntry",
	filename: "src/server/entry.ts"
}, (opts) => resolveWorkspaceEntry.__executeServer(opts));
var resolveWorkspaceEntry = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => ({ requested: typeof data?.requested === "string" ? data.requested : "/app" })).handler(resolveWorkspaceEntry_createServerFn_handler, async ({ data }) => {
	return { path: postLoginPath({
		requested: data.requested,
		role: "business_owner",
		mfaSatisfied: false
	}) };
});
//#endregion
export { resolveWorkspaceEntry_createServerFn_handler };
