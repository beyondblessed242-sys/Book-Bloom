//#region node_modules/.nitro/vite/services/ssr/assets/sample-CJS8dzaP.js
var TONES = [
	{
		id: "warm",
		label: "Warm",
		hint: "Friendly and plain-spoken"
	},
	{
		id: "professional",
		label: "Professional",
		hint: "Polite and composed"
	},
	{
		id: "concise",
		label: "Concise",
		hint: "Short, no extra lines"
	}
];
var FREQUENCIES = [
	{
		id: "one-time",
		label: "One-time",
		bps: 1e4
	},
	{
		id: "weekly",
		label: "Weekly",
		bps: 8e3
	},
	{
		id: "biweekly",
		label: "Every two weeks",
		bps: 8800
	},
	{
		id: "monthly",
		label: "Monthly",
		bps: 9500
	}
];
var LEAD_STATUSES = [
	{
		id: "new",
		label: "New"
	},
	{
		id: "contacted",
		label: "Contacted"
	},
	{
		id: "quoted",
		label: "Quoted"
	},
	{
		id: "booked",
		label: "Booked"
	},
	{
		id: "lost",
		label: "Lost"
	}
];
var QUOTE_STATUSES = [
	{
		id: "draft",
		label: "Draft"
	},
	{
		id: "approved",
		label: "Approved"
	},
	{
		id: "sent",
		label: "Marked sent"
	}
];
var MESSAGE_TYPES = [
	{
		id: "initial",
		label: "Initial response",
		hint: "First reply to a new inquiry"
	},
	{
		id: "estimate_followup",
		label: "Estimate follow-up",
		hint: "After a quote is on file"
	},
	{
		id: "unanswered",
		label: "Unanswered inquiry",
		hint: "A nudge when they went quiet"
	},
	{
		id: "thank_you",
		label: "Thank-you",
		hint: "After a booking or a visit"
	}
];
var DEFAULT_SERVICES = [
	{
		id: "standard",
		label: "Standard clean",
		baseCents: 8900,
		perRoomCents: 2200,
		perSqftCents: 8
	},
	{
		id: "deep",
		label: "Deep clean",
		baseCents: 14900,
		perRoomCents: 3500,
		perSqftCents: 14
	},
	{
		id: "move-out",
		label: "Move-out clean",
		baseCents: 19900,
		perRoomCents: 4500,
		perSqftCents: 18
	}
];
var DEFAULT_EXTRAS = [
	{
		id: "fridge",
		name: "Inside fridge",
		cents: 3500
	},
	{
		id: "oven",
		name: "Inside oven",
		cents: 3e3
	},
	{
		id: "windows",
		name: "Interior windows",
		cents: 4e3
	},
	{
		id: "laundry",
		name: "Laundry fold",
		cents: 2500
	}
];
var EMPTY_BUSINESS = {
	id: "pending",
	companyName: "",
	ownerName: "",
	email: "",
	phone: "",
	serviceArea: "",
	hours: "Mon–Fri 8:00–17:00",
	tone: "warm",
	services: DEFAULT_SERVICES,
	extras: DEFAULT_EXTRAS,
	sampleLoaded: false
};
function frequencyById(id) {
	return FREQUENCIES.find((item) => item.id === id) ?? null;
}
function statusLabel(id) {
	return LEAD_STATUSES.find((item) => item.id === id)?.label ?? id;
}
/** Whole cents. Negative values are allowed for an owner adjustment. */
function formatMoney(cents) {
	const sign = cents < 0 ? "-" : "";
	const abs = Math.abs(Math.round(cents));
	const dollars = Math.floor(abs / 100);
	const rem = String(abs % 100).padStart(2, "0");
	return `${sign}$${String(dollars).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}.${rem}`;
}
/** Parse a dollar field. Empty is 0. Returns null when the text is not a money amount. */
function parseDollarsToCents(input, allowNegative = false) {
	const t = input.trim().replace(/[$,\s]/g, "");
	if (!t) return 0;
	if (!(allowNegative ? /^-?\d+(\.\d{1,2})?$/ : /^\d+(\.\d{1,2})?$/).test(t)) return null;
	const negative = t.startsWith("-");
	const [d, c = ""] = (negative ? t.slice(1) : t).split(".");
	const cents = Number(d) * 100 + Number(c.padEnd(2, "0"));
	if (!Number.isSafeInteger(cents)) return null;
	return negative ? -cents : cents;
}
function centsToInput(cents) {
	const sign = cents < 0 ? "-" : "";
	const abs = Math.abs(Math.round(cents));
	return `${sign}${Math.floor(abs / 100)}.${String(abs % 100).padStart(2, "0")}`;
}
function calculateQuote(input) {
	const service = input.services.find((item) => item.id === input.serviceId);
	if (!service) throw new Error("Choose a service from your rate card.");
	const frequency = frequencyById(input.frequency);
	if (!frequency) throw new Error("Choose how often they want service.");
	const rooms = clampInt(input.rooms, 0, 40);
	const sqft = clampInt(input.sqft, 0, 2e4);
	const roomsCents = rooms * service.perRoomCents;
	const sqftCents = sqft * service.perSqftCents;
	const cleaningCents = service.baseCents + roomsCents + sqftCents;
	const frequencyCents = Math.round(cleaningCents * frequency.bps / 1e4);
	const extras = input.extraIds.map((id) => input.extrasCatalog.find((item) => item.id === id)).filter((item) => Boolean(item)).map((item) => ({
		id: item.id,
		name: item.name,
		cents: item.cents
	}));
	const extrasCents = extras.reduce((sum, item) => sum + item.cents, 0);
	const adjustmentCents = clampInt(input.adjustmentCents, -5e5, 5e5);
	const totalCents = frequencyCents + extrasCents + adjustmentCents;
	return {
		serviceId: service.id,
		serviceLabel: service.label,
		rooms,
		sqft,
		perRoomCents: service.perRoomCents,
		perSqftCents: service.perSqftCents,
		frequency: frequency.id,
		frequencyLabel: frequency.label,
		multiplierBps: frequency.bps,
		baseCents: service.baseCents,
		roomsCents,
		sqftCents,
		cleaningCents,
		frequencyCents,
		extras,
		extrasCents,
		adjustmentCents,
		totalCents
	};
}
/** Plain-language explanation built only from the calculated lines. */
function explainQuote(b) {
	const parts = [`${b.serviceLabel}, ${b.frequencyLabel.toLowerCase()}.`, `Base ${formatMoney(b.baseCents)}.`];
	if (b.rooms > 0) parts.push(`${b.rooms} ${b.rooms === 1 ? "room" : "rooms"} at ${formatMoney(b.perRoomCents)} comes to ${formatMoney(b.roomsCents)}.`);
	if (b.sqft > 0) parts.push(`${b.sqft.toLocaleString("en-US")} sq ft at ${formatMoney(b.perSqftCents)} comes to ${formatMoney(b.sqftCents)}.`);
	if (b.rooms === 0 && b.sqft === 0) parts.push("No rooms or square footage were entered, so only the base rate is used.");
	if (b.multiplierBps !== 1e4) {
		const pct = (b.multiplierBps / 100).toFixed(0);
		parts.push(`The ${b.frequencyLabel.toLowerCase()} rate (${pct}% of the cleaning subtotal) brings that portion to ${formatMoney(b.frequencyCents)}.`);
	}
	for (const extra of b.extras) parts.push(`${extra.name} adds ${formatMoney(extra.cents)}.`);
	if (b.adjustmentCents !== 0) parts.push(`Owner adjustment ${formatMoney(b.adjustmentCents)}.`);
	parts.push(`Total ${formatMoney(b.totalCents)}.`);
	parts.push("Extras are not discounted. This total is math from the rate card, not an estimate invented by a model.");
	return parts.join(" ");
}
function clampInt(value, min, max) {
	if (!Number.isFinite(value)) return min;
	return Math.min(max, Math.max(min, Math.round(value)));
}
/** Local calendar date as YYYY-MM-DD. String compare matches chronological order. */
function todayISO(now = /* @__PURE__ */ new Date()) {
	return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}
function addDaysISO(iso, days) {
	const [y, m, d] = iso.split("-").map(Number);
	const dt = new Date(y, (m ?? 1) - 1, d ?? 1);
	dt.setDate(dt.getDate() + days);
	return todayISO(dt);
}
function isOverdue(due, done, today = todayISO()) {
	return !done && due < today;
}
function isDue(due, done, today = todayISO()) {
	return !done && due <= today;
}
function formatDay(iso) {
	if (!iso) return "—";
	const [y, m, d] = iso.split("-").map(Number);
	if (!y || !m || !d) return iso;
	return new Date(y, m - 1, d).toLocaleDateString("en-US", {
		month: "short",
		day: "numeric",
		year: "numeric"
	});
}
var SAMPLE_COMPANY = "Harbor & Pine Cleaning";
function sampleBusiness() {
	return {
		id: "sample-business",
		companyName: SAMPLE_COMPANY,
		ownerName: "A. Parker",
		email: "hello@harborpine.example",
		phone: "(404) 555-0148",
		serviceArea: "Decatur and East Atlanta",
		hours: "Mon–Fri 8:00–17:00, Sat 9:00–13:00",
		tone: "warm",
		services: DEFAULT_SERVICES.map((item) => ({ ...item })),
		extras: DEFAULT_EXTRAS.map((item) => ({ ...item })),
		sampleLoaded: true
	};
}
function buildSample(business, idPrefix, now = /* @__PURE__ */ new Date()) {
	const today = todayISO(now);
	const stamp = new Date(now).toISOString();
	const lead = (slug, partial) => {
		const service = business.services.find((item) => item.id === partial.serviceId);
		return {
			...partial,
			id: `${idPrefix}-lead-${slug}`,
			serviceLabel: service?.label ?? partial.serviceId,
			isSample: true,
			updatedAt: stamp
		};
	};
	const leads = [
		lead("amira", {
			name: "Amira Cole",
			email: "amira.cole@example.com",
			phone: "(404) 555-0172",
			serviceId: "standard",
			rooms: 3,
			sqft: null,
			frequency: "biweekly",
			notes: "Asked about Thursday mornings. Has a small dog.",
			status: "new",
			lastContact: addDaysISO(today, -1)
		}),
		lead("jordan", {
			name: "Jordan Hale",
			email: "jordan.hale@example.com",
			phone: "(404) 555-0119",
			serviceId: "deep",
			rooms: null,
			sqft: 1800,
			frequency: "one-time",
			notes: "Kitchen is the priority. They will move photos before arrival.",
			status: "contacted",
			lastContact: addDaysISO(today, -3)
		}),
		lead("priya", {
			name: "Priya Shah",
			email: "priya.shah@example.com",
			phone: "(404) 555-0164",
			serviceId: "move-out",
			rooms: 4,
			sqft: 2100,
			frequency: "one-time",
			notes: "Keys with the building manager after 4pm.",
			status: "quoted",
			lastContact: addDaysISO(today, -2)
		}),
		lead("chris", {
			name: "Chris Nguyen",
			email: "chris.nguyen@example.com",
			phone: "(404) 555-0188",
			serviceId: "standard",
			rooms: 2,
			sqft: null,
			frequency: "weekly",
			notes: "Standing Thursday visit. Do not store a gate code here.",
			status: "booked",
			lastContact: addDaysISO(today, -7)
		}),
		lead("elena", {
			name: "Elena Brooks",
			email: "elena.brooks@example.com",
			phone: "(404) 555-0133",
			serviceId: "deep",
			rooms: 3,
			sqft: 1400,
			frequency: "one-time",
			notes: "Sent a form last week and has not replied.",
			status: "new",
			lastContact: addDaysISO(today, -10)
		})
	];
	const makeQuote = (slug, leadSlug, extraIds, status) => {
		const row = leads.find((item) => item.id.endsWith(`-lead-${leadSlug}`));
		if (!row) throw new Error("Sample lead missing");
		const breakdown = calculateQuote({
			services: business.services,
			extrasCatalog: business.extras,
			serviceId: row.serviceId,
			rooms: row.rooms ?? 0,
			sqft: row.sqft ?? 0,
			frequency: row.frequency,
			extraIds,
			adjustmentCents: 0
		});
		return {
			id: `${idPrefix}-quote-${slug}`,
			leadId: row.id,
			leadName: row.name,
			breakdown,
			totalCents: breakdown.totalCents,
			explanation: explainQuote(breakdown),
			status,
			isSample: true,
			updatedAt: stamp
		};
	};
	const quotes = [makeQuote("jordan", "jordan", ["fridge"], "draft"), makeQuote("priya", "priya", ["fridge", "oven"], "approved")];
	const bySlug = (slug) => leads.find((item) => item.id.endsWith(`-lead-${slug}`)) ?? null;
	return {
		leads,
		quotes,
		followUps: [
			{
				id: `${idPrefix}-follow-elena`,
				leadId: bySlug("elena")?.id ?? null,
				leadName: "Elena Brooks",
				title: "Second note about the deep clean inquiry",
				dueDate: addDaysISO(today, -1),
				notes: "Sample reminder. Nothing has been sent.",
				done: false,
				isSample: true
			},
			{
				id: `${idPrefix}-follow-amira`,
				leadId: bySlug("amira")?.id ?? null,
				leadName: "Amira Cole",
				title: "Offer Thursday morning",
				dueDate: addDaysISO(today, 1),
				notes: "",
				done: false,
				isSample: true
			},
			{
				id: `${idPrefix}-follow-priya`,
				leadId: bySlug("priya")?.id ?? null,
				leadName: "Priya Shah",
				title: "Confirm the move-out date",
				dueDate: addDaysISO(today, 2),
				notes: "",
				done: false,
				isSample: true
			},
			{
				id: `${idPrefix}-follow-chris`,
				leadId: bySlug("chris")?.id ?? null,
				leadName: "Chris Nguyen",
				title: "Welcome note after the first clean",
				dueDate: addDaysISO(today, -6),
				notes: "Marked done in the sample.",
				done: true,
				isSample: true
			}
		]
	};
}
//#endregion
export { isOverdue as _, LEAD_STATUSES as a, statusLabel as b, TONES as c, centsToInput as d, explainQuote as f, isDue as g, frequencyById as h, FREQUENCIES as i, buildSample as l, formatMoney as m, DEFAULT_SERVICES as n, MESSAGE_TYPES as o, formatDay as p, EMPTY_BUSINESS as r, QUOTE_STATUSES as s, DEFAULT_EXTRAS as t, calculateQuote as u, parseDollarsToCents as v, todayISO as x, sampleBusiness as y };
