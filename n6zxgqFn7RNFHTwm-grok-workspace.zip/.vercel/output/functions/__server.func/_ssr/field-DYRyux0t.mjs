import { Q as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/field-DYRyux0t.js
var import_jsx_runtime = require_jsx_runtime();
function Field({ label, hint, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-1.5 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium text-ink",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted",
				children: hint
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-warn",
				children: error
			}) : null
		]
	});
}
function Notice({ tone = "info", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "status",
		className: tone === "warn" ? "rounded-2xl border border-warn/30 bg-warn-soft px-4 py-3 text-sm text-warn" : "rounded-2xl border border-line bg-accent-soft px-4 py-3 text-sm text-accent",
		children
	});
}
//#endregion
export { Notice as n, Field as t };
