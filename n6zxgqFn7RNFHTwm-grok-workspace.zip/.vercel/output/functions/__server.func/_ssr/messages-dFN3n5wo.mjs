import { t as MessagesPanel } from "./messages-panel-DUnh6H0f.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/messages-dFN3n5wo.js
var SplitComponent = MessagesPanel;
//#endregion
export { SplitComponent as component };
