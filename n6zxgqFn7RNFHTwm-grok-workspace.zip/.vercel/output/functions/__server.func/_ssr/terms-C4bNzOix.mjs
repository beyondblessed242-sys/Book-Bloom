import { Q as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Logo } from "./logo-CQuIplpX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-C4bNzOix.js
var import_jsx_runtime = require_jsx_runtime();
function TermsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-6 font-display text-4xl",
				children: "Terms of Service"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "BookBloom AI is a workspace for a cleaning business to keep leads, prepare estimates from its own rates, and write message drafts." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Creating an account is free and does not start a subscription. The Founder's Plan price is proposed until payments are configured and tested. A success page does not unlock a paid plan." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Message drafts stay in the app until you copy them. BookBloom does not email or text your customers, and it does not confirm bookings." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You are responsible for the customer details you type in. Do not put real customer information in the public demo. The demo uses fictional sample leads and does not save them to an account." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Accounts cannot assign themselves an administrator role. Privileged access is not available." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/privacy",
						className: "text-accent",
						children: "Privacy Policy"
					}) })
				]
			})
		]
	});
}
//#endregion
export { TermsPage as component };
