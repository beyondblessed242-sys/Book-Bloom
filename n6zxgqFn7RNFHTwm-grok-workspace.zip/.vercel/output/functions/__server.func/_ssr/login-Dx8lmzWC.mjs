import { o as __toESM } from "../_runtime.mjs";
import { Q as require_jsx_runtime, S as useNavigate, Z as require_react, b as Link, x as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Field } from "./field-DYRyux0t.mjs";
import { t as Logo } from "./logo-CQuIplpX.mjs";
import { r as createServerFn } from "./ssr.mjs";
import { r as signIn } from "./client-1vAx-gM_.mjs";
import { n as useCurrentUserState } from "./use-current-user-B7Cbrtsy.mjs";
import { t as GROK_PROVIDERS } from "./server-Y5tgn6dX.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B2Izd0c7.mjs";
import { t as authMiddleware } from "./middleware-3dIwojxy.mjs";
import { n as safeNextPath, t as postLoginPath } from "./safe-next-vDyqGKPg.mjs";
import { i as signUpWithEmail, r as signInWithEmail } from "./email-session-zjx0egTi.mjs";
import { r as Route$12 } from "./router-DJKls-_c.mjs";
import { n as passwordError, r as passwordRules, t as PasswordField } from "./password-policy-COkjUCox.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-Dx8lmzWC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Where a verified session may go. The client cannot supply a role. */
var resolveWorkspaceEntry = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => ({ requested: typeof data?.requested === "string" ? data.requested : "/app" })).handler(createSsrRpc("c7435ec54f7c341712c03725e772398516a9caf2ac5625403a27d36e7fcc4ff1"));
function LoginPage() {
	const { next, mode } = Route$12.useSearch();
	const navigate = useNavigate();
	const destination = postLoginPath({ requested: next });
	const { user, isPending } = useCurrentUserState();
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [showConfirm, setShowConfirm] = (0, import_react.useState)(false);
	const [remember, setRemember] = (0, import_react.useState)(true);
	const [accepted, setAccepted] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const creating = mode === "create";
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center text-muted",
		children: "Checking your session…"
	});
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: destination });
	function switchMode(nextMode) {
		setError(null);
		setPassword("");
		setConfirm("");
		navigate({
			to: "/login",
			search: {
				next,
				mode: nextMode
			},
			replace: true
		});
	}
	async function submit(event) {
		event.preventDefault();
		setError(null);
		if (creating && name.trim().length < 2) {
			setError("Add the name you want on the account.");
			return;
		}
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
			setError("Enter a valid email address.");
			return;
		}
		const passwordProblem = passwordError(password);
		if (passwordProblem) {
			setError(passwordProblem);
			return;
		}
		if (creating && confirm !== password) {
			setError("Those passwords do not match.");
			return;
		}
		if (creating && !accepted) {
			setError("Agree to the Terms of Service and Privacy Policy to create an account.");
			return;
		}
		setBusy(true);
		try {
			if (creating) await signUpWithEmail({
				name: name.trim(),
				email: email.trim(),
				password
			});
			else await signInWithEmail({
				email: email.trim(),
				password,
				rememberMe: remember
			});
			const entry = await resolveWorkspaceEntry({ data: { requested: next } });
			window.location.assign(entry.path);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not sign in.");
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto grid min-h-screen max-w-md place-items-center px-4 py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card w-full p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-6 font-display text-4xl leading-tight",
					children: creating ? "Start Growing Your Cleaning Business" : "Welcome Back"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted",
					children: creating ? "Create your free account and discover a smarter way to manage your cleaning business." : "Sign in to your BookBloom AI workspace."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-6 grid gap-4",
					onSubmit: (event) => void submit(event),
					noValidate: true,
					"aria-busy": busy,
					children: [
						creating ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Your name",
							error: void 0,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field-input",
								autoComplete: "name",
								value: name,
								onChange: (event) => setName(event.target.value),
								required: true
							})
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Email address",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field-input",
								type: "email",
								autoComplete: "email",
								inputMode: "email",
								spellCheck: false,
								required: true,
								value: email,
								onChange: (event) => setEmail(event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordField, {
							label: "Password",
							value: password,
							onChange: setPassword,
							autoComplete: creating ? "new-password" : "current-password",
							shown: showPassword,
							onToggle: () => setShowPassword((value) => !value)
						}),
						creating ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "grid gap-1 text-xs",
								"aria-live": "polite",
								children: passwordRules(password).map((rule) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: rule.met ? "text-accent" : "text-muted",
									children: [
										rule.met ? "Met" : "Needed",
										" — ",
										rule.label
									]
								}, rule.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordField, {
								label: "Confirm password",
								value: confirm,
								onChange: setConfirm,
								autoComplete: "new-password",
								shown: showConfirm,
								onToggle: () => setShowConfirm((value) => !value),
								error: confirm && confirm !== password ? "Those passwords do not match." : void 0
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-start gap-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									className: "mt-1 size-4 accent-[var(--color-accent)]",
									checked: accepted,
									onChange: (event) => setAccepted(event.target.checked)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"I agree to the ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/terms",
										className: "text-accent",
										children: "Terms of Service"
									}),
									" and",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/privacy",
										className: "text-accent",
										children: "Privacy Policy"
									}),
									"."
								] })]
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "size-4 accent-[var(--color-accent)]",
								checked: remember,
								onChange: (event) => setRemember(event.target.checked)
							}), "Remember this session on this device"]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-warn",
							role: "alert",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn btn-primary",
							type: "submit",
							disabled: busy,
							children: busy ? creating ? "Creating account…" : "Signing in…" : creating ? "Create Free Account" : "Sign In"
						})
					]
				}),
				creating ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Creating an account does not start a paid subscription. Email verification is not available yet, so no verification message is sent."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/forgot-password",
						className: "text-accent",
						children: "Forgot password?"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-ghost mt-2 px-0",
					onClick: () => switchMode(creating ? "sign-in" : "create"),
					children: creating ? "Already have an account? Sign in" : "New here? Create an account"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-2",
					children: [GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-secondary",
						disabled: busy,
						onClick: () => {
							signIn(provider.providerId, { callbackURL: safeNextPath(next) }).catch((err) => {
								setError(err instanceof Error ? err.message : "Could not start that sign-in.");
							});
						},
						children: ["Continue with ", provider.label]
					}, provider.providerId)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Google and X use the connected sign-in service. They do not start a subscription or grant admin access."
					})]
				})
			]
		})
	});
}
//#endregion
export { LoginPage as component };
