import { o as __toESM } from "../_runtime.mjs";
import { Q as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Field } from "./field-DYRyux0t.mjs";
import { d as centsToInput, f as explainQuote, i as FREQUENCIES, m as formatMoney, s as QUOTE_STATUSES, u as calculateQuote, v as parseDollarsToCents } from "./sample-CJS8dzaP.mjs";
import { r as useWorkspace } from "./workspace-D4AMri1S.mjs";
import { t as Modal } from "./modal-DyY1WL2E.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quotes-panel-D8RoUOKk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QuotesPanel() {
	const workspace = useWorkspace();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)(null);
	const [formError, setFormError] = (0, import_react.useState)(null);
	const preview = (0, import_react.useMemo)(() => {
		if (!form) return null;
		const adjustment = parseDollarsToCents(form.adjustment, true);
		if (adjustment == null) return {
			error: "Adjustment must be a dollar amount.",
			quote: null
		};
		try {
			return {
				error: null,
				quote: calculateQuote({
					services: workspace.business.services,
					extrasCatalog: workspace.business.extras,
					serviceId: form.serviceId,
					rooms: Number(form.rooms || 0),
					sqft: Number(form.sqft || 0),
					frequency: form.frequency,
					extraIds: form.extraIds,
					adjustmentCents: adjustment
				})
			};
		} catch (error) {
			return {
				error: error instanceof Error ? error.message : "Could not calculate.",
				quote: null
			};
		}
	}, [form, workspace.business]);
	function start(existing) {
		const first = workspace.business.services[0];
		const base = existing ? {
			id: existing.id,
			leadId: existing.leadId ?? "",
			serviceId: existing.breakdown.serviceId,
			rooms: String(existing.breakdown.rooms || ""),
			sqft: String(existing.breakdown.sqft || ""),
			frequency: existing.breakdown.frequency,
			extraIds: existing.breakdown.extras.map((item) => item.id),
			adjustment: centsToInput(existing.breakdown.adjustmentCents),
			explanation: existing.explanation,
			explanationTouched: true,
			status: existing.status
		} : {
			leadId: "",
			serviceId: first?.id ?? "",
			rooms: "",
			sqft: "",
			frequency: "one-time",
			extraIds: [],
			adjustment: "0.00",
			explanation: "",
			explanationTouched: false,
			status: "draft"
		};
		setForm(base);
		setFormError(null);
		setOpen(true);
	}
	function update(patch, fromLead = false) {
		setForm((current) => {
			if (!current) return current;
			const next = {
				...current,
				...patch
			};
			if (!fromLead && (patch.serviceId || patch.rooms || patch.sqft || patch.frequency || patch.extraIds || patch.adjustment)) next.explanationTouched = current.explanationTouched;
			return next;
		});
	}
	function applyLead(leadId) {
		const lead = workspace.leads.find((item) => item.id === leadId);
		if (!lead) {
			update({ leadId: "" });
			return;
		}
		update({
			leadId,
			serviceId: lead.serviceId,
			rooms: lead.rooms == null ? "" : String(lead.rooms),
			sqft: lead.sqft == null ? "" : String(lead.sqft),
			frequency: lead.frequency,
			explanationTouched: false
		});
	}
	const explanation = form && preview?.quote ? form.explanationTouched ? form.explanation : explainQuote(preview.quote) : form?.explanation ?? "";
	async function save(event) {
		event.preventDefault();
		if (!form || !preview?.quote) {
			setFormError(preview?.error ?? "Check the estimate.");
			return;
		}
		try {
			await workspace.upsertQuote({
				id: form.id,
				leadId: form.leadId || null,
				serviceId: form.serviceId,
				rooms: preview.quote.rooms,
				sqft: preview.quote.sqft,
				frequency: form.frequency,
				extraIds: form.extraIds,
				adjustmentCents: preview.quote.adjustmentCents,
				explanation,
				status: form.status
			});
			setOpen(false);
		} catch (error) {
			setFormError(error instanceof Error ? error.message : "Could not save that estimate.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl",
					children: "Quotes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-sm text-muted",
					children: "Totals come from your rate card. A model can help explain them later, but it cannot set the price. Recurring discounts apply to the cleaning subtotal. Extras stay full price."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-primary",
					onClick: () => start(),
					children: "New estimate"
				})]
			}),
			workspace.quotes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card p-6 text-sm text-muted",
				children: "No estimates yet. Build one from the rate card in Settings."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3",
				children: workspace.quotes.map((quote) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "card flex w-full flex-wrap items-center justify-between gap-3 p-4 text-left",
					onClick: () => start(quote),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: quote.leadName || "No lead linked"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 block text-sm text-muted",
						children: [
							quote.breakdown.serviceLabel,
							" · ",
							quote.breakdown.frequencyLabel,
							quote.isSample ? " · Sample" : ""
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-display text-2xl tabular-nums",
							children: formatMoney(quote.totalCents)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pill",
							children: QUOTE_STATUSES.find((item) => item.id === quote.status)?.label
						})]
					})]
				}) }, quote.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				title: form?.id ? "Edit estimate" : "New estimate",
				open,
				onClose: () => setOpen(false),
				children: form ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-3",
					onSubmit: (event) => void save(event),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Lead",
							hint: "Optional. Choosing one fills rooms and service.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "field-input",
								value: form.leadId,
								onChange: (event) => applyLead(event.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "No lead"
								}), workspace.leads.map((lead) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: lead.id,
									children: lead.name
								}, lead.id))]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Service",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: "field-input",
									value: form.serviceId,
									onChange: (event) => update({
										serviceId: event.target.value,
										explanationTouched: false
									}),
									children: workspace.business.services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: service.id,
										children: service.label
									}, service.id))
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Frequency",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: "field-input",
									value: form.frequency,
									onChange: (event) => update({
										frequency: event.target.value,
										explanationTouched: false
									}),
									children: FREQUENCIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: item.id,
										children: item.label
									}, item.id))
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Rooms",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field-input",
										inputMode: "numeric",
										value: form.rooms,
										onChange: (event) => update({
											rooms: event.target.value,
											explanationTouched: false
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Square feet",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field-input",
										inputMode: "numeric",
										value: form.sqft,
										onChange: (event) => update({
											sqft: event.target.value,
											explanationTouched: false
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Owner adjustment",
									hint: "Use a minus for a discount you chose.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field-input",
										value: form.adjustment,
										onChange: (event) => update({
											adjustment: event.target.value,
											explanationTouched: false
										})
									})
								})
							]
						}),
						workspace.business.extras.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "text-sm font-medium",
								children: "Approved extras"
							}), workspace.business.extras.map((extra) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-h-11 items-center gap-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: form.extraIds.includes(extra.id),
										onChange: (event) => {
											update({
												extraIds: event.target.checked ? [...form.extraIds, extra.id] : form.extraIds.filter((id) => id !== extra.id),
												explanationTouched: false
											});
										}
									}),
									extra.name,
									" · ",
									formatMoney(extra.cents)
								]
							}, extra.id))]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Status",
							hint: "Marked sent only updates your tracker. You still send the message yourself.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field-input",
								value: form.status,
								onChange: (event) => update({ status: event.target.value }),
								children: QUOTE_STATUSES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item.id,
									children: item.label
								}, item.id))
							})
						}),
						preview?.quote ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-bg p-4 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-3xl tabular-nums",
								children: formatMoney(preview.quote.totalCents)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-2 grid gap-1 text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Base ", formatMoney(preview.quote.baseCents)] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Rooms ", formatMoney(preview.quote.roomsCents)] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Square feet ", formatMoney(preview.quote.sqftCents)] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["After frequency ", formatMoney(preview.quote.frequencyCents)] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Extras ", formatMoney(preview.quote.extrasCents)] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Adjustment ", formatMoney(preview.quote.adjustmentCents)] })
								]
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Explanation",
							hint: "Starts from the math. You can edit the wording. The total above does not change if you rewrite this.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: "field-input",
								value: explanation,
								onChange: (event) => update({
									explanation: event.target.value,
									explanationTouched: true
								})
							})
						}),
						preview?.error || formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-warn",
							children: formError || preview?.error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn btn-primary",
								type: "submit",
								disabled: workspace.saving || !preview?.quote,
								children: workspace.saving ? "Saving…" : "Save estimate"
							}), form.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-warn",
								onClick: () => {
									workspace.deleteQuote(form.id).then(() => setOpen(false)).catch((error) => {
										setFormError(error instanceof Error ? error.message : "Could not delete that estimate.");
									});
								},
								children: "Delete"
							}) : null]
						})
					]
				}) : null
			})
		]
	});
}
//#endregion
export { QuotesPanel as t };
