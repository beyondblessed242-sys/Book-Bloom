import { t as authClient } from "./client-1vAx-gM_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/email-session-zjx0egTi.js
var BEARER_KEY = "grok-auth.bearer-token";
/**
* Email/password runs against this app's own auth API. In the embedded preview,
* cookies are partitioned, so the session token from `set-auth-token` is stored
* the same way the OAuth popup stores its bearer. Deployed cookie auth still
* works because credentials are included.
*/
async function signUpWithEmail(input) {
	await finish(await fetch("/api/auth/sign-up/email", {
		method: "POST",
		headers: { "content-type": "application/json" },
		credentials: "include",
		body: JSON.stringify(input)
	}));
}
async function signInWithEmail(input) {
	await finish(await fetch("/api/auth/sign-in/email", {
		method: "POST",
		headers: { "content-type": "application/json" },
		credentials: "include",
		body: JSON.stringify({
			email: input.email,
			password: input.password,
			rememberMe: input.rememberMe !== false
		})
	}));
}
async function finish(response) {
	const payload = await response.json().catch(() => null);
	if (!response.ok) throw new Error(payload?.message || "Could not sign in. Check the email and password.");
	const token = response.headers.get("set-auth-token") || payload?.token || null;
	if (token) try {
		window.sessionStorage.setItem(BEARER_KEY, token);
	} catch {}
	await authClient.getSession();
}
async function requestPasswordReset(email) {
	const response = await fetch("/api/auth/request-password-reset", {
		method: "POST",
		headers: { "content-type": "application/json" },
		credentials: "include",
		body: JSON.stringify({
			email,
			redirectTo: "/reset-password"
		})
	});
	const payload = await response.json().catch(() => null);
	if (!response.ok) {
		const message = payload?.message ?? "";
		if (/reset password isn't enabled|not enabled/i.test(message)) return "unavailable";
		throw new Error("Could not start a password reset. Your password was not changed.");
	}
	return "accepted";
}
async function resetPasswordWithToken(input) {
	const response = await fetch("/api/auth/reset-password", {
		method: "POST",
		headers: { "content-type": "application/json" },
		credentials: "include",
		body: JSON.stringify({
			token: input.token,
			newPassword: input.newPassword
		})
	});
	const payload = await response.json().catch(() => null);
	if (!response.ok) throw new Error(payload?.message || "This reset link is not valid. Your password was not changed.");
}
//#endregion
export { signUpWithEmail as i, resetPasswordWithToken as n, signInWithEmail as r, requestPasswordReset as t };
