import { o as __toESM } from "../_runtime.mjs";
import { Q as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as DemoWorkspace } from "./workspace-D4AMri1S.mjs";
import { n as Shell } from "./shell-CNEazurf.mjs";
import { t as OverviewPanel } from "./overview-panel-CxxLa52F.mjs";
import { t as BillingPanel } from "./billing-panel-BZuCTGZA.mjs";
import { t as FollowUpsPanel } from "./followups-panel-C36pQesE.mjs";
import { t as LeadsPanel } from "./leads-panel-C0LCHvVd.mjs";
import { t as MessagesPanel } from "./messages-panel-DUnh6H0f.mjs";
import { t as QuotesPanel } from "./quotes-panel-D8RoUOKk.mjs";
import { t as SettingsPanel } from "./settings-panel-CkY6vWnv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/demo-Cn4F6ZRS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DemoPage() {
	const [section, setSection] = (0, import_react.useState)("overview");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoWorkspace, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		current: section,
		onNavigate: setSection,
		children: [
			section === "overview" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewPanel, {}) : null,
			section === "leads" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadsPanel, {}) : null,
			section === "quotes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuotesPanel, {}) : null,
			section === "messages" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessagesPanel, {}) : null,
			section === "follow-ups" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FollowUpsPanel, {}) : null,
			section === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPanel, {}) : null,
			section === "billing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BillingPanel, {}) : null
		]
	}) });
}
//#endregion
export { DemoPage as component };
