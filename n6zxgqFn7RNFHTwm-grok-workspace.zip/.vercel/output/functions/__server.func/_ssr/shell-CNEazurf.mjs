import { o as __toESM } from "../_runtime.mjs";
import { Q as require_jsx_runtime, Z as require_react, b as Link, x as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Notice } from "./field-DYRyux0t.mjs";
import { t as Logo } from "./logo-CQuIplpX.mjs";
import { i as signOut } from "./client-1vAx-gM_.mjs";
import { t as useCurrentUser } from "./use-current-user-B7Cbrtsy.mjs";
import { a as hasGateSessionMarker } from "./server-Y5tgn6dX.mjs";
import { r as useWorkspace } from "./workspace-D4AMri1S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-CNEazurf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var SECTIONS = [
	{
		id: "overview",
		label: "Overview",
		href: "/app"
	},
	{
		id: "leads",
		label: "Leads",
		href: "/app/leads"
	},
	{
		id: "quotes",
		label: "Quotes",
		href: "/app/quotes"
	},
	{
		id: "messages",
		label: "Messages",
		href: "/app/messages"
	},
	{
		id: "follow-ups",
		label: "Follow-ups",
		href: "/app/follow-ups"
	},
	{
		id: "settings",
		label: "Settings",
		href: "/app/settings"
	},
	{
		id: "billing",
		label: "Billing",
		href: "/app/billing"
	}
];
function sectionFromPath(pathname) {
	return SECTIONS.find((item) => item.href !== "/app" && pathname.startsWith(item.href))?.id ?? "overview";
}
function Shell({ current, onNavigate, children }) {
	const workspace = useWorkspace();
	const company = workspace.business.companyName || "Your cleaning business";
	const hasSample = workspace.mode === "demo" || workspace.leads.some((lead) => lead.isSample) || workspace.business.sampleLoaded;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "border-b border-line bg-surface",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { to: workspace.mode === "demo" ? "/demo" : "/app" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-sm text-muted sm:inline",
						children: company
					})]
				}), workspace.mode === "live" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/login",
					search: {
						next: "/app",
						mode: "create"
					},
					className: "btn btn-secondary",
					children: "Create account"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				"aria-label": "Workspace",
				className: "mx-auto flex max-w-6xl gap-1 overflow-x-auto px-3 pb-3",
				children: SECTIONS.map((item) => {
					const active = item.id === current;
					const className = active ? "btn btn-primary" : "btn btn-ghost";
					if (onNavigate) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className,
						onClick: () => onNavigate(item.id),
						"aria-current": active ? "page" : void 0,
						children: item.label
					}, item.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.href,
						className,
						"aria-current": active ? "page" : void 0,
						children: item.label
					}, item.id);
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto grid max-w-6xl gap-4 px-4 py-6",
			children: [
				workspace.mode === "demo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Sample workspace. These people are fictional. Nothing is saved, and nothing is emailed or texted." }) : hasSample ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Sample records are marked. They are fictional and stay inside your account until you remove them." }) : null,
				workspace.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Notice, {
					tone: "warn",
					children: [
						workspace.error,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "underline",
							onClick: () => void workspace.reload(),
							children: "Retry"
						})
					]
				}) : null,
				workspace.loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Loading your workspace…"
				}) : children
			]
		})]
	});
}
//#endregion
export { Shell as n, sectionFromPath as r, RedirectToSignIn as t };
