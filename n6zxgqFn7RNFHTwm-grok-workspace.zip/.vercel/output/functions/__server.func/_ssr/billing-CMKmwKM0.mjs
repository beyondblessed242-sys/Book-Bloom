import { C as useSearch, Q as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as BillingPanel } from "./billing-panel-BZuCTGZA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/billing-CMKmwKM0.js
var import_jsx_runtime = require_jsx_runtime();
function BillingRoute() {
	const search = useSearch({ strict: false });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BillingPanel, { checkout: search.checkout === "success" });
}
//#endregion
export { BillingRoute as component };
