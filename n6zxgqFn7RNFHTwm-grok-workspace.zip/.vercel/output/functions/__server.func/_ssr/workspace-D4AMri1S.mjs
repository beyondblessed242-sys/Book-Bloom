import { o as __toESM } from "../_runtime.mjs";
import { Q as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as createServerFn } from "./ssr.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B2Izd0c7.mjs";
import { t as authMiddleware } from "./middleware-3dIwojxy.mjs";
import { f as explainQuote, h as frequencyById, l as buildSample, m as formatMoney, r as EMPTY_BUSINESS, u as calculateQuote, y as sampleBusiness } from "./sample-CJS8dzaP.mjs";
import { a as followDoneSchema, c as idSchema, d as quoteSchema, f as quoteStatusSchema, i as firstName, l as leadSchema, m as stripMoney, n as clip, o as followUpSchema, p as renderDemoDraft, r as draftSchema, t as businessSchema, u as parseInput } from "./messages-DV8Zo0Sx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workspace-D4AMri1S.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var getWorkspace = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("c82b597bbd9cc90d6bf96a0a7d8c4d14056c09c0302a2c4c6a1135093ef60613"));
var saveBusiness = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(businessSchema, data)).handler(createSsrRpc("1a98d9eee6bc99a2419c8cd632bcba146914a6ea03cfc76d41438745c8020a42"));
var upsertLead = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(leadSchema, data)).handler(createSsrRpc("3623226e5ae01fc1b59ba9b759beaf7d1618e1052ddd33db9bd71efda6e0f66f"));
var deleteLead = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(idSchema, data)).handler(createSsrRpc("162e458f6479eb479b6d0cf26174458a3808874196dfff11497cab5f865ba258"));
var upsertQuote = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(quoteSchema, data)).handler(createSsrRpc("f0b5a6fcd336d55b830850c6319bb57589846022a86c73136c699a6450ccf9dc"));
var setQuoteStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(quoteStatusSchema, data)).handler(createSsrRpc("619ae72a601b457eb8168e58189eadf66f55ac98feeba65d0d296cdbb7cb2697"));
var deleteQuote = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(idSchema, data)).handler(createSsrRpc("d9624f7ae0eafa2caf97250931c539226be1c23606898c75cc9a9985ae606eee"));
var upsertFollowUp = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(followUpSchema, data)).handler(createSsrRpc("0f1657fc913af99d613b5c24df3192d8e0c0cc5ab0e512d898a934629a987202"));
var setFollowUpDone = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(followDoneSchema, data)).handler(createSsrRpc("212e562c1ca707a9e7e291cad9c5124d9a2041c6a8aa833259a19438daa76999"));
var deleteFollowUp = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(idSchema, data)).handler(createSsrRpc("ef7a0f84010da00437e66ce7ba4352d5f48429fb68323b328c4ec22d8367c4ce"));
var loadSample = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("43ddd4f79ee908b8cb30aed615d606305463d0207f9dab0fc595b31d2e7aa3f1"));
var clearSample = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("4634d38f18e89d65076c65439681d8c21cbd73db85547cfe69c0bdf398851ce6"));
var draftMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => parseInput(draftSchema, data)).handler(createSsrRpc("6954df5632041f916f4c9c439770f517820354401cd696d868b2886e64d261e2"));
var WorkspaceContext = (0, import_react.createContext)(null);
function useWorkspace() {
	const value = (0, import_react.useContext)(WorkspaceContext);
	if (!value) throw new Error("Open a workspace before using this screen.");
	return value;
}
function errorText(error) {
	if (error instanceof Error && error.message) return error.message;
	return "Something went wrong. Please try again.";
}
function LiveWorkspace({ children }) {
	const [data, setData] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	async function load() {
		setError(null);
		const next = await getWorkspace();
		setData(next);
	}
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		getWorkspace().then((next) => {
			if (!cancelled) setData(next);
		}).catch((err) => {
			if (!cancelled) setError(errorText(err));
		}).finally(() => {
			if (!cancelled) setLoading(false);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	async function commit(work) {
		setSaving(true);
		setError(null);
		try {
			const next = await work();
			setData(next);
		} catch (err) {
			const message = errorText(err);
			setError(message);
			if (message === "Unauthorized" && typeof window !== "undefined") window.location.href = "/login";
			throw err;
		} finally {
			setSaving(false);
		}
	}
	const api = {
		business: data?.business ?? emptyFallback(),
		leads: data?.leads ?? [],
		quotes: data?.quotes ?? [],
		followUps: data?.followUps ?? [],
		aiLive: data?.aiLive ?? false,
		mode: "live",
		loading,
		saving,
		error,
		clearError: () => setError(null),
		reload: () => load(),
		saveBusiness: (input) => commit(() => saveBusiness({ data: input })),
		upsertLead: (input) => commit(() => upsertLead({ data: input })),
		deleteLead: (id) => commit(() => deleteLead({ data: { id } })),
		upsertQuote: (input) => commit(() => upsertQuote({ data: input })),
		setQuoteStatus: (id, status) => commit(() => setQuoteStatus({ data: {
			id,
			status
		} })),
		deleteQuote: (id) => commit(() => deleteQuote({ data: { id } })),
		upsertFollowUp: (input) => commit(() => upsertFollowUp({ data: input })),
		setFollowUpDone: (id, done) => commit(() => setFollowUpDone({ data: {
			id,
			done
		} })),
		deleteFollowUp: (id) => commit(() => deleteFollowUp({ data: { id } })),
		draftMessage: (leadId, messageType) => draftMessage({ data: {
			leadId,
			messageType
		} }),
		loadSample: () => commit(() => loadSample()),
		clearSample: () => commit(() => clearSample())
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkspaceContext.Provider, {
		value: api,
		children
	});
}
function emptyFallback() {
	return EMPTY_BUSINESS;
}
function DemoWorkspace({ children }) {
	const seeded = sampleBusiness();
	const starter = buildSample(seeded, "demo");
	const [business, setBusiness] = (0, import_react.useState)(seeded);
	const [leads, setLeads] = (0, import_react.useState)(starter.leads);
	const [quotes, setQuotes] = (0, import_react.useState)(starter.quotes);
	const [followUps, setFollowUps] = (0, import_react.useState)(starter.followUps);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	async function run(work) {
		setSaving(true);
		setError(null);
		try {
			return work();
		} catch (err) {
			setError(errorText(err));
			throw err;
		} finally {
			setSaving(false);
		}
	}
	const api = {
		business,
		leads,
		quotes,
		followUps,
		aiLive: false,
		mode: "demo",
		loading: false,
		saving,
		error,
		clearError: () => setError(null),
		reload: async () => void 0,
		saveBusiness: (input) => run(() => {
			const data = parseInput(businessSchema, input);
			setBusiness((current) => ({
				...current,
				...data,
				sampleLoaded: current.sampleLoaded
			}));
		}),
		upsertLead: (input) => run(() => {
			const data = parseInput(leadSchema, input);
			const service = business.services.find((item) => item.id === data.serviceId);
			if (!service) throw new Error("Choose a service from your rate card.");
			const next = {
				id: data.id ?? crypto.randomUUID(),
				name: data.name,
				email: data.email,
				phone: data.phone,
				serviceId: service.id,
				serviceLabel: service.label,
				rooms: data.rooms,
				sqft: data.sqft,
				frequency: data.frequency,
				notes: data.notes,
				status: data.status,
				lastContact: data.lastContact || null,
				isSample: data.id ? leads.find((item) => item.id === data.id)?.isSample ?? false : false,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			};
			setLeads((current) => {
				return current.some((item) => item.id === next.id) ? current.map((item) => item.id === next.id ? next : item) : [next, ...current];
			});
		}),
		deleteLead: (id) => run(() => {
			setLeads((current) => current.filter((item) => item.id !== id));
			setQuotes((current) => current.map((item) => item.leadId === id ? {
				...item,
				leadId: null,
				leadName: null
			} : item));
			setFollowUps((current) => current.filter((item) => item.leadId !== id));
		}),
		upsertQuote: (input) => run(() => {
			const data = parseInput(quoteSchema, input);
			const breakdown = calculateQuote({
				services: business.services,
				extrasCatalog: business.extras,
				serviceId: data.serviceId,
				rooms: data.rooms,
				sqft: data.sqft,
				frequency: data.frequency,
				extraIds: data.extraIds,
				adjustmentCents: data.adjustmentCents
			});
			const lead = data.leadId ? leads.find((item) => item.id === data.leadId) : void 0;
			if (data.leadId && !lead) throw new Error("That lead is not in this sample workspace.");
			const next = {
				id: data.id ?? crypto.randomUUID(),
				leadId: lead?.id ?? null,
				leadName: lead?.name ?? null,
				breakdown,
				totalCents: breakdown.totalCents,
				explanation: data.explanation.trim() || explainQuote(breakdown),
				status: data.status,
				isSample: data.id ? quotes.find((item) => item.id === data.id)?.isSample ?? true : false,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			};
			setQuotes((current) => {
				return current.some((item) => item.id === next.id) ? current.map((item) => item.id === next.id ? next : item) : [next, ...current];
			});
		}),
		setQuoteStatus: (id, status) => run(() => {
			setQuotes((current) => current.map((item) => item.id === id ? {
				...item,
				status
			} : item));
		}),
		deleteQuote: (id) => run(() => setQuotes((current) => current.filter((item) => item.id !== id))),
		upsertFollowUp: (input) => run(() => {
			const data = parseInput(followUpSchema, input);
			const lead = data.leadId ? leads.find((item) => item.id === data.leadId) : void 0;
			if (data.leadId && !lead) throw new Error("That lead is not in this sample workspace.");
			const next = {
				id: data.id ?? crypto.randomUUID(),
				leadId: lead?.id ?? null,
				leadName: lead?.name ?? null,
				title: data.title,
				dueDate: data.dueDate,
				notes: data.notes,
				done: data.id ? followUps.find((item) => item.id === data.id)?.done ?? false : false,
				isSample: data.id ? followUps.find((item) => item.id === data.id)?.isSample ?? true : false
			};
			setFollowUps((current) => {
				return current.some((item) => item.id === next.id) ? current.map((item) => item.id === next.id ? next : item) : [next, ...current];
			});
		}),
		setFollowUpDone: (id, done) => run(() => setFollowUps((current) => current.map((item) => item.id === id ? {
			...item,
			done
		} : item))),
		deleteFollowUp: (id) => run(() => setFollowUps((current) => current.filter((item) => item.id !== id))),
		draftMessage: (leadId, messageType) => run(() => {
			const lead = leads.find((item) => item.id === leadId);
			if (!lead) throw new Error("Choose a lead from this sample workspace.");
			const quote = quotes.find((item) => item.leadId === lead.id);
			return {
				mode: "demo",
				text: renderDemoDraft({
					messageType,
					tone: business.tone,
					companyName: clip(stripMoney(business.companyName), 80),
					serviceArea: clip(stripMoney(business.serviceArea), 120),
					hours: clip(stripMoney(business.hours), 160),
					customerFirstName: firstName(lead.name),
					serviceLabel: clip(stripMoney(lead.serviceLabel), 60),
					frequencyLabel: frequencyById(lead.frequency)?.label ?? "One-time",
					notes: clip(stripMoney(lead.notes), 400),
					quoteTotalLabel: quote ? formatMoney(quote.totalCents) : null,
					quoteStatus: quote?.status ?? null
				}),
				label: "Demo draft — not a live model",
				notice: "Sample workspace. This is a template filled with fictional details, not a live model. Nothing is saved or sent."
			};
		}),
		loadSample: () => run(() => {
			const profile = business.companyName.trim() ? business : sampleBusiness();
			const next = buildSample(profile, "demo");
			if (!business.companyName.trim()) setBusiness(profile);
			setLeads(next.leads);
			setQuotes(next.quotes);
			setFollowUps(next.followUps);
		}),
		clearSample: () => run(() => {
			setLeads((current) => current.filter((item) => !item.isSample));
			setQuotes((current) => current.filter((item) => !item.isSample));
			setFollowUps((current) => current.filter((item) => !item.isSample));
			setBusiness((current) => ({
				...current,
				sampleLoaded: false
			}));
		})
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkspaceContext.Provider, {
		value: api,
		children
	});
}
//#endregion
export { LiveWorkspace as n, useWorkspace as r, DemoWorkspace as t };
