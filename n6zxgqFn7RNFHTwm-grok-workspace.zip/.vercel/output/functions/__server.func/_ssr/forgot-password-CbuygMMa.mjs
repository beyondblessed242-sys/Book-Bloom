import { o as __toESM } from "../_runtime.mjs";
import { Q as require_jsx_runtime, Z as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Notice, t as Field } from "./field-DYRyux0t.mjs";
import { t as Logo } from "./logo-CQuIplpX.mjs";
import { t as requestPasswordReset } from "./email-session-zjx0egTi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/forgot-password-CbuygMMa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ForgotPasswordPage() {
	const [email, setEmail] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [result, setResult] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		setError(null);
		setResult(null);
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
			setError("Enter a valid email address.");
			return;
		}
		setBusy(true);
		try {
			setResult(await requestPasswordReset(email.trim()));
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not start a password reset.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto grid min-h-screen max-w-md place-items-center px-4 py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card w-full p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-6 font-display text-4xl leading-tight",
					children: "Reset your password"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted",
					children: "Enter the email on your BookBloom account. This does not reveal whether that email is registered, and it does not start a subscription."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-6 grid gap-4",
					onSubmit: (event) => void submit(event),
					noValidate: true,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Email address",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field-input",
								type: "email",
								autoComplete: "email",
								required: true,
								value: email,
								onChange: (event) => setEmail(event.target.value)
							})
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-warn",
							role: "alert",
							children: error
						}) : null,
						result === "unavailable" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
							tone: "warn",
							children: "Password reset email is not available yet. No message was sent and your password was not changed. Sign in if you still know it, or use Google or X if that is how you created the account."
						}) : null,
						result === "accepted" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "If this email has an account, a reset link was sent. The link expires and does not start a subscription." }) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn btn-primary",
							type: "submit",
							disabled: busy,
							children: busy ? "Checking…" : "Send reset link"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						search: {
							next: "/app",
							mode: "sign-in"
						},
						className: "text-accent",
						children: "Back to sign in"
					})
				})
			]
		})
	});
}
//#endregion
export { ForgotPasswordPage as component };
