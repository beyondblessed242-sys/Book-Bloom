import { o as __toESM } from "../_runtime.mjs";
import { Q as require_jsx_runtime, Z as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as LEAD_STATUSES, f as explainQuote, i as FREQUENCIES, l as buildSample, m as formatMoney, n as DEFAULT_SERVICES, t as DEFAULT_EXTRAS, u as calculateQuote, y as sampleBusiness } from "./sample-CJS8dzaP.mjs";
import { t as foundersPriceLabel } from "./pricing-BvRl-Hpu.mjs";
import { t as SiteHeader } from "./site-header-CWiOJRzR.mjs";
import { a as ReceiptText, c as Check, i as Sparkles, l as CalendarClock, o as MessageSquareText, r as Store, s as ChevronDown, t as Users, u as Calculator } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CWrpBKOA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FRIDGE = DEFAULT_EXTRAS.find((item) => item.id === "fridge");
var FEATURES = [
	{
		title: "Lead Management",
		body: "Keep customer inquiries, contact details, and booking opportunities organized in one place.",
		icon: Users
	},
	{
		title: "Smart Estimates",
		body: "Create professional cleaning estimates using your own services, rates, and add-ons.",
		icon: ReceiptText
	},
	{
		title: "Follow-Up Tracker",
		body: "See which clients need a response so promising inquiries don't get overlooked.",
		icon: CalendarClock
	},
	{
		title: "AI Message Assistant",
		body: "Prepare polished, personalized replies and follow-ups in your business's voice.",
		icon: MessageSquareText
	}
];
var STEPS = [
	{
		n: "01",
		title: "Set Up Your Business",
		body: "Add your services, pricing, and business details so BookBloom can personalize your experience.",
		icon: Store
	},
	{
		n: "02",
		title: "Create Smart Estimates",
		body: "Turn customer inquiries into professional cleaning estimates using your own rates and services.",
		icon: Calculator
	},
	{
		n: "03",
		title: "Let AI Do the Writing",
		body: "Generate personalized customer replies and follow-up messages in seconds, ready for your review and approval.",
		icon: Sparkles
	}
];
var PLAN_FEATURES = [
	"Organized customer leads and inquiries",
	"Professional estimates using your rates",
	"AI-generated customer response drafts",
	"Follow-up reminders and tracking",
	"Personalized business profile",
	"Access to all currently available core dashboard features"
];
var FAQS = [
	{
		q: "What is BookBloom AI?",
		a: "BookBloom is an AI-powered workspace for cleaning businesses. It helps you organize leads, prepare professional estimates, create customer message drafts, and keep track of follow-ups."
	},
	{
		q: "Do I need technical experience to use BookBloom?",
		a: "No. BookBloom is designed to be simple and easy to use, even if you're new to AI tools."
	},
	{
		q: "How does BookBloom create cleaning estimates?",
		a: "You enter your services, rates, and available extras. BookBloom calculates estimates based on those saved prices, and you can review the results before sharing them with customers."
	},
	{
		q: "Does BookBloom automatically contact customers?",
		a: "Not yet. BookBloom prepares customer replies and follow-up messages for you to review, copy, and send. Automated messaging is a feature being considered for a future release."
	},
	{
		q: "Can I customize the AI messages?",
		a: "Yes. You can set your business's preferred communication style and edit generated drafts before sending them."
	},
	{
		q: "How much does BookBloom cost?",
		a: `The proposed Founder's Plan is ${foundersPriceLabel()} per month. Subscriptions are not yet active, and joining early access does not initiate a charge.`
	},
	{
		q: "Is my business information private?",
		a: "BookBloom is designed to separate business workspaces and restrict access to authorized users. These privacy and access controls must be tested before accepting real customer information."
	},
	{
		q: "Can I try BookBloom before subscribing?",
		a: "Yes. Explore the free demo to see the available features using sample business information."
	}
];
function HomePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto grid max-w-6xl items-center gap-10 px-4 py-14 md:grid-cols-2 md:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-[0.14em] text-accent sm:text-sm",
						children: "YOUR AI-POWERED CLEANING BUSINESS ASSISTANT"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-5xl leading-[1.05] text-ink md:text-6xl",
						children: "More bookings. Less busywork."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-xl text-lg text-muted",
						children: "Manage leads, create accurate estimates, and prepare professional customer follow-ups with one simple AI-powered workspace. Spend less time on admin and more time growing your cleaning business."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/demo",
							className: "btn btn-primary",
							children: "Try Free Demo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/login",
							search: {
								next: "/app/billing",
								mode: "create"
							},
							className: "btn btn-secondary",
							children: [
								"Start for ",
								foundersPriceLabel(),
								"/month"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xl text-sm text-muted",
						children: "The demo is free and uses sample data. $49/month is a proposed price. Starting an account does not charge a card or turn on a paid plan."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EstimatePreview, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "product",
				className: "border-y border-line bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-6xl px-4 py-16 md:py-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-2xl text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-4xl leading-tight md:text-5xl",
								children: "Meet Your New AI Business Assistant"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-lg text-muted",
								children: "Less time managing paperwork and messages. More time focusing on your customers."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-12 grid gap-4 md:grid-cols-2 md:gap-5",
							children: FEATURES.map((feature) => {
								const Icon = feature.icon;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "feature-card card p-6 sm:p-7",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-11 place-items-center rounded-2xl bg-accent-soft text-accent",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
												className: "size-5",
												strokeWidth: 1.75,
												"aria-hidden": "true"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-5 text-lg font-medium",
											children: feature.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 max-w-md text-sm leading-relaxed text-muted",
											children: feature.body
										})
									]
								}, feature.title);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-10 flex flex-col items-center gap-3 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/demo",
								className: "btn btn-primary",
								children: "Try Free Demo"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-md text-sm text-muted",
								children: "The demo uses sample leads. Replies are drafts you review and send yourself. Nothing is emailed or texted for you."
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "how",
				className: "mx-auto max-w-6xl px-4 py-16 md:py-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-2xl text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl leading-tight md:text-5xl",
							children: "How BookBloom Works"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-lg text-muted",
							children: "Running your cleaning business just got easier. Get organized, create estimates, and prepare customer messages in three simple steps."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-12 grid items-stretch gap-4 md:grid-cols-3 md:gap-5",
						children: STEPS.map((step) => {
							const Icon = step.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "feature-card card flex h-full flex-col p-6 sm:p-7",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-11 place-items-center rounded-2xl bg-accent-soft text-accent",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-5",
											strokeWidth: 1.75,
											"aria-hidden": "true"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-5 font-display text-2xl text-accent",
										children: step.n
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-2 text-lg font-medium",
										children: step.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted",
										children: step.body
									})
								]
							}, step.n);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 flex flex-col items-center gap-3 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/demo",
							className: "btn btn-primary",
							children: "Try Free Demo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-md text-sm text-muted",
							children: "Messages are drafts for you to review and send. BookBloom does not send them or confirm bookings."
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-6xl px-4 pb-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex flex-wrap items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "Dashboard preview"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Fictional leads. Filter the pipeline, then open the full demo to edit them."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/demo",
						className: "btn btn-secondary",
						children: "Open the demo"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PipelinePreview, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "pricing",
				className: "border-y border-line bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-6xl px-4 py-16 md:py-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-2xl text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-[0.14em] text-accent sm:text-sm",
								children: "SIMPLE, TRANSPARENT PRICING"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-4xl leading-tight md:text-5xl",
								children: "A Smarter Way to Run Your Cleaning Business"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-lg text-muted",
								children: "Everything you need to stay organized, impress potential customers, and keep your business moving."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "feature-card card mx-auto mt-12 max-w-lg p-6 sm:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-3xl",
									children: "Founder's Plan"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "pill",
									children: "Early Access"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-5 font-display text-5xl tabular-nums",
								children: [foundersPriceLabel(), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-2xl text-muted",
									children: "/month"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted",
								children: "One simple workspace to manage customers, estimates, and AI-powered communication."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-6 grid gap-3",
								children: PLAN_FEATURES.map((feature) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-accent-soft text-accent",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "size-3.5",
											strokeWidth: 2.5,
											"aria-hidden": "true"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: feature })]
								}, feature))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/login",
								search: {
									next: "/app/billing",
									mode: "create"
								},
								className: "btn btn-primary mt-8 w-full",
								children: "Join Early Access"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-center text-sm text-muted",
								children: "Early access — subscription payments are not yet enabled."
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "faq",
				className: "mx-auto max-w-3xl px-4 py-16 md:py-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-2xl text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-[0.14em] text-accent sm:text-sm",
								children: "FREQUENTLY ASKED QUESTIONS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-4xl leading-tight md:text-5xl",
								children: "Questions? We've Got Answers."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-lg text-muted",
								children: "Everything you need to know about making BookBloom part of your cleaning business."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/demo",
							className: "btn btn-primary",
							children: "Try Free Demo"
						})
					})
				]
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
			className: "border-t border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-8 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "BookBloom AI · a workspace for cleaning businesses." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/demo",
					children: "Try the sample workspace"
				})]
			})
		})
	] });
}
function FaqList() {
	const [open, setOpen] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-10 grid gap-3",
		children: FAQS.map((item, index) => {
			const isOpen = open === index;
			const panelId = `faq-panel-${index}`;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "card overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-full items-center justify-between gap-4 px-5 py-4 text-left text-base font-medium",
					"aria-expanded": isOpen,
					"aria-controls": panelId,
					onClick: () => setOpen(isOpen ? null : index),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.q }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
						className: `faq-chevron size-5 shrink-0 text-accent ${isOpen ? "rotate-180" : ""}`,
						"aria-hidden": "true"
					})]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: panelId,
					className: "faq-panel",
					"data-open": isOpen,
					role: "region",
					"aria-hidden": !isOpen,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-5 pb-5 text-sm leading-relaxed text-muted",
						children: item.a
					}) })
				})]
			}, item.q);
		})
	});
}
function customerNote(quote) {
	return [
		`Thank you for asking about a ${quote.serviceLabel.toLowerCase()}.`,
		explainQuote(quote),
		"This sample quote uses illustrative demo rates. Nothing has been booked or billed."
	].join(" ");
}
function quoteDocument(quote, note) {
	const lines = [
		"BookBloom AI — sample customer quote",
		"Illustrative demo pricing. Not an invoice. Not billed.",
		"",
		`Service: ${quote.serviceLabel}`,
		`Frequency: ${quote.frequencyLabel}`,
		`Rooms: ${quote.rooms}`,
		`Base: ${formatMoney(quote.baseCents)}`
	];
	if (quote.rooms > 0) lines.push(`Rooms: ${quote.rooms} × ${formatMoney(quote.perRoomCents)} = ${formatMoney(quote.roomsCents)}`);
	if (quote.sqft > 0) lines.push(`Square feet: ${quote.sqft.toLocaleString("en-US")} × ${formatMoney(quote.perSqftCents)} = ${formatMoney(quote.sqftCents)}`);
	if (quote.multiplierBps !== 1e4) lines.push(`Cleaning portion after frequency: ${formatMoney(quote.frequencyCents)}`);
	for (const extra of quote.extras) lines.push(`${extra.name}: ${formatMoney(extra.cents)}`);
	lines.push("", `Total: ${formatMoney(quote.totalCents)}`, "", note.trim());
	return lines.join("\n");
}
function EstimatePreview() {
	const [serviceId, setServiceId] = (0, import_react.useState)("standard");
	const [rooms, setRooms] = (0, import_react.useState)(3);
	const [frequency, setFrequency] = (0, import_react.useState)("biweekly");
	const [fridge, setFridge] = (0, import_react.useState)(false);
	const [quoteOpen, setQuoteOpen] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	const [noteEdited, setNoteEdited] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [copyError, setCopyError] = (0, import_react.useState)(null);
	const quote = (0, import_react.useMemo)(() => calculateQuote({
		services: DEFAULT_SERVICES,
		extrasCatalog: DEFAULT_EXTRAS,
		serviceId,
		rooms,
		sqft: 0,
		frequency,
		extraIds: fridge && FRIDGE ? [FRIDGE.id] : [],
		adjustmentCents: 0
	}), [
		serviceId,
		rooms,
		frequency,
		fridge
	]);
	const seededNote = (0, import_react.useMemo)(() => customerNote(quote), [quote]);
	(0, import_react.useEffect)(() => {
		if (quoteOpen && !noteEdited) setNote(seededNote);
	}, [
		quoteOpen,
		noteEdited,
		seededNote
	]);
	function generateQuote() {
		setQuoteOpen(true);
		setCopied(false);
		setCopyError(null);
		if (!noteEdited) setNote(seededNote);
		window.setTimeout(() => {
			document.getElementById("sample-quote")?.scrollIntoView({
				behavior: "smooth",
				block: "nearest"
			});
		}, 40);
	}
	async function copyQuote() {
		setCopyError(null);
		try {
			await navigator.clipboard.writeText(quoteDocument(quote, note));
			setCopied(true);
		} catch {
			setCopied(false);
			setCopyError("Clipboard is unavailable. Select the note and copy it yourself. Nothing was sent.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card p-5 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pill",
				children: "Illustrative demo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 font-display text-3xl leading-tight",
				children: "Create an Estimate in Seconds"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "See how BookBloom turns your service rates into clear, professional estimates."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-xs font-medium tracking-wide text-accent",
				children: "Sample rate card · not your prices and not a live invoice"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-display text-4xl tabular-nums",
				children: formatMoney(quote.totalCents)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					quote.serviceLabel,
					" · ",
					quote.frequencyLabel
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-sm",
						children: ["Service", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field-input",
							value: serviceId,
							onChange: (event) => setServiceId(event.target.value),
							children: DEFAULT_SERVICES.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: service.id,
								children: service.label
							}, service.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Rooms"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-secondary",
									onClick: () => setRooms((value) => Math.max(0, value - 1)),
									"aria-label": "Fewer rooms",
									children: "−"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-6 text-center tabular-nums",
									children: rooms
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-secondary",
									onClick: () => setRooms((value) => Math.min(12, value + 1)),
									"aria-label": "More rooms",
									children: "+"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-sm",
						children: ["Frequency", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field-input",
							value: frequency,
							onChange: (event) => setFrequency(event.target.value),
							children: FREQUENCIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.label
							}, item.id))
						})]
					}),
					FRIDGE ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: fridge ? "btn btn-primary" : "btn btn-secondary",
						"aria-pressed": fridge,
						onClick: () => setFridge((value) => !value),
						children: `${fridge ? "Added" : "Add"} ${FRIDGE.name} · ${formatMoney(FRIDGE.cents)}`
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary mt-5 w-full",
				onClick: generateQuote,
				children: "Generate Customer Quote"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-muted",
				children: "The total updates from the sample rate card. Weekly and biweekly rates discount the cleaning portion only. Add-ons stay full price."
			}),
			quoteOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				id: "sample-quote",
				className: "rise-in mt-5 rounded-2xl border border-line bg-bg p-4",
				"aria-live": "polite",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-wide text-accent",
							children: "Demo quote · illustrative pricing"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1 font-display text-2xl",
							children: "Customer quote"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl tabular-nums",
							children: formatMoney(quote.totalCents)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteLine, {
								label: "Service",
								value: quote.serviceLabel
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteLine, {
								label: "Frequency",
								value: quote.frequencyLabel
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteLine, {
								label: "Base",
								value: formatMoney(quote.baseCents)
							}),
							quote.rooms > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteLine, {
								label: "Rooms",
								value: `${quote.rooms} × ${formatMoney(quote.perRoomCents)} = ${formatMoney(quote.roomsCents)}`
							}) : null,
							quote.multiplierBps !== 1e4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteLine, {
								label: "After frequency",
								value: formatMoney(quote.frequencyCents)
							}) : null,
							quote.extras.map((extra) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteLine, {
								label: extra.name,
								value: formatMoney(extra.cents)
							}, extra.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteLine, {
								label: "Total",
								value: formatMoney(quote.totalCents)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-4 grid gap-1 text-sm",
						children: ["Quote note", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "field-input",
							value: note,
							onChange: (event) => {
								setNote(event.target.value);
								setNoteEdited(true);
								setCopied(false);
							},
							"aria-describedby": "quote-note-hint"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						id: "quote-note-hint",
						className: "mt-2 text-xs text-muted",
						children: noteEdited ? "The total still comes from the calculator. Your note stays as you edited it." : "The note follows the calculator. Edit it if you want different wording. The price does not change when you edit the words."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-secondary",
							onClick: () => void copyQuote(),
							children: copied ? "Copied" : "Copy quote"
						}), noteEdited ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-ghost",
							onClick: () => {
								setNoteEdited(false);
								setNote(seededNote);
								setCopied(false);
							},
							children: "Refresh note from total"
						}) : null]
					}),
					copyError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-warn",
						role: "alert",
						children: copyError
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted",
						children: "Demo mode. This quote is not saved, not emailed, and not a paid booking."
					})
				]
			}) : null
		]
	});
}
function QuoteLine({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between gap-4 border-b border-line pb-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "text-right font-medium tabular-nums",
			children: value
		})]
	});
}
function PipelinePreview() {
	const [status, setStatus] = (0, import_react.useState)("all");
	const leads = (0, import_react.useMemo)(() => buildSample(sampleBusiness(), "home").leads, []);
	const visible = status === "all" ? leads : leads.filter((lead) => lead.status === status);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2 overflow-x-auto pb-3",
			role: "tablist",
			"aria-label": "Filter sample leads",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
				active: status === "all",
				onClick: () => setStatus("all"),
				children: "All"
			}), LEAD_STATUSES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
				active: status === item.id,
				onClick: () => setStatus(item.id),
				children: item.label
			}, item.id))]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid gap-2",
			children: visible.map((lead) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-wrap items-center justify-between gap-2 rounded-xl bg-bg px-3 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: lead.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: [
						lead.serviceLabel,
						" · ",
						lead.status
					]
				})]
			}, lead.id))
		})]
	});
}
function FilterChip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: active ? "btn btn-primary" : "btn btn-ghost",
		onClick,
		"aria-pressed": active,
		children
	});
}
var SplitComponent = HomePage;
//#endregion
export { SplitComponent as component };
