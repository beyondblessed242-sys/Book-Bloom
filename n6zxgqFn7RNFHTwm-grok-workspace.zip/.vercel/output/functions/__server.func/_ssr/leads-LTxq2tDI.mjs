import { t as LeadsPanel } from "./leads-panel-C0LCHvVd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/leads-LTxq2tDI.js
var SplitComponent = LeadsPanel;
//#endregion
export { SplitComponent as component };
