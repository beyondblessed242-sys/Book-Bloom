import { o as __toESM } from "../_runtime.mjs";
import { Q as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Notice, t as Field } from "./field-DYRyux0t.mjs";
import { t as useCurrentUser } from "./use-current-user-B7Cbrtsy.mjs";
import { c as TONES, d as centsToInput, v as parseDollarsToCents } from "./sample-CJS8dzaP.mjs";
import { r as useWorkspace } from "./workspace-D4AMri1S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-panel-CkY6vWnv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function fromBusiness(business) {
	return {
		companyName: business.companyName,
		ownerName: business.ownerName,
		email: business.email,
		phone: business.phone,
		serviceArea: business.serviceArea,
		hours: business.hours,
		tone: business.tone,
		services: business.services.map((item) => ({
			id: item.id,
			label: item.label,
			base: centsToInput(item.baseCents),
			perRoom: centsToInput(item.perRoomCents),
			perSqft: centsToInput(item.perSqftCents)
		})),
		extras: business.extras.map((item) => ({
			id: item.id,
			name: item.name,
			price: centsToInput(item.cents)
		}))
	};
}
function nextId(label, taken) {
	const base = label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 24) || "item";
	let id = base;
	let n = 2;
	while (taken.includes(id)) id = `${base.slice(0, 20)}-${n++}`;
	return id;
}
function SettingsPanel() {
	const workspace = useWorkspace();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsForm, {}, JSON.stringify(workspace.business));
}
function SettingsForm() {
	const workspace = useWorkspace();
	const user = useCurrentUser();
	const [form, setForm] = (0, import_react.useState)(() => fromBusiness(workspace.business));
	const [error, setError] = (0, import_react.useState)(null);
	const [saved, setSaved] = (0, import_react.useState)(false);
	async function save(event) {
		event.preventDefault();
		setSaved(false);
		const services = [];
		for (const service of form.services) {
			const baseCents = parseDollarsToCents(service.base);
			const perRoomCents = parseDollarsToCents(service.perRoom);
			const perSqftCents = parseDollarsToCents(service.perSqft);
			if (baseCents == null || perRoomCents == null || perSqftCents == null) {
				setError("Rate amounts need to look like 89.00 or 0.08.");
				return;
			}
			services.push({
				id: service.id,
				label: service.label,
				baseCents,
				perRoomCents,
				perSqftCents
			});
		}
		const extras = [];
		for (const extra of form.extras) {
			const cents = parseDollarsToCents(extra.price);
			if (cents == null) {
				setError("Extra prices need to look like 35.00.");
				return;
			}
			extras.push({
				id: extra.id,
				name: extra.name,
				cents
			});
		}
		try {
			await workspace.saveBusiness({
				...form,
				tone: form.tone,
				services,
				extras
			});
			setError(null);
			setSaved(true);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not save settings.");
		}
	}
	function patchService(index, patch) {
		setForm((current) => ({
			...current,
			services: current.services.map((item, i) => i === index ? {
				...item,
				...patch
			} : item)
		}));
	}
	function patchExtra(index, patch) {
		setForm((current) => ({
			...current,
			extras: current.extras.map((item, i) => i === index ? {
				...item,
				...patch
			} : item)
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "grid gap-5",
		onSubmit: (event) => void save(event),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Settings"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-2xl text-sm text-muted",
				children: "Suggested rates are a starting point, not a promise of what you should charge. Set any rate to 0.00 if you do not use that measure. Both rooms and square feet are added when a quote includes both."
			})] }),
			workspace.mode === "live" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Notice, { children: [
				"Signed in as ",
				user?.primaryEmail ?? user?.displayName ?? "your account",
				". That sign-in address is separate from the public contact email below."
			] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card grid gap-3 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Business profile"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Company name",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field-input",
									value: form.companyName,
									onChange: (event) => setForm({
										...form,
										companyName: event.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Your name",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field-input",
									value: form.ownerName,
									onChange: (event) => setForm({
										...form,
										ownerName: event.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Public contact email",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field-input",
									value: form.email,
									onChange: (event) => setForm({
										...form,
										email: event.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Phone",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field-input",
									value: form.phone,
									onChange: (event) => setForm({
										...form,
										phone: event.target.value
									})
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Service area",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field-input",
							value: form.serviceArea,
							onChange: (event) => setForm({
								...form,
								serviceArea: event.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Business hours",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field-input",
							value: form.hours,
							onChange: (event) => setForm({
								...form,
								hours: event.target.value
							})
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card grid gap-3 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Response tone"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2",
					children: TONES.map((tone) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-11 items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "radio",
							name: "tone",
							checked: form.tone === tone.id,
							onChange: () => setForm({
								...form,
								tone: tone.id
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-medium",
								children: [tone.label, "."]
							}),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: tone.hint
							})
						] })]
					}, tone.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card grid gap-4 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Rate card"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-secondary",
						onClick: () => setForm((current) => ({
							...current,
							services: [...current.services, {
								id: nextId("service", current.services.map((item) => item.id)),
								label: "New service",
								base: "0.00",
								perRoom: "0.00",
								perSqft: "0.00"
							}]
						})),
						children: "Add service"
					})]
				}), form.services.map((service, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2 rounded-2xl border border-line p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Service name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field-input",
								value: service.label,
								onChange: (event) => patchService(index, { label: event.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Base ($)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field-input",
										value: service.base,
										onChange: (event) => patchService(index, { base: event.target.value })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Per room ($)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field-input",
										value: service.perRoom,
										onChange: (event) => patchService(index, { perRoom: event.target.value })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Per sq ft ($)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field-input",
										value: service.perSqft,
										onChange: (event) => patchService(index, { perSqft: event.target.value })
									})
								})
							]
						}),
						form.services.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-ghost w-fit",
							onClick: () => setForm((current) => ({
								...current,
								services: current.services.filter((_, i) => i !== index)
							})),
							children: "Remove service"
						}) : null
					]
				}, service.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card grid gap-4 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl",
							children: "Extras"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-secondary",
							onClick: () => setForm((current) => ({
								...current,
								extras: [...current.extras, {
									id: nextId("extra", current.extras.map((item) => item.id)),
									name: "New extra",
									price: "0.00"
								}]
							})),
							children: "Add extra"
						})]
					}),
					form.extras.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "No extras. Quotes will only use the service rates."
					}) : null,
					form.extras.map((extra, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-[1fr_10rem_auto] sm:items-end",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Name",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field-input",
									value: extra.name,
									onChange: (event) => patchExtra(index, { name: event.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Price ($)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field-input",
									value: extra.price,
									onChange: (event) => patchExtra(index, { price: event.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost",
								onClick: () => setForm((current) => ({
									...current,
									extras: current.extras.filter((_, i) => i !== index)
								})),
								children: "Remove"
							})
						]
					}, extra.id))
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-warn",
				role: "alert",
				children: error
			}) : null,
			saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-accent",
				role: "status",
				children: "Saved."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn btn-primary w-fit",
				type: "submit",
				disabled: workspace.saving,
				children: workspace.saving ? "Saving…" : "Save settings"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card grid gap-3 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Sample workspace"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Loads fictional leads for Harbor & Pine Cleaning, all using example.com addresses. If your company name is still blank, the sample profile fills it too. Your own leads are kept. Removing the sample deletes only rows marked sample."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-secondary",
							onClick: () => void workspace.loadSample(),
							children: "Load sample data"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-ghost",
							onClick: () => void workspace.clearSample(),
							children: "Remove sample data"
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { SettingsPanel as t };
