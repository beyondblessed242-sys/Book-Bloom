//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-nW3Gep4I.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/app",
			"/demo",
			"/forgot-password",
			"/login",
			"/privacy",
			"/reset-password",
			"/terms",
			"/billing/success",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-C2WrNttr.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/createClientRpc-Z3UMeyk5.js",
			"/assets/preload-helper-DCDadVuo.js",
			"/assets/useSelector-Bd78rxvp.js",
			"/assets/link-CL0hNoh8.js",
			"/assets/invariant-DEEwAagU.js",
			"/assets/root-DLTE-HSj.js",
			"/assets/lazyRouteComponent-5jN7t-7o.js",
			"/assets/useNavigate-DTpPOMD-.js",
			"/assets/jsx-runtime-BtH0gOTJ.js",
			"/assets/useMatch-b_ohVFZw.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C2WrNttr.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CBVEqEH1.js",
			"/assets/sample-DcNfNIav.js",
			"/assets/pricing-CkovAgEZ.js",
			"/assets/site-header-BvJ1QX_a.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DxCX5MXk.js",
			"/assets/field-CMGxsKlo.js",
			"/assets/logo-BYiX4iik.js"
		]
	},
	"/app": {
		filePath: "/workspace/src/routes/app.tsx",
		children: [
			"/app/billing",
			"/app/follow-ups",
			"/app/leads",
			"/app/messages",
			"/app/quotes",
			"/app/settings",
			"/app/"
		],
		preloads: [
			"/assets/app-ClcqehL_.js",
			"/assets/shell-C26seuqx.js",
			"/assets/use-current-user-DQB55Vmc.js",
			"/assets/workspace-Dz4uwCQ2.js"
		]
	},
	"/demo": {
		filePath: "/workspace/src/routes/demo.tsx",
		children: void 0,
		preloads: [
			"/assets/demo-CT2LLL0b.js",
			"/assets/shell-C26seuqx.js",
			"/assets/workspace-Dz4uwCQ2.js",
			"/assets/billing-panel-COnd76Ca.js",
			"/assets/followups-panel-DQoz49PG.js",
			"/assets/overview-panel-CWiWJLJg.js",
			"/assets/leads-panel-givu0RV6.js",
			"/assets/messages-panel-CsPZ9f0k.js",
			"/assets/quotes-panel-DMN8VjAq.js",
			"/assets/settings-panel-DtIE-ob-.js"
		]
	},
	"/forgot-password": {
		filePath: "/workspace/src/routes/forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-password-CVLoasFh.js",
			"/assets/field-CMGxsKlo.js",
			"/assets/logo-BYiX4iik.js",
			"/assets/email-session-BqviAugc.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-Ded1iElG.js",
			"/assets/middleware-wy95joUI.js",
			"/assets/client-cLw6edTc.js",
			"/assets/field-CMGxsKlo.js",
			"/assets/logo-BYiX4iik.js",
			"/assets/use-current-user-DQB55Vmc.js",
			"/assets/email-session-BqviAugc.js",
			"/assets/password-policy-DqO0xHD8.js"
		]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-ChevFp7B.js", "/assets/logo-BYiX4iik.js"]
	},
	"/reset-password": {
		filePath: "/workspace/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-C9AKOkic.js",
			"/assets/field-CMGxsKlo.js",
			"/assets/logo-BYiX4iik.js",
			"/assets/email-session-BqviAugc.js",
			"/assets/password-policy-DqO0xHD8.js"
		]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-BUJhl0sQ.js", "/assets/logo-BYiX4iik.js"]
	},
	"/app/billing": {
		filePath: "/workspace/src/routes/app/billing.tsx",
		children: void 0,
		preloads: [
			"/assets/billing-C3jChZVn.js",
			"/assets/useSearch-CVFpoLF9.js",
			"/assets/billing-panel-COnd76Ca.js"
		]
	},
	"/app/follow-ups": {
		filePath: "/workspace/src/routes/app/follow-ups.tsx",
		children: void 0,
		preloads: ["/assets/follow-ups-QypEk8LL.js", "/assets/followups-panel-DQoz49PG.js"]
	},
	"/app/leads": {
		filePath: "/workspace/src/routes/app/leads.tsx",
		children: void 0,
		preloads: ["/assets/leads-zPEZiHfs.js", "/assets/leads-panel-givu0RV6.js"]
	},
	"/app/messages": {
		filePath: "/workspace/src/routes/app/messages.tsx",
		children: void 0,
		preloads: ["/assets/messages-C6FSXKOB.js", "/assets/messages-panel-CsPZ9f0k.js"]
	},
	"/app/quotes": {
		filePath: "/workspace/src/routes/app/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-tOLll9Yu.js", "/assets/quotes-panel-DMN8VjAq.js"]
	},
	"/app/settings": {
		filePath: "/workspace/src/routes/app/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-NDwnSZOg.js", "/assets/settings-panel-DtIE-ob-.js"]
	},
	"/billing/success": {
		filePath: "/workspace/src/routes/billing.success.tsx",
		children: void 0,
		preloads: [
			"/assets/billing.success-qyEEbtPs.js",
			"/assets/field-CMGxsKlo.js",
			"/assets/site-header-BvJ1QX_a.js"
		]
	},
	"/app/": {
		filePath: "/workspace/src/routes/app/index.tsx",
		children: void 0,
		preloads: ["/assets/app-BVyA6Kz5.js", "/assets/overview-panel-CWiWJLJg.js"]
	}
} });
//#endregion
export { tsrStartManifest };
