import { addDaysISO, todayISO } from "./dates.ts";
import { explainQuote, calculateQuote } from "./quotes.ts";
import {
  DEFAULT_EXTRAS,
  DEFAULT_SERVICES,
  type Business,
  type FollowUp,
  type Lead,
  type Quote,
} from "./types.ts";

export const SAMPLE_COMPANY = "Harbor & Pine Cleaning";

export function sampleBusiness(): Business {
  return {
    id: "sample-business",
    companyName: SAMPLE_COMPANY,
    ownerName: "A. Parker",
    email: "hello@harborpine.example",
    phone: "(404) 555-0148",
    serviceArea: "Decatur and East Atlanta",
    hours: "Mon–Fri 8:00–17:00, Sat 9:00–13:00",
    tone: "warm",
    services: DEFAULT_SERVICES.map((item) => ({ ...item })),
    extras: DEFAULT_EXTRAS.map((item) => ({ ...item })),
    sampleLoaded: true,
  };
}

export function buildSample(business: Business, idPrefix: string, now = new Date()) {
  const today = todayISO(now);
  const stamp = new Date(now).toISOString();
  const lead = (
    slug: string,
    partial: Omit<Lead, "id" | "isSample" | "updatedAt" | "serviceLabel"> & { serviceId: string },
  ): Lead => {
    const service = business.services.find((item) => item.id === partial.serviceId);
    return {
      ...partial,
      id: `${idPrefix}-lead-${slug}`,
      serviceLabel: service?.label ?? partial.serviceId,
      isSample: true,
      updatedAt: stamp,
    };
  };

  const leads: Lead[] = [
    lead("amira", {
      name: "Amira Cole",
      email: "amira.cole@example.com",
      phone: "(404) 555-0172",
      serviceId: "standard",
      rooms: 3,
      sqft: null,
      frequency: "biweekly",
      notes: "Asked about Thursday mornings. Has a small dog.",
      status: "new",
      lastContact: addDaysISO(today, -1),
    }),
    lead("jordan", {
      name: "Jordan Hale",
      email: "jordan.hale@example.com",
      phone: "(404) 555-0119",
      serviceId: "deep",
      rooms: null,
      sqft: 1800,
      frequency: "one-time",
      notes: "Kitchen is the priority. They will move photos before arrival.",
      status: "contacted",
      lastContact: addDaysISO(today, -3),
    }),
    lead("priya", {
      name: "Priya Shah",
      email: "priya.shah@example.com",
      phone: "(404) 555-0164",
      serviceId: "move-out",
      rooms: 4,
      sqft: 2100,
      frequency: "one-time",
      notes: "Keys with the building manager after 4pm.",
      status: "quoted",
      lastContact: addDaysISO(today, -2),
    }),
    lead("chris", {
      name: "Chris Nguyen",
      email: "chris.nguyen@example.com",
      phone: "(404) 555-0188",
      serviceId: "standard",
      rooms: 2,
      sqft: null,
      frequency: "weekly",
      notes: "Standing Thursday visit. Do not store a gate code here.",
      status: "booked",
      lastContact: addDaysISO(today, -7),
    }),
    lead("elena", {
      name: "Elena Brooks",
      email: "elena.brooks@example.com",
      phone: "(404) 555-0133",
      serviceId: "deep",
      rooms: 3,
      sqft: 1400,
      frequency: "one-time",
      notes: "Sent a form last week and has not replied.",
      status: "new",
      lastContact: addDaysISO(today, -10),
    }),
  ];

  const makeQuote = (
    slug: string,
    leadSlug: string,
    extraIds: string[],
    status: Quote["status"],
  ): Quote => {
    const row = leads.find((item) => item.id.endsWith(`-lead-${leadSlug}`));
    if (!row) throw new Error("Sample lead missing");
    const breakdown = calculateQuote({
      services: business.services,
      extrasCatalog: business.extras,
      serviceId: row.serviceId,
      rooms: row.rooms ?? 0,
      sqft: row.sqft ?? 0,
      frequency: row.frequency,
      extraIds,
      adjustmentCents: 0,
    });
    return {
      id: `${idPrefix}-quote-${slug}`,
      leadId: row.id,
      leadName: row.name,
      breakdown,
      totalCents: breakdown.totalCents,
      explanation: explainQuote(breakdown),
      status,
      isSample: true,
      updatedAt: stamp,
    };
  };

  const quotes: Quote[] = [
    makeQuote("jordan", "jordan", ["fridge"], "draft"),
    makeQuote("priya", "priya", ["fridge", "oven"], "approved"),
  ];

  const bySlug = (slug: string) => leads.find((item) => item.id.endsWith(`-lead-${slug}`)) ?? null;

  const followUps: FollowUp[] = [
    {
      id: `${idPrefix}-follow-elena`,
      leadId: bySlug("elena")?.id ?? null,
      leadName: "Elena Brooks",
      title: "Second note about the deep clean inquiry",
      dueDate: addDaysISO(today, -1),
      notes: "Sample reminder. Nothing has been sent.",
      done: false,
      isSample: true,
    },
    {
      id: `${idPrefix}-follow-amira`,
      leadId: bySlug("amira")?.id ?? null,
      leadName: "Amira Cole",
      title: "Offer Thursday morning",
      dueDate: addDaysISO(today, 1),
      notes: "",
      done: false,
      isSample: true,
    },
    {
      id: `${idPrefix}-follow-priya`,
      leadId: bySlug("priya")?.id ?? null,
      leadName: "Priya Shah",
      title: "Confirm the move-out date",
      dueDate: addDaysISO(today, 2),
      notes: "",
      done: false,
      isSample: true,
    },
    {
      id: `${idPrefix}-follow-chris`,
      leadId: bySlug("chris")?.id ?? null,
      leadName: "Chris Nguyen",
      title: "Welcome note after the first clean",
      dueDate: addDaysISO(today, -6),
      notes: "Marked done in the sample.",
      done: true,
      isSample: true,
    },
  ];

  return { leads, quotes, followUps };
}
