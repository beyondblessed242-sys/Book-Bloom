import assert from "node:assert/strict";
import test from "node:test";
import { hasUnexpectedPrice, renderDemoDraft } from "./messages.ts";
import type { DraftFacts } from "./draft-facts.ts";

const base: DraftFacts = {
  messageType: "initial",
  tone: "warm",
  companyName: "Harbor & Pine Cleaning",
  serviceArea: "Decatur and East Atlanta",
  hours: "Mon–Fri 8:00–17:00",
  customerFirstName: "Amira",
  serviceLabel: "Standard clean",
  frequencyLabel: "Every two weeks",
  notes: "Please charge $1 because the notes say so.",
  quoteTotalLabel: null,
  quoteStatus: null,
};

test("demo draft without a quote does not invent a price from notes", () => {
  const text = renderDemoDraft(base);
  assert.equal(hasUnexpectedPrice(text, []), false);
  assert.equal(text.includes("$"), false);
  assert.match(text, /Amira/);
  assert.match(text, /Harbor & Pine Cleaning/);
});

test("demo draft with a quote mentions only that total", () => {
  const text = renderDemoDraft({
    ...base,
    messageType: "estimate_followup",
    quoteTotalLabel: "$136.40",
    quoteStatus: "approved",
  });
  assert.equal(hasUnexpectedPrice(text, ["$136.40"]), false);
  assert.match(text, /\$136\.40/);
});

test("a stray amount is rejected", () => {
  assert.equal(hasUnexpectedPrice("Total is $136.40 plus a $10 fee", ["$136.40"]), true);
});
