import assert from "node:assert/strict";
import test from "node:test";
import { passwordError, passwordRules } from "./password-policy.ts";

test("password rules require length, a letter, and a number", () => {
  assert.equal(passwordError("short1"), "Password needs: at least 8 characters.");
  assert.equal(passwordError("longenough"), "Password needs: at least one number.");
  assert.equal(passwordError("12345678"), "Password needs: at least one letter.");
  assert.equal(passwordError("Bookbloom1"), null);
  assert.equal(passwordRules("").every((rule) => !rule.met), true);
});
