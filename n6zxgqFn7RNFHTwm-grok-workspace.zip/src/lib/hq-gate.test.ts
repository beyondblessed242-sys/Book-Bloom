import assert from "node:assert/strict";
import test from "node:test";
import { decideHqAccess } from "./hq-gate.ts";

const now = Date.parse("2026-11-05T05:00:00Z");

test("email is not an owner credential", () => {
  const denied = decideHqAccess({
    assignedRole: null,
    twoFactorEnabled: true,
    mfaProofExpiresAt: "2026-11-05T05:10:00Z",
    sessionMatches: true,
    now,
  });
  assert.equal(denied.allowed, false);
  assert.equal(denied.needsCode, false);
});

test("a different administrator role does not open HQ", () => {
  const denied = decideHqAccess({
    assignedRole: "super_admin",
    twoFactorEnabled: true,
    mfaProofExpiresAt: "2026-11-05T05:10:00Z",
    sessionMatches: true,
    now,
  });
  assert.equal(denied.allowed, false);
});

test("the owner role without this session's authenticator proof stays closed", () => {
  const pending = decideHqAccess({
    assignedRole: "platform_owner",
    twoFactorEnabled: true,
    mfaProofExpiresAt: "2026-11-05T05:10:00Z",
    sessionMatches: false,
    now,
  });
  assert.equal(pending.allowed, false);
  assert.equal(pending.needsCode, true);
});

test("HQ opens only for this session after the role and a fresh authenticator proof", () => {
  const open = decideHqAccess({
    assignedRole: "platform_owner",
    twoFactorEnabled: true,
    mfaProofExpiresAt: "2026-11-05T05:10:00Z",
    sessionMatches: true,
    now,
  });
  assert.equal(open.allowed, true);
});
