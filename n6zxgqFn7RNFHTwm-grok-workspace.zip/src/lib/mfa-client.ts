import { getBearerToken } from "@/lib/auth/client";

function headers(): HeadersInit {
  const value: Record<string, string> = { "content-type": "application/json" };
  const token = getBearerToken();
  if (token) value.Authorization = `Bearer ${token}`;
  return value;
}

export async function startAuthenticator(password: string): Promise<{ totpURI: string; backupCodes: string[] }> {
  const response = await fetch("/api/auth/two-factor/enable", {
    method: "POST",
    headers: headers(),
    credentials: "include",
    body: JSON.stringify({ password }),
  });
  const payload = (await response.json().catch(() => null)) as { message?: string; totpURI?: string; backupCodes?: string[] } | null;
  if (!response.ok || !payload?.totpURI || !payload.backupCodes) {
    throw new Error(payload?.message || "Authenticator setup did not start.");
  }
  return { totpURI: payload.totpURI, backupCodes: payload.backupCodes };
}

export async function confirmAuthenticator(code: string): Promise<void> {
  const response = await fetch("/api/auth/two-factor/verify-totp", {
    method: "POST",
    headers: headers(),
    credentials: "include",
    body: JSON.stringify({ code }),
  });
  if (!response.ok) {
    const payload = (await response.json().catch(() => null)) as { message?: string } | null;
    throw new Error(payload?.message || "That authenticator code was not accepted.");
  }
}
