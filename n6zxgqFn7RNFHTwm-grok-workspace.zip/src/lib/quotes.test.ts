import assert from "node:assert/strict";
import test from "node:test";
import { calculateQuote, explainQuote } from "./quotes.ts";
import { DEFAULT_EXTRAS, DEFAULT_SERVICES } from "./types.ts";
import { formatMoney } from "./money.ts";

test("biweekly standard clean discounts the cleaning portion only", () => {
  const quote = calculateQuote({
    services: DEFAULT_SERVICES,
    extrasCatalog: DEFAULT_EXTRAS,
    serviceId: "standard",
    rooms: 3,
    sqft: 0,
    frequency: "biweekly",
    extraIds: [],
    adjustmentCents: 0,
  });
  assert.equal(quote.cleaningCents, 15500);
  assert.equal(quote.frequencyCents, 13640);
  assert.equal(quote.totalCents, 13640);
});

test("square footage and extras use the rate card, not a free-typed price", () => {
  const quote = calculateQuote({
    services: DEFAULT_SERVICES,
    extrasCatalog: DEFAULT_EXTRAS,
    serviceId: "deep",
    rooms: 0,
    sqft: 1800,
    frequency: "one-time",
    extraIds: ["fridge", "not-a-real-extra"],
    adjustmentCents: -500,
  });
  assert.equal(quote.cleaningCents, 40100);
  assert.equal(quote.extrasCents, 3500);
  assert.equal(quote.totalCents, 43100);
  assert.equal(quote.extras.length, 1);
});

test("explanation only mentions amounts that the calculator produced", () => {
  const quote = calculateQuote({
    services: DEFAULT_SERVICES,
    extrasCatalog: DEFAULT_EXTRAS,
    serviceId: "move-out",
    rooms: 4,
    sqft: 2100,
    frequency: "one-time",
    extraIds: ["oven"],
    adjustmentCents: 0,
  });
  const text = explainQuote(quote);
  assert.match(text, new RegExp(formatMoney(quote.totalCents).replace("$", "\\$")));
  assert.doesNotMatch(text, /\$1\b/);
  assert.equal(text.includes(formatMoney(quote.totalCents)), true);
});

test("unknown service is rejected", () => {
  assert.throws(
    () =>
      calculateQuote({
        services: DEFAULT_SERVICES,
        extrasCatalog: DEFAULT_EXTRAS,
        serviceId: "windows-only",
        rooms: 1,
        sqft: 0,
        frequency: "weekly",
        extraIds: [],
        adjustmentCents: 0,
      }),
    /rate card/,
  );
});
