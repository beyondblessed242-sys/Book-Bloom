export const TONES = [
  { id: "warm", label: "Warm", hint: "Friendly and plain-spoken" },
  { id: "professional", label: "Professional", hint: "Polite and composed" },
  { id: "concise", label: "Concise", hint: "Short, no extra lines" },
] as const;

export type Tone = (typeof TONES)[number]["id"];

export const FREQUENCIES = [
  { id: "one-time", label: "One-time", bps: 10000 },
  { id: "weekly", label: "Weekly", bps: 8000 },
  { id: "biweekly", label: "Every two weeks", bps: 8800 },
  { id: "monthly", label: "Monthly", bps: 9500 },
] as const;

export type FrequencyId = (typeof FREQUENCIES)[number]["id"];

export const LEAD_STATUSES = [
  { id: "new", label: "New" },
  { id: "contacted", label: "Contacted" },
  { id: "quoted", label: "Quoted" },
  { id: "booked", label: "Booked" },
  { id: "lost", label: "Lost" },
] as const;

export type LeadStatus = (typeof LEAD_STATUSES)[number]["id"];

export const QUOTE_STATUSES = [
  { id: "draft", label: "Draft" },
  { id: "approved", label: "Approved" },
  { id: "sent", label: "Marked sent" },
] as const;

export type QuoteStatus = (typeof QUOTE_STATUSES)[number]["id"];

export const MESSAGE_TYPES = [
  { id: "initial", label: "Initial response", hint: "First reply to a new inquiry" },
  { id: "estimate_followup", label: "Estimate follow-up", hint: "After a quote is on file" },
  { id: "unanswered", label: "Unanswered inquiry", hint: "A nudge when they went quiet" },
  { id: "thank_you", label: "Thank-you", hint: "After a booking or a visit" },
] as const;

export type MessageType = (typeof MESSAGE_TYPES)[number]["id"];

export type ServiceRate = {
  id: string;
  label: string;
  baseCents: number;
  perRoomCents: number;
  perSqftCents: number;
};

export type Extra = {
  id: string;
  name: string;
  cents: number;
};

export type Business = {
  id: string;
  companyName: string;
  ownerName: string;
  email: string;
  phone: string;
  serviceArea: string;
  hours: string;
  tone: Tone;
  services: ServiceRate[];
  extras: Extra[];
  sampleLoaded: boolean;
};

export type Lead = {
  id: string;
  name: string;
  email: string;
  phone: string;
  serviceId: string;
  serviceLabel: string;
  rooms: number | null;
  sqft: number | null;
  frequency: FrequencyId;
  notes: string;
  status: LeadStatus;
  lastContact: string | null;
  isSample: boolean;
  updatedAt: string;
};

export type QuoteExtraLine = { id: string; name: string; cents: number };

export type QuoteBreakdown = {
  serviceId: string;
  serviceLabel: string;
  rooms: number;
  sqft: number;
  perRoomCents: number;
  perSqftCents: number;
  frequency: FrequencyId;
  frequencyLabel: string;
  multiplierBps: number;
  baseCents: number;
  roomsCents: number;
  sqftCents: number;
  cleaningCents: number;
  frequencyCents: number;
  extras: QuoteExtraLine[];
  extrasCents: number;
  adjustmentCents: number;
  totalCents: number;
};

export type Quote = {
  id: string;
  leadId: string | null;
  leadName: string | null;
  breakdown: QuoteBreakdown;
  totalCents: number;
  explanation: string;
  status: QuoteStatus;
  isSample: boolean;
  updatedAt: string;
};

export type FollowUp = {
  id: string;
  leadId: string | null;
  leadName: string | null;
  title: string;
  dueDate: string;
  notes: string;
  done: boolean;
  isSample: boolean;
};

export type DraftResult = {
  mode: "demo" | "grok";
  text: string;
  label: string;
  notice: string;
};

export const DEFAULT_SERVICES: ServiceRate[] = [
  { id: "standard", label: "Standard clean", baseCents: 8900, perRoomCents: 2200, perSqftCents: 8 },
  { id: "deep", label: "Deep clean", baseCents: 14900, perRoomCents: 3500, perSqftCents: 14 },
  { id: "move-out", label: "Move-out clean", baseCents: 19900, perRoomCents: 4500, perSqftCents: 18 },
];

export const DEFAULT_EXTRAS: Extra[] = [
  { id: "fridge", name: "Inside fridge", cents: 3500 },
  { id: "oven", name: "Inside oven", cents: 3000 },
  { id: "windows", name: "Interior windows", cents: 4000 },
  { id: "laundry", name: "Laundry fold", cents: 2500 },
];

export const EMPTY_BUSINESS: Business = {
  id: "pending",
  companyName: "",
  ownerName: "",
  email: "",
  phone: "",
  serviceArea: "",
  hours: "Mon–Fri 8:00–17:00",
  tone: "warm",
  services: DEFAULT_SERVICES,
  extras: DEFAULT_EXTRAS,
  sampleLoaded: false,
};

export function frequencyById(id: string) {
  return FREQUENCIES.find((item) => item.id === id) ?? null;
}

export function statusLabel(id: string): string {
  return LEAD_STATUSES.find((item) => item.id === id)?.label ?? id;
}
