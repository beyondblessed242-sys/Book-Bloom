import assert from "node:assert/strict";
import test from "node:test";
import { decodeProfilePhoto, initials, profileSchema, rejectRoleField } from "./account.ts";

test("profile settings cannot carry a role", () => {
  assert.throws(() => rejectRoleField({ displayName: "Nia", role: "super_admin" }), /cannot change an account role/);
  assert.doesNotThrow(() => rejectRoleField({ displayName: "Nia Brooks" }));
});

test("profile validation keeps personal fields only", () => {
  const parsed = profileSchema.parse({
    firstName: "Nia",
    lastName: "Brooks",
    displayName: "Nia Brooks",
    phone: "(404) 555-0100",
    timezone: "America/New_York",
  });
  assert.equal(parsed.displayName, "Nia Brooks");
  assert.equal(profileSchema.safeParse({ ...parsed, timezone: "Mars/Base" }).success, false);
});

test("initials come from the saved name", () => {
  assert.equal(initials("Nia Brooks", "nia@example.com"), "NB");
  assert.equal(initials("", "nia@example.com"), "NI");
});

test("profile photos must match an allowed image type", () => {
  const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3, 4, 5, 6, 7, 8]).toString("base64");
  const decoded = decodeProfilePhoto(`data:image/png;base64,${png}`);
  assert.equal(decoded.mime, "image/png");
  assert.throws(() => decodeProfilePhoto(`data:image/png;base64,${Buffer.from("not-a-png-file!!").toString("base64")}`), /not a PNG/);
});
