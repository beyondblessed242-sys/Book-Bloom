import { type DraftFacts, clip } from "./draft-facts.ts";
import type { MessageType, Tone } from "./types.ts";

const MONEY = /\$\s?\d{1,3}(?:,\d{3})*(?:\.\d{2})?/g;

export function moneyTokens(text: string): string[] {
  return (text.match(MONEY) ?? []).map((token) => token.replace(/\s/g, ""));
}

export function stripMoney(text: string): string {
  return text
    .replace(MONEY, "")
    .replace(/\s{2,}/g, " ")
    .replace(/\s+([,.])/g, "$1")
    .trim();
}

/** True when the draft mentions a dollar amount other than the saved quote total. */
export function hasUnexpectedPrice(text: string, allowed: string[]): boolean {
  const ok = new Set(allowed.map((item) => item.replace(/\s/g, "")));
  return moneyTokens(text).some((token) => !ok.has(token));
}

export function renderDemoDraft(facts: DraftFacts): string {
  const name = stripMoney(facts.customerFirstName) || "there";
  const company = stripMoney(facts.companyName) || "our cleaning team";
  const service = stripMoney(facts.serviceLabel) || "a cleaning";
  const area = facts.serviceArea ? ` We work in ${stripMoney(facts.serviceArea)}.` : "";
  const hours = facts.hours ? ` Hours: ${stripMoney(facts.hours)}.` : "";
  const price = facts.quoteTotalLabel
    ? `The estimate on file is ${facts.quoteTotalLabel}.`
    : "I will price it from our rate card once the details are confirmed, so I am not quoting a number in this note.";
  const noteSource = stripMoney(facts.notes);
  const note = noteSource ? ` I have this note: ${clip(noteSource, 180)}` : "";

  const body = draftBody(facts.messageType, facts.tone, {
    name,
    company,
    service,
    area,
    hours,
    price,
    note,
    frequency: facts.frequencyLabel,
  });
  return body;
}

type Bits = {
  name: string;
  company: string;
  service: string;
  area: string;
  hours: string;
  price: string;
  note: string;
  frequency: string;
};

function draftBody(type: MessageType, tone: Tone, b: Bits): string {
  if (tone === "concise") return concise(type, b);
  if (tone === "professional") return professional(type, b);
  return warm(type, b);
}

function warm(type: MessageType, b: Bits): string {
  switch (type) {
    case "initial":
      return `Hi ${b.name}, this is ${b.company}. Thanks for asking about ${b.service} (${b.frequency}).${b.note} ${b.price}${b.area}${b.hours} Reply with a day that works and I will hold it.`;
    case "estimate_followup":
      return `Hi ${b.name}, just circling back from ${b.company} on the ${b.service}. ${b.price} Happy to adjust rooms or add-ons if something changed. No payment is taken in this message — tell me if you want the time.`;
    case "unanswered":
      return `Hi ${b.name}, ${b.company} again. I still have your ${b.service} inquiry and I have not heard back.${b.note} ${b.price} If now is not a fit, a quick no is welcome so I can close the note.`;
    case "thank_you":
      return `Hi ${b.name}, thank you for choosing ${b.company}. It was good to take care of the ${b.service}. If anything was missed, reply and I will make it right.${b.area}`;
  }
}

function professional(type: MessageType, b: Bits): string {
  switch (type) {
    case "initial":
      return `Hello ${b.name}, this is ${b.company}. Thank you for your inquiry about ${b.service} on a ${b.frequency.toLowerCase()} schedule.${b.note} ${b.price}${b.area}${b.hours} Please reply with a preferred day and I will confirm availability.`;
    case "estimate_followup":
      return `Hello ${b.name}, I am following up from ${b.company} regarding ${b.service}. ${b.price} The figure uses the rate card saved on the account. Let me know if the scope should change before you decide.`;
    case "unanswered":
      return `Hello ${b.name}, I am writing from ${b.company} because your ${b.service} inquiry is still open.${b.note} ${b.price} Kindly let me know whether you would like to proceed.`;
    case "thank_you":
      return `Hello ${b.name}, thank you for scheduling with ${b.company}. We appreciate the chance to complete your ${b.service}. Please contact us if any detail needs attention.${b.area}`;
  }
}

function concise(type: MessageType, b: Bits): string {
  switch (type) {
    case "initial":
      return `Hi ${b.name} — ${b.company}. ${b.service}, ${b.frequency}.${b.note} ${b.price}${b.hours} Reply with a day if you want it booked.`;
    case "estimate_followup":
      return `Hi ${b.name}, following up on ${b.service}. ${b.price} Say if you want changes or a time.`;
    case "unanswered":
      return `Hi ${b.name}, still holding your ${b.service} inquiry at ${b.company}. ${b.price} A yes or no is enough.`;
    case "thank_you":
      return `Hi ${b.name}, thank you from ${b.company} for the ${b.service}. Message me if anything needs a fix.`;
  }
}
