/** The published site. Not a secret. */
export const CUSTOM_PRODUCTION_ORIGIN = "https://thebookbloom.com";

/**
 * The deployer injects a `*.grok.me` origin. Visitors use the custom domain, so
 * OAuth must start and finish on that domain or the browser rejects the request.
 */
export function resolveAuthBaseURL(injected: string | undefined): string | undefined {
  if (!injected) return undefined;
  try {
    const host = new URL(injected).hostname.toLowerCase();
    if (host === "thebookbloom.com" || host.endsWith(".grok.me")) return CUSTOM_PRODUCTION_ORIGIN;
  } catch {
    return injected;
  }
  return injected;
}

export function authTrustedOrigins(injected: string | undefined, base: string | undefined, local: string[]): string[] {
  const origins = new Set(local);
  if (base) origins.add(base);
  if (!injected) return [...origins];
  try {
    origins.add(new URL(injected).origin);
  } catch {
    /* ignore a malformed injected origin */
  }
  origins.add(CUSTOM_PRODUCTION_ORIGIN);
  return [...origins];
}
