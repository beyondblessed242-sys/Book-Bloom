import assert from "node:assert/strict";
import test from "node:test";
import { ADMIN_ACCESS_READY, postLoginPath } from "../safe-next.ts";

test("business accounts stay in their workspace, even if they ask for admin", () => {
  assert.equal(ADMIN_ACCESS_READY, false);
  assert.equal(postLoginPath({ requested: "/app/billing" }), "/app/billing");
  assert.equal(postLoginPath({ requested: "/admin" }), "/app");
  assert.equal(postLoginPath({ requested: "https://evil.example" }), "/app");
  assert.equal(postLoginPath({ requested: "/admin", role: "super_admin", mfaSatisfied: true }), "/app");
  assert.equal(postLoginPath({ requested: "/app", role: "support_admin", mfaSatisfied: false }), "/app");
});
