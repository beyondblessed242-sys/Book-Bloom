import assert from "node:assert/strict";
import test from "node:test";
import { authTrustedOrigins, resolveAuthBaseURL } from "./public-origin.ts";

test("a grok.me deployment still signs in on the custom domain", () => {
  assert.equal(
    resolveAuthBaseURL("https://ruby-bolt-xenon-breeze.grok.me"),
    "https://thebookbloom.com",
  );
  const trusted = authTrustedOrigins(
    "https://ruby-bolt-xenon-breeze.grok.me",
    "https://thebookbloom.com",
    ["http://localhost:8080"],
  );
  assert.ok(trusted.includes("https://thebookbloom.com"));
  assert.ok(trusted.includes("https://ruby-bolt-xenon-breeze.grok.me"));
});

test("preview keeps its dynamic origin", () => {
  assert.equal(resolveAuthBaseURL(undefined), undefined);
});
