/** Founder's Plan display price. Billing is not connected, so this does not charge anyone. */
export const FOUNDERS_MONTHLY_CENTS = 4900;

/** True only after Stripe subscriptions, webhooks, and entitlements are configured and tested. */
export const SUBSCRIPTION_BILLING_LIVE = false;

export function foundersPriceLabel(): string {
  const dollars = FOUNDERS_MONTHLY_CENTS / 100;
  return Number.isInteger(dollars) ? `$${dollars}` : `$${(FOUNDERS_MONTHLY_CENTS / 100).toFixed(2)}`;
}
