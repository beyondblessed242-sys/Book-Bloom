import { authClient, getBearerToken, setBearerToken } from "@/lib/auth/client";
import { verificationRequestCopy, type VerificationRequestStatus } from "@/lib/verification-copy";

export { verificationRequestCopy };
export type { VerificationRequestStatus };

function authHeaders(): HeadersInit {
  const headers: Record<string, string> = { "content-type": "application/json" };
  const token = getBearerToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  return headers;
}

const VERIFY_STATUS_KEY = "bookbloom.verify-status";

export function rememberVerificationStatus(status: VerificationRequestStatus) {
  try {
    window.sessionStorage.setItem(VERIFY_STATUS_KEY, status);
  } catch {
    /* storage unavailable */
  }
}

export function takeVerificationStatus(): VerificationRequestStatus | null {
  try {
    const value = window.sessionStorage.getItem(VERIFY_STATUS_KEY);
    window.sessionStorage.removeItem(VERIFY_STATUS_KEY);
    if (
      value === "accepted" ||
      value === "not_configured" ||
      value === "rate_limited" ||
      value === "already_verified" ||
      value === "provider_rejected"
    ) {
      return value;
    }
  } catch {
    /* storage unavailable */
  }
  return null;
}

/**
 * Email/password runs against this app's own auth API. In the embedded preview,
 * cookies are partitioned, so the session token from `set-auth-token` is stored
 * the same way the OAuth popup stores its bearer. Deployed cookie auth still
 * works because credentials are included.
 */
export async function signUpWithEmail(input: { name: string; email: string; password: string }) {
  const response = await fetch("/api/auth/sign-up/email", {
    method: "POST",
    headers: authHeaders(),
    credentials: "include",
    body: JSON.stringify(input),
  });
  await finish(response);
}

export async function signInWithEmail(input: { email: string; password: string; rememberMe?: boolean }): Promise<"ok" | "two-factor"> {
  const response = await fetch("/api/auth/sign-in/email", {
    method: "POST",
    headers: authHeaders(),
    credentials: "include",
    body: JSON.stringify({
      email: input.email,
      password: input.password,
      rememberMe: input.rememberMe !== false,
    }),
  });
  const payload = (await response.json().catch(() => null)) as {
    message?: string;
    token?: string;
    twoFactorRedirect?: boolean;
  } | null;
  if (!response.ok) {
    throw new Error(payload?.message || "Could not sign in. Check the email and password.");
  }
  if (payload?.twoFactorRedirect) return "two-factor";
  const token = response.headers.get("set-auth-token") || payload?.token || null;
  if (token) setBearerToken(token);
  await authClient.getSession();
  return "ok";
}

export async function verifySignInTotp(code: string): Promise<void> {
  const response = await fetch("/api/auth/two-factor/verify-totp", {
    method: "POST",
    headers: authHeaders(),
    credentials: "include",
    body: JSON.stringify({ code }),
  });
  await finish(response);
}

async function finish(response: Response) {
  const payload = (await response.json().catch(() => null)) as {
    message?: string;
    token?: string;
  } | null;
  if (!response.ok) {
    throw new Error(payload?.message || "Could not sign in. Check the email and password.");
  }
  const token = response.headers.get("set-auth-token") || payload?.token || null;
  if (token) setBearerToken(token);
  await authClient.getSession();
}

export async function requestPasswordReset(_email: string): Promise<"unavailable" | "accepted"> {
  return "unavailable";
}

export async function resetPasswordWithToken(input: { token: string; newPassword: string }) {
  const response = await fetch("/api/auth/reset-password", {
    method: "POST",
    headers: authHeaders(),
    credentials: "include",
    body: JSON.stringify({ token: input.token, newPassword: input.newPassword }),
  });
  const payload = (await response.json().catch(() => null)) as { message?: string } | null;
  if (!response.ok) {
    throw new Error(payload?.message || "This reset link is not valid. Your password was not changed.");
  }
}

export async function requestVerificationEmail(_email: string): Promise<VerificationRequestStatus> {
  return "not_configured";
}

export async function refreshEmailVerified(): Promise<{ email: string | null; emailVerified: boolean }> {
  const headers = new Headers();
  const token = getBearerToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);
  const response = await fetch("/api/auth/get-session?disableCookieCache=true", {
    credentials: "include",
    headers,
  });
  if (!response.ok) return { email: null, emailVerified: false };
  const payload = (await response.json().catch(() => null)) as {
    user?: { email?: string; emailVerified?: boolean };
  } | null;
  return {
    email: payload?.user?.email ?? null,
    emailVerified: payload?.user?.emailVerified === true,
  };
}

export { safeNextPath } from "@/lib/safe-next";

export async function changeAccountPassword(input: { currentPassword: string; newPassword: string }) {
  const response = await fetch("/api/auth/change-password", {
    method: "POST",
    headers: authHeaders(),
    credentials: "include",
    body: JSON.stringify({ ...input, revokeOtherSessions: false }),
  });
  await finish(response);
}

export async function requestEmailChange(_newEmail: string): Promise<"not_configured" | "accepted" | "unchanged"> {
  return "not_configured";
}


