import { formatMoney } from "./money.ts";
import {
  type Extra,
  type FrequencyId,
  type QuoteBreakdown,
  type ServiceRate,
  frequencyById,
} from "./types.ts";

export type QuoteCalcInput = {
  services: ServiceRate[];
  extrasCatalog: Extra[];
  serviceId: string;
  rooms: number;
  sqft: number;
  frequency: FrequencyId;
  extraIds: string[];
  adjustmentCents: number;
};

export function calculateQuote(input: QuoteCalcInput): QuoteBreakdown {
  const service = input.services.find((item) => item.id === input.serviceId);
  if (!service) throw new Error("Choose a service from your rate card.");
  const frequency = frequencyById(input.frequency);
  if (!frequency) throw new Error("Choose how often they want service.");

  const rooms = clampInt(input.rooms, 0, 40);
  const sqft = clampInt(input.sqft, 0, 20000);
  const roomsCents = rooms * service.perRoomCents;
  const sqftCents = sqft * service.perSqftCents;
  const cleaningCents = service.baseCents + roomsCents + sqftCents;
  const frequencyCents = Math.round((cleaningCents * frequency.bps) / 10000);
  const extras = input.extraIds
    .map((id) => input.extrasCatalog.find((item) => item.id === id))
    .filter((item): item is Extra => Boolean(item))
    .map((item) => ({ id: item.id, name: item.name, cents: item.cents }));
  const extrasCents = extras.reduce((sum, item) => sum + item.cents, 0);
  const adjustmentCents = clampInt(input.adjustmentCents, -500_000, 500_000);
  const totalCents = frequencyCents + extrasCents + adjustmentCents;

  return {
    serviceId: service.id,
    serviceLabel: service.label,
    rooms,
    sqft,
    perRoomCents: service.perRoomCents,
    perSqftCents: service.perSqftCents,
    frequency: frequency.id,
    frequencyLabel: frequency.label,
    multiplierBps: frequency.bps,
    baseCents: service.baseCents,
    roomsCents,
    sqftCents,
    cleaningCents,
    frequencyCents,
    extras,
    extrasCents,
    adjustmentCents,
    totalCents,
  };
}

/** Plain-language explanation built only from the calculated lines. */
export function explainQuote(b: QuoteBreakdown): string {
  const parts = [
    `${b.serviceLabel}, ${b.frequencyLabel.toLowerCase()}.`,
    `Base ${formatMoney(b.baseCents)}.`,
  ];
  if (b.rooms > 0) {
    parts.push(
      `${b.rooms} ${b.rooms === 1 ? "room" : "rooms"} at ${formatMoney(b.perRoomCents)} comes to ${formatMoney(b.roomsCents)}.`,
    );
  }
  if (b.sqft > 0) {
    parts.push(
      `${b.sqft.toLocaleString("en-US")} sq ft at ${formatMoney(b.perSqftCents)} comes to ${formatMoney(b.sqftCents)}.`,
    );
  }
  if (b.rooms === 0 && b.sqft === 0) {
    parts.push("No rooms or square footage were entered, so only the base rate is used.");
  }
  if (b.multiplierBps !== 10000) {
    const pct = (b.multiplierBps / 100).toFixed(0);
    parts.push(
      `The ${b.frequencyLabel.toLowerCase()} rate (${pct}% of the cleaning subtotal) brings that portion to ${formatMoney(b.frequencyCents)}.`,
    );
  }
  for (const extra of b.extras) {
    parts.push(`${extra.name} adds ${formatMoney(extra.cents)}.`);
  }
  if (b.adjustmentCents !== 0) {
    parts.push(`Owner adjustment ${formatMoney(b.adjustmentCents)}.`);
  }
  parts.push(`Total ${formatMoney(b.totalCents)}.`);
  parts.push("Extras are not discounted. This total is math from the rate card, not an estimate invented by a model.");
  return parts.join(" ");
}

function clampInt(value: number, min: number, max: number): number {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, Math.round(value)));
}
