import { z } from "zod";
import { FREQUENCIES, LEAD_STATUSES, MESSAGE_TYPES, QUOTE_STATUSES, TONES } from "./types.ts";

const money = z.number().int().min(0).max(10_000_000);
const adjustment = z.number().int().min(-500_000).max(500_000);

export const serviceSchema = z.object({
  id: z.string().trim().min(1).max(40).regex(/^[a-z0-9-]+$/, "Service id must be a short slug"),
  label: z.string().trim().min(1, "Service name is required").max(60),
  baseCents: money,
  perRoomCents: money,
  perSqftCents: z.number().int().min(0).max(500),
});

export const extraSchema = z.object({
  id: z.string().trim().min(1).max(40).regex(/^[a-z0-9-]+$/, "Extra id must be a short slug"),
  name: z.string().trim().min(1, "Extra name is required").max(60),
  cents: money,
});

const optionalEmail = z
  .string()
  .trim()
  .max(120)
  .refine((value) => value === "" || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value), "Enter a valid email or leave it blank");

export const businessSchema = z.object({
  companyName: z.string().trim().max(80),
  ownerName: z.string().trim().max(80),
  email: optionalEmail,
  phone: z.string().trim().max(40),
  serviceArea: z.string().trim().max(120),
  hours: z.string().trim().max(160),
  tone: z.enum(TONES.map((item) => item.id) as ["warm", "professional", "concise"]),
  services: z.array(serviceSchema).min(1, "Keep at least one service").max(12),
  extras: z.array(extraSchema).max(20),
});

export const leadSchema = z.object({
  id: z.string().trim().min(1).max(80).optional(),
  name: z.string().trim().min(1, "Name is required").max(80),
  email: optionalEmail,
  phone: z.string().trim().max(40),
  serviceId: z.string().trim().min(1).max(40),
  rooms: z.number().int().min(0).max(40).nullable(),
  sqft: z.number().int().min(0).max(20000).nullable(),
  frequency: z.enum(FREQUENCIES.map((item) => item.id) as ["one-time", "weekly", "biweekly", "monthly"]),
  notes: z.string().trim().max(2000),
  status: z.enum(LEAD_STATUSES.map((item) => item.id) as ["new", "contacted", "quoted", "booked", "lost"]),
  lastContact: z
    .string()
    .trim()
    .refine((value) => value === "" || /^\d{4}-\d{2}-\d{2}$/.test(value), "Use a real date")
    .nullable(),
});

export const quoteSchema = z.object({
  id: z.string().trim().min(1).max(80).optional(),
  leadId: z.string().trim().min(1).max(80).nullable(),
  serviceId: z.string().trim().min(1).max(40),
  rooms: z.number().int().min(0).max(40),
  sqft: z.number().int().min(0).max(20000),
  frequency: z.enum(FREQUENCIES.map((item) => item.id) as ["one-time", "weekly", "biweekly", "monthly"]),
  extraIds: z.array(z.string().trim().min(1).max(40)).max(20),
  adjustmentCents: adjustment,
  explanation: z.string().trim().max(2000),
  status: z.enum(QUOTE_STATUSES.map((item) => item.id) as ["draft", "approved", "sent"]),
});

export const quoteStatusSchema = z.object({
  id: z.string().trim().min(1).max(80),
  status: z.enum(["draft", "approved", "sent"]),
});

export const followUpSchema = z.object({
  id: z.string().trim().min(1).max(80).optional(),
  leadId: z.string().trim().min(1).max(80).nullable(),
  title: z.string().trim().min(1, "Add a short reminder").max(140),
  dueDate: z.string().trim().regex(/^\d{4}-\d{2}-\d{2}$/, "Choose a due date"),
  notes: z.string().trim().max(1000),
});

export const idSchema = z.object({
  id: z.string().trim().min(1).max(80),
});

export const followDoneSchema = z.object({
  id: z.string().trim().min(1).max(80),
  done: z.boolean(),
});

export const draftSchema = z.object({
  leadId: z.string().trim().min(1).max(80),
  messageType: z.enum(
    MESSAGE_TYPES.map((item) => item.id) as [
      "initial",
      "estimate_followup",
      "unanswered",
      "thank_you",
    ],
  ),
});

export function parseInput<T>(schema: z.ZodType<T>, data: unknown): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    throw new Error(result.error.issues[0]?.message ?? "Check the form and try again.");
  }
  return result.data;
}

export type BusinessInput = z.infer<typeof businessSchema>;
export type LeadInput = z.infer<typeof leadSchema>;
export type QuoteInput = z.infer<typeof quoteSchema>;
export type FollowUpInput = z.infer<typeof followUpSchema>;
