import { z } from "zod";

export const TIMEZONES = [
  "America/New_York",
  "America/Chicago",
  "America/Denver",
  "America/Phoenix",
  "America/Los_Angeles",
  "America/Anchorage",
  "Pacific/Honolulu",
  "UTC",
] as const;

export type TimezoneId = (typeof TIMEZONES)[number];

const phone = z
  .string()
  .trim()
  .max(40)
  .refine((value) => value === "" || /^[0-9+().\-\s]{7,40}$/.test(value), "Enter a phone number or leave it blank");

export const profileSchema = z.object({
  firstName: z.string().trim().max(40),
  lastName: z.string().trim().max(40),
  displayName: z.string().trim().min(2, "Add a display name").max(80),
  phone,
  timezone: z.enum(TIMEZONES),
});

export type ProfileInput = z.infer<typeof profileSchema>;

export const notificationSchema = z.object({
  followUpReminders: z.boolean(),
  productUpdates: z.boolean(),
  subscriptionNotices: z.boolean(),
  marketing: z.boolean(),
});

export type NotificationInput = z.infer<typeof notificationSchema>;

export function rejectRoleField(input: unknown): void {
  if (input && typeof input === "object" && "role" in input) {
    throw new Error("You cannot change an account role.");
  }
}

export function initials(name: string, email: string): string {
  const source = name.trim() || email.trim() || "Account";
  const parts = source.split(/\s+/).filter(Boolean);
  if (parts.length >= 2) return `${parts[0]!.charAt(0)}${parts[1]!.charAt(0)}`.toUpperCase();
  return source.slice(0, 2).toUpperCase();
}

const JPEG = [0xff, 0xd8, 0xff];
const PNG = [0x89, 0x50, 0x4e, 0x47];
const MAX_PHOTO_BYTES = 400_000;

export function decodeProfilePhoto(dataUrl: string): { mime: string; bytes: Uint8Array } {
  const match = /^data:(image\/(?:jpeg|png|webp));base64,([a-z0-9+/=\s]+)$/i.exec(dataUrl.trim());
  if (!match) throw new Error("Use a JPEG, PNG, or WebP photo.");
  const mime = match[1]!.toLowerCase() === "image/jpg" ? "image/jpeg" : match[1]!.toLowerCase();
  const binary = globalThis.atob(match[2]!.replace(/\s/g, ""));
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  if (bytes.byteLength < 16 || bytes.byteLength > MAX_PHOTO_BYTES) {
    throw new Error("Photo must be under 400 KB.");
  }
  const head = Array.from(bytes.slice(0, 12));
  const jpeg = JPEG.every((value, index) => head[index] === value);
  const png = PNG.every((value, index) => head[index] === value);
  const webp = head[0] === 0x52 && head[1] === 0x49 && head[2] === 0x46 && head[3] === 0x46 && head[8] === 0x57 && head[9] === 0x45 && head[10] === 0x42 && head[11] === 0x50;
  if (mime === "image/jpeg" && !jpeg) throw new Error("That file is not a JPEG.");
  if (mime === "image/png" && !png) throw new Error("That file is not a PNG.");
  if (mime === "image/webp" && !webp) throw new Error("That file is not a WebP.");
  return { mime, bytes };
}
