export type VerificationRequestStatus =
  | "not_configured"
  | "accepted"
  | "rate_limited"
  | "already_verified"
  | "provider_rejected";

export function verificationRequestCopy(status: VerificationRequestStatus): { text: string; error: boolean } {
  if (status === "accepted") {
    return { text: "Verification email requested. Check your inbox and spam folder.", error: false };
  }
  if (status === "rate_limited") {
    return { text: "A verification email was requested too recently. Wait a minute. No additional message was sent.", error: true };
  }
  if (status === "already_verified") {
    return { text: "This address is already verified. No message was sent.", error: false };
  }
  if (status === "provider_rejected") {
    return { text: "The mail provider did not accept the request. No message was sent, and the address was not marked verified.", error: true };
  }
  return { text: "No message was sent. Mail delivery is not configured, and this address was not marked verified.", error: true };
}

export function verificationScreenCopy(status: VerificationRequestStatus | null): { text: string; error: boolean } {
  if (status === "accepted") {
    return {
      text: "Email sent. Check your inbox and your spam or junk folder. This screen cannot confirm the message arrived.",
      error: false,
    };
  }
  if (status === null) {
    return {
      text: "No verification message has been requested from this screen yet.",
      error: false,
    };
  }
  return verificationRequestCopy(status);
}
