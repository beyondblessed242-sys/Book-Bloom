/** Owner decision. An email address is not an input, and MFA does not grant the role. */
export function decideHqAccess(input: {
  assignedRole: string | null;
  twoFactorEnabled: boolean;
  mfaProofExpiresAt: string | null;
  sessionMatches: boolean;
  now: number;
}): { allowed: boolean; needsCode: boolean; reason: string } {
  if (input.assignedRole !== "platform_owner") {
    return {
      allowed: false,
      needsCode: false,
      reason: "This account does not have a server-assigned platform owner role. An email address cannot open BookBloom HQ.",
    };
  }
  if (!input.twoFactorEnabled) {
    return {
      allowed: false,
      needsCode: false,
      reason: "Enroll an authenticator app under Password & Security before BookBloom HQ can open.",
    };
  }
  const expires = input.mfaProofExpiresAt ? Date.parse(input.mfaProofExpiresAt) : NaN;
  if (!input.sessionMatches || !Number.isFinite(expires) || expires <= input.now) {
    return {
      allowed: false,
      needsCode: true,
      reason: "Enter the current code from your authenticator app. Another sign-in method or an older session does not skip this.",
    };
  }
  return { allowed: true, needsCode: false, reason: "Platform owner role and authenticator check are both present for this session." };
}
