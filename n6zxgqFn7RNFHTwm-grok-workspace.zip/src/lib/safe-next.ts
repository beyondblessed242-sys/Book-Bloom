/** Only in-app business paths. Blocks open redirects and admin URLs. */
export function safeNextPath(value: string | null | undefined): string {
  if (!value || !value.startsWith("/") || value.startsWith("//")) return "/app";
  if (value === "/app" || value.startsWith("/app/") || value === "/demo") return value;
  return "/app";
}

/** Assigned on the server. The sign-in form never sends or accepts a role. */
export type PlatformRole = "business_owner" | "support_admin" | "super_admin";

/**
 * Privileged admin access stays off until a server-side owner assignment
 * and a tested multi-factor check both exist. Do not flip this from the client.
 */
export const ADMIN_ACCESS_READY = false;

export function postLoginPath(input: {
  requested?: string | null;
  role?: PlatformRole;
  mfaSatisfied?: boolean;
}): string {
  const role = input.role ?? "business_owner";
  if (!ADMIN_ACCESS_READY || role === "business_owner" || !input.mfaSatisfied) {
    return safeNextPath(input.requested);
  }
  if (role === "super_admin") return "/admin";
  return "/app";
}
