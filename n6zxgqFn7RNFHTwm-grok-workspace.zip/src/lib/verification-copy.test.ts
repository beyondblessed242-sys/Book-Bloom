import assert from "node:assert/strict";
import test from "node:test";
import { verificationRequestCopy, verificationScreenCopy } from "./verification-copy.ts";

test("an accepted verification request does not claim the inbox received it", () => {
  const copy = verificationRequestCopy("accepted");
  assert.equal(copy.error, false);
  assert.match(copy.text, /requested/i);
  assert.doesNotMatch(copy.text, /arrived|delivered/i);
});

test("a missing mail provider does not claim a message was sent", () => {
  const copy = verificationRequestCopy("not_configured");
  assert.equal(copy.error, true);
  assert.match(copy.text, /No message was sent/);
});

test("the verification screen says email sent only after the provider accepts", () => {
  assert.equal(verificationScreenCopy("accepted").text.startsWith("Email sent."), true);
  assert.match(verificationScreenCopy("provider_rejected").text, /No message was sent/);
  assert.equal(verificationScreenCopy("not_configured").error, true);
});
