import type { MessageType, Tone } from "./types.ts";

/** Facts the draft is allowed to use. No customer email or phone. */
export type DraftFacts = {
  messageType: MessageType;
  tone: Tone;
  companyName: string;
  serviceArea: string;
  hours: string;
  customerFirstName: string;
  serviceLabel: string;
  frequencyLabel: string;
  notes: string;
  quoteTotalLabel: string | null;
  quoteStatus: string | null;
};

export function firstName(fullName: string): string {
  const part = fullName.trim().split(/\s+/)[0] ?? "";
  return part.replace(/[^\p{L}\p{M}'-]/gu, "").slice(0, 40);
}

export function clip(value: string, max: number): string {
  const clean = value.replace(/\s+/g, " ").trim();
  if (clean.length <= max) return clean;
  return `${clean.slice(0, max - 1).trim()}…`;
}
