export type PasswordRule = { id: string; label: string; met: boolean };

export function passwordRules(password: string): PasswordRule[] {
  return [
    { id: "length", label: "At least 8 characters", met: password.length >= 8 && password.length <= 128 },
    { id: "letter", label: "At least one letter", met: /[A-Za-z]/.test(password) },
    { id: "number", label: "At least one number", met: /[0-9]/.test(password) },
  ];
}

export function passwordError(password: string): string | null {
  if (password.length > 128) return "Use 128 characters or fewer.";
  const missing = passwordRules(password).filter((rule) => !rule.met);
  if (missing.length === 0) return null;
  return `Password needs: ${missing.map((rule) => rule.label.toLowerCase()).join(", ")}.`;
}
