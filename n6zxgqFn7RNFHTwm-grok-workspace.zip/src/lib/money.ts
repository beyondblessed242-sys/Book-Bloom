/** Whole cents. Negative values are allowed for an owner adjustment. */
export function formatMoney(cents: number): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(Math.round(cents));
  const dollars = Math.floor(abs / 100);
  const rem = String(abs % 100).padStart(2, "0");
  const grouped = String(dollars).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${sign}$${grouped}.${rem}`;
}

/** Parse a dollar field. Empty is 0. Returns null when the text is not a money amount. */
export function parseDollarsToCents(input: string, allowNegative = false): number | null {
  const t = input.trim().replace(/[$,\s]/g, "");
  if (!t) return 0;
  const pattern = allowNegative ? /^-?\d+(\.\d{1,2})?$/ : /^\d+(\.\d{1,2})?$/;
  if (!pattern.test(t)) return null;
  const negative = t.startsWith("-");
  const raw = negative ? t.slice(1) : t;
  const [d, c = ""] = raw.split(".");
  const cents = Number(d) * 100 + Number(c.padEnd(2, "0"));
  if (!Number.isSafeInteger(cents)) return null;
  return negative ? -cents : cents;
}

export function centsToInput(cents: number): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(Math.round(cents));
  return `${sign}${Math.floor(abs / 100)}.${String(abs % 100).padStart(2, "0")}`;
}
