import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Logo } from "@/components/logo";
import { Notice } from "@/components/field";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { foundersPriceLabel } from "@/lib/pricing";
import {
  confirmHqMfa,
  getHqAccess,
  getHqActivity,
  getHqAnalytics,
  getHqBilling,
  getHqBusinesses,
  getHqCases,
  getHqOverview,
  getHqSettings,
  getHqUser,
  getHqUsers,
  saveHqCase,
  saveHqSettings,
} from "@/server/hq";

export const Route = createFileRoute("/hq")({
  component: HqPage,
});

const SECTIONS = [
  ["overview", "Overview"],
  ["users", "Users"],
  ["businesses", "Businesses"],
  ["subscriptions", "Subscriptions"],
  ["payments", "Payments"],
  ["support", "Support"],
  ["analytics", "Analytics"],
  ["plans", "Plans"],
  ["settings", "Platform Settings"],
  ["activity", "Activity & Security"],
] as const;

type Section = (typeof SECTIONS)[number][0];
type Access = Awaited<ReturnType<typeof getHqAccess>>;

function HqPage() {
  const { user, isPending } = useCurrentUserState();
  const [access, setAccess] = useState<Access | null>(null);
  const [section, setSection] = useState<Section>("overview");
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!user) return;
    void getHqAccess()
      .then(setAccess)
      .catch((err: unknown) => setError(err instanceof Error ? err.message : "BookBloom HQ could not be checked."));
  }, [user]);

  if (isPending || (user && !access && !error)) {
    return <main className="grid min-h-screen place-items-center text-muted">Checking owner access…</main>;
  }
  if (!user) return <RedirectToSignIn />;
  if (!access?.allowed) {
    return (
      <main className="mx-auto grid min-h-screen max-w-lg place-items-center px-4 py-12">
        <div className="card w-full p-6 sm:p-8">
          <Logo to="/app" />
          <h1 className="mt-6 font-display text-4xl">BookBloom HQ</h1>
          <div className="mt-4">
            <Notice tone="warn">{error || access?.reason || "BookBloom HQ is closed."}</Notice>
          </div>
          {access?.needsCode ? (
            <form
              className="mt-4 grid gap-3"
              onSubmit={(event) => {
                event.preventDefault();
                setBusy(true);
                setError(null);
                void confirmHqMfa({ data: { code } })
                  .then((next) => {
                    setAccess(next);
                    if (!next.allowed) setError(next.reason);
                  })
                  .catch((err: unknown) => setError(err instanceof Error ? err.message : "The code was not accepted."))
                  .finally(() => setBusy(false));
              }}
            >
              <label className="grid gap-1 text-sm">
                Authenticator code
                <input className="field-input" inputMode="numeric" autoComplete="one-time-code" value={code} onChange={(event) => setCode(event.target.value)} required />
              </label>
              <button className="btn btn-primary" type="submit" disabled={busy}>{busy ? "Checking…" : "Continue"}</button>
            </form>
          ) : (
            <p className="mt-4 text-sm text-muted">There is no page, form, or signup that can assign this role. A database administrator has to write it to the user id.</p>
          )}
          <Link to="/app" className="btn btn-secondary mt-4">Back to your workspace</Link>
        </div>
      </main>
    );
  }

  return (
    <div className="min-h-screen">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
          <Logo to="/app" />
          <p className="text-sm text-muted">BookBloom HQ</p>
        </div>
        <nav aria-label="BookBloom HQ" className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-3 pb-3">
          {SECTIONS.map(([id, label]) => (
            <button key={id} type="button" className={id === section ? "btn btn-primary" : "btn btn-ghost"} onClick={() => setSection(id)} aria-current={id === section ? "page" : undefined}>
              {label}
            </button>
          ))}
        </nav>
      </header>
      <main className="mx-auto grid max-w-6xl gap-4 px-4 py-6">
        {section === "overview" ? <Overview /> : null}
        {section === "users" ? <Users /> : null}
        {section === "businesses" ? <Businesses /> : null}
        {section === "subscriptions" || section === "payments" ? <Billing payments={section === "payments"} /> : null}
        {section === "support" ? <Support /> : null}
        {section === "analytics" ? <Analytics /> : null}
        {section === "plans" || section === "settings" ? <Settings plans={section === "plans"} /> : null}
        {section === "activity" ? <Activity /> : null}
      </main>
    </div>
  );
}

function Overview() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getHqOverview>> | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    void getHqOverview().then(setData).catch((err: unknown) => setError(err instanceof Error ? err.message : "Could not load the overview."));
  }, []);
  if (error) return <Notice tone="warn">{error}</Notice>;
  if (!data) return <p className="text-muted">Loading overview…</p>;
  return (
    <div className="grid gap-4">
      <h1 className="font-display text-3xl">Overview</h1>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Metric label="Registered users" value={String(data.users)} />
        <Metric label="New this month" value={String(data.newUsersThisMonth)} />
        <Metric label="Businesses" value={String(data.businesses)} />
        <Metric label="Open support cases" value={String(data.openSupportCases)} />
        <Metric label="Active subscriptions" value="Unavailable" note={data.subscriptions.reason} />
        <Metric label="Monthly recurring revenue" value="Unavailable" note={data.revenue.reason} />
      </div>
      <section className="card p-5">
        <h2 className="font-display text-xl">Recent signups</h2>
        {data.recentSignups.length === 0 ? <p className="mt-2 text-sm text-muted">No registered users yet.</p> : (
          <ul className="mt-3 divide-y divide-line text-sm">
            {data.recentSignups.map((row) => (
              <li key={row.id} className="flex justify-between gap-3 py-2">
                <span>{row.name}<span className="block text-muted">{row.email}</span></span>
                <span className="text-muted">{new Date(row.createdAt).toLocaleDateString()}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
      <Notice>Recent billing events are unavailable. Stripe is not connected, so none are shown as zero.</Notice>
    </div>
  );
}

function Users() {
  const [query, setQuery] = useState("");
  const [rows, setRows] = useState<Awaited<ReturnType<typeof getHqUsers>> | null>(null);
  const [selected, setSelected] = useState<Awaited<ReturnType<typeof getHqUser>> | null>(null);
  const [error, setError] = useState<string | null>(null);
  function load(next = query) {
    setError(null);
    void getHqUsers({ data: { query: next } })
      .then(setRows)
      .catch((err: unknown) => setError(err instanceof Error ? err.message : "Could not load users."));
  }
  useEffect(() => { load(""); }, []);
  return (
    <div className="grid gap-4">
      <h1 className="font-display text-3xl">Users</h1>
      <form className="flex gap-2" onSubmit={(event) => { event.preventDefault(); load(); }}>
        <input className="field-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search name, email, or business" aria-label="Search users" />
        <button className="btn btn-secondary" type="submit">Search</button>
      </form>
      {error ? <Notice tone="warn">{error}</Notice> : null}
      {!rows ? <p className="text-muted">Loading users…</p> : rows.length === 0 ? <p className="text-sm text-muted">No accounts match.</p> : (
        <div className="overflow-x-auto rounded-2xl border border-line bg-surface">
          <table className="w-full min-w-[720px] text-left text-sm">
            <thead className="text-muted"><tr><th className="p-3">Name</th><th>Email</th><th>Signed up</th><th>Business</th><th>Account</th><th>Subscription</th><th>Last activity</th></tr></thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id} className="border-t border-line">
                  <td className="p-3"><button type="button" className="text-accent" onClick={() => void getHqUser({ data: { userId: row.id } }).then(setSelected)}>{row.name}</button></td>
                  <td>{row.email}</td>
                  <td>{new Date(row.createdAt).toLocaleDateString()}</td>
                  <td>{row.business}</td>
                  <td>{row.accountStatus}</td>
                  <td>{row.subscriptionStatus}</td>
                  <td>{row.lastActivity ? new Date(row.lastActivity).toLocaleDateString() : "No session yet"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {selected ? (
        <section className="card grid gap-2 p-5 text-sm">
          <h2 className="font-display text-xl">{selected.name}</h2>
          <p>{selected.email}</p>
          <p>Business: {selected.business}</p>
          <p>Account: {selected.accountStatus}</p>
          <p>Subscription: {selected.subscriptionStatus}</p>
          <p>Leads: {selected.leadCount} · Estimates: {selected.estimateCount} · Follow-ups: {selected.followUpCount}</p>
          <p className="text-muted">Counts only. Lead notes, messages, and estimate text stay in the customer workspace.</p>
          <Notice>{selected.supportNote}</Notice>
        </section>
      ) : null}
    </div>
  );
}

function Businesses() {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof getHqBusinesses>> | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    void getHqBusinesses().then(setRows).catch((err: unknown) => setError(err instanceof Error ? err.message : "Could not load businesses."));
  }, []);
  if (error) return <Notice tone="warn">{error}</Notice>;
  if (!rows) return <p className="text-muted">Loading businesses…</p>;
  if (rows.length === 0) return <p className="text-sm text-muted">No businesses have been saved yet.</p>;
  return (
    <div className="grid gap-4">
      <h1 className="font-display text-3xl">Businesses</h1>
      <div className="overflow-x-auto rounded-2xl border border-line bg-surface">
        <table className="w-full min-w-[760px] text-left text-sm">
          <thead className="text-muted"><tr><th className="p-3">Business</th><th>Owner</th><th>Created</th><th>Industry</th><th>Status</th><th>Plan</th><th>Leads</th><th>Estimates</th><th>Follow-ups</th></tr></thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id} className="border-t border-line">
                <td className="p-3">{row.name}</td><td>{row.owner}</td><td>{new Date(row.createdAt).toLocaleDateString()}</td><td>{row.industry}</td><td>{row.accountStatus}</td><td>{row.plan}</td><td>{row.leads}</td><td>{row.estimates}</td><td>{row.followUps}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Billing({ payments }: { payments: boolean }) {
  const [data, setData] = useState<Awaited<ReturnType<typeof getHqBilling>> | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    void getHqBilling().then(setData).catch((err: unknown) => setError(err instanceof Error ? err.message : "Could not load billing."));
  }, []);
  if (error) return <Notice tone="warn">{error}</Notice>;
  if (!data) return <p className="text-muted">Loading billing…</p>;
  return (
    <div className="grid gap-4">
      <h1 className="font-display text-3xl">{payments ? "Payments" : "Subscriptions"}</h1>
      <Notice tone="warn">{data.reason}</Notice>
      <p className="text-sm">Advertised plan: {data.plan}, {foundersPriceLabel()}/month. Checkout is not enabled.</p>
      <p className="text-sm text-muted">{payments ? "Paid invoices, unpaid invoices, failed payments, refunds, and trends have no records." : "Customer, status, renewal date, cancellation, and Stripe reference have no records."}</p>
    </div>
  );
}

function Support() {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof getHqCases>> | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [subject, setSubject] = useState("");
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);
  function load() {
    void getHqCases().then(setRows).catch((err: unknown) => setError(err instanceof Error ? err.message : "Could not load cases."));
  }
  useEffect(() => { load(); }, []);
  return (
    <div className="grid gap-4">
      <h1 className="font-display text-3xl">Support</h1>
      <Notice>Cases stay inside BookBloom HQ. No email is sent or received.</Notice>
      {error ? <Notice tone="warn">{error}</Notice> : null}
      <form className="card grid gap-3 p-5" onSubmit={(event) => {
        event.preventDefault();
        setBusy(true);
        void saveHqCase({ data: { subject, notes, category: "other", priority: "normal", status: "open" } })
          .then(() => { setSubject(""); setNotes(""); load(); })
          .catch((err: unknown) => setError(err instanceof Error ? err.message : "The case was not saved."))
          .finally(() => setBusy(false));
      }}>
        <label className="grid gap-1 text-sm">Subject<input className="field-input" value={subject} onChange={(event) => setSubject(event.target.value)} required /></label>
        <label className="grid gap-1 text-sm">Internal note<textarea className="field-input min-h-24" value={notes} onChange={(event) => setNotes(event.target.value)} /></label>
        <button className="btn btn-primary w-fit" type="submit" disabled={busy}>{busy ? "Saving…" : "Add case"}</button>
      </form>
      {!rows ? <p className="text-muted">Loading cases…</p> : rows.length === 0 ? <p className="text-sm text-muted">No support cases yet.</p> : (
        <ul className="grid gap-3">
          {rows.map((row) => (
            <li key={row.id} className="card p-4 text-sm">
              <p className="font-medium">{row.subject}</p>
              <p className="text-muted">{row.customer} · {row.category} · {row.priority} · {row.status}</p>
              {row.notes ? <p className="mt-2">{row.notes}</p> : null}
              {row.resolution ? <p className="mt-2">Resolution: {row.resolution}</p> : null}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Analytics() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getHqAnalytics>> | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    void getHqAnalytics().then(setData).catch((err: unknown) => setError(err instanceof Error ? err.message : "Could not load analytics."));
  }, []);
  if (error) return <Notice tone="warn">{error}</Notice>;
  if (!data) return <p className="text-muted">Loading analytics…</p>;
  return (
    <div className="grid gap-4">
      <h1 className="font-display text-3xl">Analytics</h1>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Metric label="Businesses" value={String(data.businesses)} />
        <Metric label="Leads created" value={String(data.leads)} />
        <Metric label="Estimates generated" value={String(data.estimates)} />
        <Metric label="Follow-ups tracked" value={String(data.followUps)} />
        <Metric label="Message drafts" value={String(data.messageDrafts)} />
        <Metric label="Sessions in 30 days" value={String(data.activeSessions30Days)} />
      </div>
      <section className="card p-5">
        <h2 className="font-display text-xl">Registrations by month</h2>
        {data.registrations.length === 0 ? <p className="mt-2 text-sm text-muted">No registrations yet. This is an empty record, not an unavailable metric.</p> : (
          <ul className="mt-3 text-sm">{data.registrations.map((row) => <li key={row.month}>{row.month}: {row.total}</li>)}</ul>
        )}
      </section>
      <Notice tone="warn">{data.retention.reason}</Notice>
      <Notice tone="warn">{data.subscriptionGrowth.reason}</Notice>
    </div>
  );
}

function Settings({ plans }: { plans: boolean }) {
  const [data, setData] = useState<Awaited<ReturnType<typeof getHqSettings>> | null>(null);
  const [announcement, setAnnouncement] = useState("");
  const [policy, setPolicy] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    void getHqSettings().then((next) => {
      setData(next);
      setAnnouncement(next.announcement);
      setPolicy(next.supportPolicy);
    }).catch((err: unknown) => setError(err instanceof Error ? err.message : "Could not load settings."));
  }, []);
  if (error) return <Notice tone="warn">{error}</Notice>;
  if (!data) return <p className="text-muted">Loading settings…</p>;
  if (plans) {
    return (
      <div className="grid gap-4">
        <h1 className="font-display text-3xl">Plans</h1>
        <section className="card p-5">
          <p className="font-medium">Founder's Plan</p>
          <p className="mt-1 text-sm">{foundersPriceLabel()}/month on the website. Billing is not connected, so this price is display only.</p>
        </section>
      </div>
    );
  }
  return (
    <div className="grid gap-4">
      <h1 className="font-display text-3xl">Platform settings</h1>
      <form className="card grid gap-3 p-5" onSubmit={(event) => {
        event.preventDefault();
        void saveHqSettings({ data: { announcement, supportPolicy: policy } })
          .then(() => setMessage("Saved inside BookBloom HQ. It was not published on the website."))
          .catch((err: unknown) => setError(err instanceof Error ? err.message : "Settings were not saved."));
      }}>
        <label className="grid gap-1 text-sm">Internal announcement<input className="field-input" value={announcement} onChange={(event) => setAnnouncement(event.target.value)} /></label>
        <label className="grid gap-1 text-sm">Support policy<textarea className="field-input min-h-24" value={policy} onChange={(event) => setPolicy(event.target.value)} /></label>
        <button className="btn btn-primary w-fit" type="submit">Save</button>
        {message ? <p className="text-sm text-muted">{message}</p> : null}
      </form>
      <ul className="grid gap-3">
        {data.flags.map((flag) => (
          <li key={flag.name} className="card p-4 text-sm">
            <p className="font-medium">{flag.name}: {flag.enabled ? "On" : "Off"}</p>
            <p className="text-muted">{flag.note}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Activity() {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof getHqActivity>> | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    void getHqActivity().then(setRows).catch((err: unknown) => setError(err instanceof Error ? err.message : "Could not load activity."));
  }, []);
  if (error) return <Notice tone="warn">{error}</Notice>;
  if (!rows) return <p className="text-muted">Loading activity…</p>;
  return (
    <div className="grid gap-4">
      <h1 className="font-display text-3xl">Activity and security</h1>
      {rows.length === 0 ? <p className="text-sm text-muted">No owner actions have been recorded.</p> : (
        <ul className="divide-y divide-line rounded-2xl border border-line bg-surface text-sm">
          {rows.map((row) => <li key={row.id} className="flex justify-between gap-3 p-3"><span>{row.action}<span className="block text-muted">{row.email}</span></span><span className="text-muted">{new Date(row.createdAt).toLocaleString()}</span></li>)}
        </ul>
      )}
    </div>
  );
}

function Metric({ label, value, note }: { label: string; value: string; note?: string }) {
  return (
    <section className="card p-4">
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-1 font-display text-2xl">{value}</p>
      {note ? <p className="mt-1 text-xs text-muted">{note}</p> : null}
    </section>
  );
}
