import { createFileRoute, Link } from "@tanstack/react-router";
import { Logo } from "@/components/logo";

export const Route = createFileRoute("/privacy")({ component: PrivacyPage });

function PrivacyPage() {
  return (
    <main className="mx-auto max-w-2xl px-4 py-12">
      <Logo />
      <h1 className="mt-6 font-display text-4xl">Privacy Policy</h1>
      <div className="mt-6 grid gap-4 text-sm leading-relaxed text-muted">
        <p>An account stores the name, email, and password you submit. The password is stored only as a hash. BookBloom does not show it back to you.</p>
        <p>Business records you add — company profile, leads, estimates, drafts, and follow-ups — are stored for that signed-in account. Other business accounts do not receive them. The public demo does not save what you type.</p>
        <p>Email verification and password-reset messages are not sent, because email delivery is not configured. Signing in with Google or X uses the connected sign-in service and does not give BookBloom your social password.</p>
        <p>Do not rely on this workspace for real customer contact details until you have reviewed access for your own deployment. There is no administrator console that can browse those records.</p>
        <p><Link to="/terms" className="text-accent">Terms of Service</Link></p>
      </div>
    </main>
  );
}
