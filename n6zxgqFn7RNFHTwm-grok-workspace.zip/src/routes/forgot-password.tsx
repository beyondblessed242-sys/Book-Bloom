import { createFileRoute, Link } from "@tanstack/react-router";
import { Notice } from "@/components/field";
import { Logo } from "@/components/logo";

export const Route = createFileRoute("/forgot-password")({
  component: ForgotPasswordPage,
});

function ForgotPasswordPage() {
  return (
    <main className="mx-auto grid min-h-screen max-w-md place-items-center px-4 py-12">
      <div className="card w-full p-6 sm:p-8">
        <Logo />
        <h1 className="mt-6 font-display text-4xl leading-tight">Password recovery</h1>
        <div className="mt-4">
          <Notice tone="warn">
            Email-based password recovery is temporarily unavailable. No message is sent, and your password is not changed. Sign in with your current password if you still know it.
          </Notice>
        </div>
        <p className="mt-6 text-sm">
          <Link to="/login" search={{ next: "/app", mode: "sign-in" }} className="text-accent">Back to sign in</Link>
        </p>
      </div>
    </main>
  );
}
