import { createFileRoute, Link } from "@tanstack/react-router";
import { Logo } from "@/components/logo";

export const Route = createFileRoute("/terms")({ component: TermsPage });

function TermsPage() {
  return (
    <main className="mx-auto max-w-2xl px-4 py-12">
      <Logo />
      <h1 className="mt-6 font-display text-4xl">Terms of Service</h1>
      <div className="mt-6 grid gap-4 text-sm leading-relaxed text-muted">
        <p>BookBloom AI is a workspace for a cleaning business to keep leads, prepare estimates from its own rates, and write message drafts.</p>
        <p>Creating an account is free and does not start a subscription. The Founder's Plan price is proposed until payments are configured and tested. A success page does not unlock a paid plan.</p>
        <p>Message drafts stay in the app until you copy them. BookBloom does not email or text your customers, and it does not confirm bookings.</p>
        <p>You are responsible for the customer details you type in. Do not put real customer information in the public demo. The demo uses fictional sample leads and does not save them to an account.</p>
        <p>Accounts cannot assign themselves an administrator role. Privileged access is not available.</p>
        <p><Link to="/privacy" className="text-accent">Privacy Policy</Link></p>
      </div>
    </main>
  );
}
