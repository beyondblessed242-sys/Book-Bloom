import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { BillingPanel } from "@/components/dashboard/billing-panel";
import { FollowUpsPanel } from "@/components/dashboard/followups-panel";
import { LeadsPanel } from "@/components/dashboard/leads-panel";
import { MessagesPanel } from "@/components/dashboard/messages-panel";
import { OverviewPanel } from "@/components/dashboard/overview-panel";
import { QuotesPanel } from "@/components/dashboard/quotes-panel";
import { SettingsPanel } from "@/components/dashboard/settings-panel";
import { Shell, type SectionId } from "@/components/dashboard/shell";
import { DemoWorkspace } from "@/components/dashboard/workspace";

export const Route = createFileRoute("/demo")({ component: DemoPage });

function DemoPage() {
  const [section, setSection] = useState<SectionId>("overview");
  return (
    <DemoWorkspace>
      <Shell current={section} onNavigate={setSection}>
        {section === "overview" ? <OverviewPanel /> : null}
        {section === "leads" ? <LeadsPanel /> : null}
        {section === "quotes" ? <QuotesPanel /> : null}
        {section === "messages" ? <MessagesPanel /> : null}
        {section === "follow-ups" ? <FollowUpsPanel /> : null}
        {section === "settings" ? <SettingsPanel /> : null}
        {section === "billing" ? <BillingPanel /> : null}
      </Shell>
    </DemoWorkspace>
  );
}
