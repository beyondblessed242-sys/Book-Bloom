import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { Notice } from "@/components/field";

export const Route = createFileRoute("/billing/success")({ component: BillingSuccess });

function BillingSuccess() {
  return (
    <div>
      <SiteHeader />
      <main className="mx-auto grid max-w-xl gap-4 px-4 py-16">
        <h1 className="font-display text-4xl">Nothing was purchased</h1>
        <Notice tone="warn">
          BookBloom does not treat this address as a successful payment. No subscription was started, and no paid access was granted. Stripe is not connected.
        </Notice>
        <div className="flex flex-wrap gap-2">
          <Link to="/" className="btn btn-secondary">Back home</Link>
          <Link to="/app/billing" className="btn btn-primary">View the plan</Link>
        </div>
      </main>
    </div>
  );
}
