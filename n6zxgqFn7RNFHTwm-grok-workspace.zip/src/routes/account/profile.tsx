import { createFileRoute } from "@tanstack/react-router";
import { ProfileScreen } from "@/components/account/screens";

export const Route = createFileRoute("/account/profile")({ component: ProfileScreen });
