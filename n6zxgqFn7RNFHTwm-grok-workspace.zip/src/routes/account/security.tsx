import { createFileRoute } from "@tanstack/react-router";
import { SecurityScreen } from "@/components/account/screens";

export const Route = createFileRoute("/account/security")({ component: SecurityScreen });
