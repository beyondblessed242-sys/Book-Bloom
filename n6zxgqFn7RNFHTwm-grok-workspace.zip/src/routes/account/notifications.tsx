import { createFileRoute } from "@tanstack/react-router";
import { NotificationsScreen } from "@/components/account/screens";

export const Route = createFileRoute("/account/notifications")({ component: NotificationsScreen });
