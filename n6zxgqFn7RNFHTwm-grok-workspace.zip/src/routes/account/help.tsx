import { createFileRoute } from "@tanstack/react-router";
import { HelpScreen } from "@/components/account/screens";

export const Route = createFileRoute("/account/help")({ component: HelpScreen });
