import { createFileRoute } from "@tanstack/react-router";
import { SubscriptionScreen } from "@/components/account/screens";

export const Route = createFileRoute("/account/subscription")({ component: SubscriptionScreen });
