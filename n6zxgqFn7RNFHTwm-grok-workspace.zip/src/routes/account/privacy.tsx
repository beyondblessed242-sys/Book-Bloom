import { createFileRoute } from "@tanstack/react-router";
import { PrivacyScreen } from "@/components/account/screens";

export const Route = createFileRoute("/account/privacy")({ component: PrivacyScreen });
