import { useState } from "react";
import { createFileRoute, Link, Navigate, useNavigate } from "@tanstack/react-router";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { PasswordField } from "@/components/auth/password-field";
import { Field } from "@/components/field";
import { Logo } from "@/components/logo";
import { postLoginPath } from "@/lib/auth/post-login";
import { signInWithEmail, signUpWithEmail, verifySignInTotp } from "@/lib/email-session";
import { passwordError, passwordRules } from "@/lib/password-policy";
import { resolveWorkspaceEntry } from "@/server/entry";

export const Route = createFileRoute("/login")({
  validateSearch: (search: Record<string, unknown>) => ({
    next: typeof search.next === "string" ? search.next : "/app",
    mode: search.mode === "sign-in" ? ("sign-in" as const) : ("create" as const),
  }),
  component: LoginPage,
});

function LoginPage() {
  const { next, mode } = Route.useSearch();
  const navigate = useNavigate();
  const destination = postLoginPath({ requested: next });
  const { user, isPending } = useCurrentUserState();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [remember, setRemember] = useState(true);
  const [accepted, setAccepted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [challenge, setChallenge] = useState(false);
  const [mfaCode, setMfaCode] = useState("");
  const creating = mode === "create";

  if (isPending) {
    return <main className="grid min-h-screen place-items-center text-muted">Checking your session…</main>;
  }
  if (user) return <Navigate to={destination} />;

  function switchMode(nextMode: "create" | "sign-in") {
    setError(null);
    setPassword("");
    setConfirm("");
    void navigate({ to: "/login", search: { next, mode: nextMode }, replace: true });
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    if (creating && name.trim().length < 2) {
      setError("Add the name you want on the account.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError("Enter a valid email address.");
      return;
    }
    const passwordProblem = passwordError(password);
    if (passwordProblem) {
      setError(passwordProblem);
      return;
    }
    if (creating && confirm !== password) {
      setError("Those passwords do not match.");
      return;
    }
    if (creating && !accepted) {
      setError("Agree to the Terms of Service and Privacy Policy to create an account.");
      return;
    }
    setBusy(true);
    try {
      if (creating) {
        await signUpWithEmail({ name: name.trim(), email: email.trim(), password });
        const entry = await resolveWorkspaceEntry({ data: { requested: next } });
        window.location.assign(entry.path);
        return;
      }
      const signedIn = await signInWithEmail({ email: email.trim(), password, rememberMe: remember });
      if (signedIn === "two-factor") {
        setChallenge(true);
        setBusy(false);
        return;
      }
      const entry = await resolveWorkspaceEntry({ data: { requested: next } });
      window.location.assign(entry.path);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not sign in.");
      setBusy(false);
    }
  }

  async function submitCode(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await verifySignInTotp(mfaCode.replace(/\s/g, ""));
      const entry = await resolveWorkspaceEntry({ data: { requested: next } });
      window.location.assign(entry.path);
    } catch (err) {
      setError(err instanceof Error ? err.message : "That authenticator code was not accepted.");
      setBusy(false);
    }
  }

  return (
    <main className="grid min-h-screen place-items-center bg-bg px-4 py-8">
      <div className="w-full max-w-[27rem]">
        <div className="mb-5 flex justify-center">
          <Logo />
        </div>
        <div className="card px-5 py-6 sm:px-7 sm:py-7">
          <h1 className="text-center font-display text-3xl leading-tight">
            {creating ? "Start Growing Your Cleaning Business" : "Welcome Back"}
          </h1>
          <p className="mt-2 text-center text-sm leading-relaxed text-muted">
            {creating
              ? "Create your free account and discover a smarter way to manage your cleaning business."
              : "Your business workspace is ready."}
          </p>
          {challenge ? (
            <form className="mt-6 grid gap-3.5" onSubmit={(event) => void submitCode(event)}>
              <Field label="Authenticator code">
                <input className="field-input" inputMode="numeric" autoComplete="one-time-code" value={mfaCode} onChange={(event) => setMfaCode(event.target.value)} required />
              </Field>
              {error ? <p className="text-sm text-red-800" role="alert">{error}</p> : null}
              <button className="btn btn-primary w-full" type="submit" disabled={busy}>{busy ? "Checking…" : "Verify code"}</button>
            </form>
          ) : (
          <form className="mt-6 grid gap-3.5" onSubmit={(event) => void submit(event)} noValidate aria-busy={busy}>
            {creating ? (
              <Field label="Your name">
                <input className="field-input" autoComplete="name" value={name} onChange={(event) => setName(event.target.value)} required />
              </Field>
            ) : null}
            <Field label="Email address">
              <input
                className="field-input"
                type="email"
                autoComplete="email"
                inputMode="email"
                spellCheck={false}
                required
                value={email}
                onChange={(event) => setEmail(event.target.value)}
              />
            </Field>
            <PasswordField
              label="Password"
              value={password}
              onChange={setPassword}
              autoComplete={creating ? "new-password" : "current-password"}
              shown={showPassword}
              onToggle={() => setShowPassword((value) => !value)}
              action={creating ? undefined : (
                <Link to="/forgot-password" className="text-sm font-medium text-accent">Forgot Password?</Link>
              )}
            />
            {creating ? (
              <>
                <ul className="grid gap-1 text-xs" aria-live="polite">
                  {passwordRules(password).map((rule) => (
                    <li key={rule.id} className={rule.met ? "text-accent" : "text-muted"}>
                      {rule.met ? "Met" : "Needed"} — {rule.label}
                    </li>
                  ))}
                </ul>
                <PasswordField
                  label="Confirm password"
                  value={confirm}
                  onChange={setConfirm}
                  autoComplete="new-password"
                  shown={showConfirm}
                  onToggle={() => setShowConfirm((value) => !value)}
                  error={confirm && confirm !== password ? "Those passwords do not match." : undefined}
                />
                <label className="flex items-start gap-3 text-sm">
                  <input
                    type="checkbox"
                    className="mt-1 size-4 accent-[var(--color-accent)]"
                    checked={accepted}
                    onChange={(event) => setAccepted(event.target.checked)}
                  />
                  <span>
                    I agree to the <Link to="/terms" className="text-accent">Terms of Service</Link> and{" "}
                    <Link to="/privacy" className="text-accent">Privacy Policy</Link>.
                  </span>
                </label>
              </>
            ) : (
              <label className="flex items-center gap-3 text-sm">
                <input
                  type="checkbox"
                  className="size-4 accent-[var(--color-accent)]"
                  checked={remember}
                  onChange={(event) => setRemember(event.target.checked)}
                />
                Remember me
              </label>
            )}
            {error ? <p className="text-sm text-warn" role="alert">{error}</p> : null}
            <button className="btn btn-primary w-full" type="submit" disabled={busy}>
              {busy ? (creating ? "Creating account…" : "Signing in…") : creating ? "Create Free Account" : "Sign In"}
            </button>
          </form>
          )}
          {creating ? (
            <p className="mt-3 text-sm text-muted">Creating an account does not start a paid subscription.</p>
          ) : (
            <p className="mt-3 text-sm text-muted">Email-based password recovery is temporarily unavailable.</p>
          )}
          <div className="mt-5 flex items-center justify-between gap-3 text-sm">
            <button type="button" className="font-medium text-accent" onClick={() => switchMode(creating ? "sign-in" : "create")}>
              {creating ? "Sign in" : "Create an Account"}
            </button>
            <Link to="/" className="text-muted">Back to Home</Link>
          </div>
        </div>
      </div>
    </main>
  );
}
