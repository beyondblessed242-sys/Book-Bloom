import { createFileRoute, Link } from "@tanstack/react-router";
import { Notice } from "@/components/field";
import { Logo } from "@/components/logo";

export const Route = createFileRoute("/email-verified")({
  validateSearch: (search: Record<string, unknown>) => ({
    error: typeof search.error === "string" ? search.error : "",
    verified: search.verified === "1" || search.verified === 1 || search.verified === true || search.verified === "true",
  }),
  component: EmailVerifiedPage,
});

function EmailVerifiedPage() {
  const { error, verified } = Route.useSearch();
  return (
    <main className="mx-auto grid min-h-screen max-w-md place-items-center px-4 py-12">
      <div className="card w-full p-6 sm:p-8">
        <Logo />
        <h1 className="mt-6 font-display text-4xl leading-tight">Email verification</h1>
        <div className="mt-4">
          {error ? (
            <Notice tone="warn">
              This verification link was not accepted ({error}). No change was made, and the address was not marked verified.
            </Notice>
          ) : verified ? (
            <Notice>
              Your email is verified. You can open your workspace. This does not start a subscription or grant admin access.
            </Notice>
          ) : (
            <Notice>
              Open the verification link from your email. Visiting this page on its own does not verify an address.
            </Notice>
          )}
        </div>
        <div className="mt-6">
          <Link to="/app" className="btn btn-primary">Open workspace</Link>
        </div>
      </div>
    </main>
  );
}
