import { createFileRoute, Outlet } from "@tanstack/react-router";
import { AccountShell } from "@/components/account/account-shell";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/account")({ component: AccountLayout });

function AccountLayout() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <main className="grid min-h-screen place-items-center text-muted">Checking your session…</main>;
  if (!user) return <RedirectToSignIn />;
  return (
    <AccountShell>
      <Outlet />
    </AccountShell>
  );
}
