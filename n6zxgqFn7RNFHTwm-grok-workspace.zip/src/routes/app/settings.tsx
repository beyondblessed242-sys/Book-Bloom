import { createFileRoute } from "@tanstack/react-router";
import { SettingsPanel } from "@/components/dashboard/settings-panel";

export const Route = createFileRoute("/app/settings")({ component: SettingsPanel });
