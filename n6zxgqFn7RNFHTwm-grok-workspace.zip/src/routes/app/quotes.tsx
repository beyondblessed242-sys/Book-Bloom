import { createFileRoute } from "@tanstack/react-router";
import { QuotesPanel } from "@/components/dashboard/quotes-panel";

export const Route = createFileRoute("/app/quotes")({ component: QuotesPanel });
