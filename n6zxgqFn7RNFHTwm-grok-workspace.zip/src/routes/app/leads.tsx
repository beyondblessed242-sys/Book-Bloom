import { createFileRoute } from "@tanstack/react-router";
import { LeadsPanel } from "@/components/dashboard/leads-panel";

export const Route = createFileRoute("/app/leads")({ component: LeadsPanel });
