import { createFileRoute, useSearch } from "@tanstack/react-router";
import { BillingPanel } from "@/components/dashboard/billing-panel";

export const Route = createFileRoute("/app/billing")({ component: BillingRoute });

function BillingRoute() {
  const search = useSearch({ strict: false }) as { checkout?: unknown };
  return <BillingPanel checkout={search.checkout === "success"} />;
}
