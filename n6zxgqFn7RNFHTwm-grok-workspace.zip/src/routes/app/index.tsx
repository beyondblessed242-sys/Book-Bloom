import { createFileRoute } from "@tanstack/react-router";
import { OverviewPanel } from "@/components/dashboard/overview-panel";

export const Route = createFileRoute("/app/")({ component: OverviewPanel });
