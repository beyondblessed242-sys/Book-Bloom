import { createFileRoute } from "@tanstack/react-router";
import { MessagesPanel } from "@/components/dashboard/messages-panel";

export const Route = createFileRoute("/app/messages")({ component: MessagesPanel });
