import { createFileRoute } from "@tanstack/react-router";
import { FollowUpsPanel } from "@/components/dashboard/followups-panel";

export const Route = createFileRoute("/app/follow-ups")({ component: FollowUpsPanel });
