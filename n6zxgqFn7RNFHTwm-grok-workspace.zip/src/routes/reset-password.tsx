import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { PasswordField } from "@/components/auth/password-field";
import { Notice } from "@/components/field";
import { Logo } from "@/components/logo";
import { resetPasswordWithToken } from "@/lib/email-session";
import { passwordError, passwordRules } from "@/lib/password-policy";

export const Route = createFileRoute("/reset-password")({
  validateSearch: (search: Record<string, unknown>) => ({
    token: typeof search.token === "string" ? search.token : "",
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const { token } = Route.useSearch();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    const problem = passwordError(password);
    if (problem) {
      setError(problem);
      return;
    }
    if (confirm !== password) {
      setError("Those passwords do not match.");
      return;
    }
    setBusy(true);
    try {
      await resetPasswordWithToken({ token, newPassword: password });
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "This reset link is not valid.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto grid min-h-screen max-w-md place-items-center px-4 py-12">
      <div className="card w-full p-6 sm:p-8">
        <Logo />
        <h1 className="mt-6 font-display text-4xl leading-tight">Choose a new password</h1>
        {token ? (
          done ? (
            <div className="mt-4 grid gap-4">
              <Notice>Your password was updated. Sign in with the new one. This did not start a subscription.</Notice>
              <Link to="/login" search={{ next: "/app", mode: "sign-in" }} className="btn btn-primary">Sign In</Link>
            </div>
          ) : (
            <form className="mt-6 grid gap-4" onSubmit={(event) => void submit(event)} noValidate>
              <PasswordField
                label="New password"
                value={password}
                onChange={setPassword}
                autoComplete="new-password"
                shown={showPassword}
                onToggle={() => setShowPassword((value) => !value)}
              />
              <ul className="grid gap-1 text-xs" aria-live="polite">
                {passwordRules(password).map((rule) => (
                  <li key={rule.id} className={rule.met ? "text-accent" : "text-muted"}>
                    {rule.met ? "Met" : "Needed"} — {rule.label}
                  </li>
                ))}
              </ul>
              <PasswordField
                label="Confirm password"
                value={confirm}
                onChange={setConfirm}
                autoComplete="new-password"
                shown={showConfirm}
                onToggle={() => setShowConfirm((value) => !value)}
                error={confirm && confirm !== password ? "Those passwords do not match." : undefined}
              />
              {error ? <p className="text-sm text-warn" role="alert">{error}</p> : null}
              <button className="btn btn-primary" type="submit" disabled={busy}>
                {busy ? "Updating…" : "Update password"}
              </button>
            </form>
          )
        ) : (
          <div className="mt-4 grid gap-4">
            <Notice tone="warn">
              This page needs a reset link. Email delivery is not configured, so BookBloom is not sending those links yet. Your password was not changed.
            </Notice>
            <Link to="/forgot-password" className="text-sm text-accent">Request a reset</Link>
          </div>
        )}
      </div>
    </main>
  );
}
