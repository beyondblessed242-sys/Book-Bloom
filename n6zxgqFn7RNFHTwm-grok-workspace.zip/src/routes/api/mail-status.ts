import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/mail-status")({
  server: {
    handlers: {
      GET: async () => Response.json({ error: "not_found" }, { status: 404 }),
    },
  },
});
