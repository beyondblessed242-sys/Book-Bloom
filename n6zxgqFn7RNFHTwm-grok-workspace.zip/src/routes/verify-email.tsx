import { createFileRoute, Link } from "@tanstack/react-router";
import { Notice } from "@/components/field";
import { Logo } from "@/components/logo";

export const Route = createFileRoute("/verify-email")({
  component: VerifyEmailPage,
});

function VerifyEmailPage() {
  return (
    <main className="mx-auto grid min-h-screen max-w-md place-items-center px-4 py-12">
      <div className="card w-full p-6 sm:p-8">
        <Logo />
        <h1 className="mt-6 font-display text-4xl leading-tight">Email verification</h1>
        <div className="mt-4">
          <Notice>
            Email verification is not required to use your workspace. Your account is not marked verified by visiting this page.
          </Notice>
        </div>
        <div className="mt-6">
          <Link to="/app" className="btn btn-primary">Open workspace</Link>
        </div>
      </div>
    </main>
  );
}
