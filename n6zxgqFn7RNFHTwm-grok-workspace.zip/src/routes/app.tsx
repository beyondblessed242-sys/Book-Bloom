import { createFileRoute, Outlet, useRouterState } from "@tanstack/react-router";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { sectionFromPath, Shell } from "@/components/dashboard/shell";
import { LiveWorkspace } from "@/components/dashboard/workspace";

export const Route = createFileRoute("/app")({ component: AppLayout });

function AppLayout() {
  const { user, isPending } = useCurrentUserState();
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  if (isPending) {
    return <main className="grid min-h-screen place-items-center text-muted">Checking your session…</main>;
  }
  if (!user) return <RedirectToSignIn />;
  return (
    <LiveWorkspace>
      <Shell current={sectionFromPath(pathname)}>
        <Outlet />
      </Shell>
    </LiveWorkspace>
  );
}
