import { createHash, randomUUID } from "node:crypto";
import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { authMiddleware } from "@/lib/auth/middleware";
import { auth, readSessionToken } from "@/lib/auth/server";
import { getSql } from "@/lib/db";
import { decideHqAccess } from "@/lib/hq-gate";
import { FOUNDERS_MONTHLY_CENTS, SUBSCRIPTION_BILLING_LIVE } from "@/lib/pricing";

const PROOF_MS = 10 * 60 * 1000;

function headersFor(bearerToken?: string): Headers {
  const headers = new Headers(getRequest()?.headers);
  if (bearerToken) headers.set("Authorization", `Bearer ${bearerToken}`);
  return headers;
}

function sessionKey(bearerToken?: string): string | null {
  const token = bearerToken || readSessionToken();
  if (!token) return null;
  return createHash("sha256").update(token).digest("hex");
}

function stamp(value: string | Date | null | undefined): string | null {
  if (!value) return null;
  return value instanceof Date ? value.toISOString() : String(value);
}

async function readAccess(userId: string, bearerToken?: string) {
  const sql = await getSql();
  const role = await sql<{ role: string }>`
    select role from admin_role_assignments where user_id = ${userId}
  `;
  const user = await sql<{ twoFactorEnabled: boolean }>`
    select "twoFactorEnabled" from "user" where id = ${userId}
  `;
  const key = sessionKey(bearerToken);
  const proof = key
    ? await sql<{ expires_at: string | Date }>`
        select expires_at from admin_mfa_proofs
        where user_id = ${userId} and session_key = ${key}
      `
    : [];
  return decideHqAccess({
    assignedRole: role[0]?.role ?? null,
    twoFactorEnabled: user[0]?.twoFactorEnabled === true,
    mfaProofExpiresAt: stamp(proof[0]?.expires_at),
    sessionMatches: Boolean(proof[0]),
    now: Date.now(),
  });
}

async function requireOwner(userId: string, bearerToken?: string) {
  const access = await readAccess(userId, bearerToken);
  if (!access.allowed) throw new Error("Not authorized.");
}

async function audit(actorUserId: string, action: string, target = "") {
  const sql = await getSql();
  await sql`
    insert into hq_audit_log (id, actor_user_id, action, target)
    values (${randomUUID()}, ${actorUserId}, ${action}, ${target.slice(0, 160)})
  `;
}

export const getHqAccess = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => readAccess(context.userId, context.bearerToken));

export const confirmHqMfa = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { code?: string }) => {
    const code = (data.code ?? "").replace(/\s/g, "");
    if (!/^\d{6}$/.test(code)) throw new Error("Enter the 6-digit authenticator code.");
    return { code };
  })
  .handler(async ({ context, data }) => {
    const before = await readAccess(context.userId, context.bearerToken);
    if (!before.needsCode) return before;
    try {
      await auth.api.verifyTOTP({
        body: { code: data.code },
        headers: headersFor(context.bearerToken),
      });
    } catch {
      throw new Error("That authenticator code was not accepted. BookBloom HQ stayed closed.");
    }
    const key = sessionKey(context.bearerToken);
    if (!key) throw new Error("This session could not be confirmed. Sign in again.");
    const sql = await getSql();
    const expires = new Date(Date.now() + PROOF_MS).toISOString();
    await sql`
      insert into admin_mfa_proofs (user_id, expires_at, session_key)
      values (${context.userId}, ${expires}, ${key})
      on conflict (user_id) do update set expires_at = ${expires}, session_key = ${key}
    `;
    await audit(context.userId, "hq_mfa_confirmed");
    return readAccess(context.userId, context.bearerToken);
  });

export const getHqOverview = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireOwner(context.userId, context.bearerToken);
    const sql = await getSql();
    const users = await sql<{ total: number; this_month: number }>`
      select count(*) as total,
        count(*) filter (where "createdAt" >= date_trunc('month', now())) as this_month
      from "user"
    `;
    const businesses = await sql<{ total: number }>`select count(*) as total from businesses`;
    const cases = await sql<{ open: number }>`
      select count(*) as open from hq_cases where status <> 'resolved'
    `;
    const recent = await sql<{ id: string; name: string; email: string; createdAt: string | Date }>`
      select id, name, email, "createdAt" from "user" order by "createdAt" desc limit 8
    `;
    return {
      users: Number(users[0]?.total ?? 0),
      newUsersThisMonth: Number(users[0]?.this_month ?? 0),
      businesses: Number(businesses[0]?.total ?? 0),
      openSupportCases: Number(cases[0]?.open ?? 0),
      subscriptions: { state: "unavailable" as const, reason: "Stripe is not connected. No subscription count is available." },
      revenue: { state: "unavailable" as const, reason: "Monthly recurring revenue is unavailable until verified Stripe billing exists." },
      recentSignups: recent.map((row) => ({
        id: row.id,
        name: row.name,
        email: row.email,
        createdAt: stamp(row.createdAt) ?? "",
      })),
      recentBilling: [] as [],
    };
  });

export const getHqUsers = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((data: { query?: string }) => ({ query: (data.query ?? "").trim().slice(0, 80) }))
  .handler(async ({ context, data }) => {
    await requireOwner(context.userId, context.bearerToken);
    const sql = await getSql();
    const pattern = `%${data.query.replace(/[%_]/g, "")}%`;
    const rows = await sql<{
      id: string;
      name: string;
      email: string;
      emailVerified: boolean;
      createdAt: string | Date;
      company_name: string | null;
      last_activity: string | Date | null;
    }>`
      select u.id, u.name, u.email, u."emailVerified", u."createdAt", b.company_name,
        (select max(s."updatedAt") from session s where s."userId" = u.id) as last_activity
      from "user" u
      left join businesses b on b.user_id = u.id
      where ${data.query} = '' or u.name ilike ${pattern} or u.email ilike ${pattern} or coalesce(b.company_name, '') ilike ${pattern}
      order by u."createdAt" desc
      limit 50
    `;
    return rows.map((row) => ({
      id: row.id,
      name: row.name,
      email: row.email,
      createdAt: stamp(row.createdAt) ?? "",
      business: row.company_name || "No business profile",
      accountStatus: row.emailVerified ? "Email confirmed" : "Email not confirmed",
      subscriptionStatus: SUBSCRIPTION_BILLING_LIVE ? "Check Stripe" : "Unavailable",
      lastActivity: stamp(row.last_activity),
    }));
  });

export const getHqUser = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((data: { userId?: string }) => {
    const userId = (data.userId ?? "").trim();
    if (!/^[A-Za-z0-9]{8,64}$/.test(userId)) throw new Error("That account was not found.");
    return { userId };
  })
  .handler(async ({ context, data }) => {
    await requireOwner(context.userId, context.bearerToken);
    const sql = await getSql();
    const rows = await sql<{
      id: string;
      name: string;
      email: string;
      emailVerified: boolean;
      createdAt: string | Date;
      company_name: string | null;
      last_activity: string | Date | null;
      leads: number;
      quotes: number;
      follow_ups: number;
    }>`
      select u.id, u.name, u.email, u."emailVerified", u."createdAt", b.company_name,
        (select max(s."updatedAt") from session s where s."userId" = u.id) as last_activity,
        (select count(*) from leads l where l.user_id = u.id) as leads,
        (select count(*) from quotes q where q.user_id = u.id) as quotes,
        (select count(*) from follow_ups f where f.user_id = u.id) as follow_ups
      from "user" u
      left join businesses b on b.user_id = u.id
      where u.id = ${data.userId}
    `;
    const row = rows[0];
    if (!row) throw new Error("That account was not found.");
    return {
      id: row.id,
      name: row.name,
      email: row.email,
      createdAt: stamp(row.createdAt) ?? "",
      business: row.company_name || "No business profile",
      accountStatus: row.emailVerified ? "Email confirmed" : "Email not confirmed",
      subscriptionStatus: "Unavailable — Stripe is not connected",
      lastActivity: stamp(row.last_activity),
      leadCount: Number(row.leads ?? 0),
      estimateCount: Number(row.quotes ?? 0),
      followUpCount: Number(row.follow_ups ?? 0),
      supportNote: "Password resets, email changes, and role changes are not available from BookBloom HQ.",
    };
  });

export const getHqBusinesses = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireOwner(context.userId, context.bearerToken);
    const sql = await getSql();
    const rows = await sql<{
      id: string;
      company_name: string;
      owner_name: string;
      email: string;
      created_at: string | Date;
      leads: number;
      quotes: number;
      follow_ups: number;
    }>`
      select b.id, b.company_name, b.owner_name, u.email, b.created_at,
        (select count(*) from leads l where l.user_id = b.user_id) as leads,
        (select count(*) from quotes q where q.user_id = b.user_id) as quotes,
        (select count(*) from follow_ups f where f.user_id = b.user_id) as follow_ups
      from businesses b
      join "user" u on u.id = b.user_id
      order by b.created_at desc
      limit 50
    `;
    return rows.map((row) => ({
      id: row.id,
      name: row.company_name || "Untitled business",
      owner: row.owner_name || row.email,
      createdAt: stamp(row.created_at) ?? "",
      industry: "Not recorded",
      accountStatus: "Registered",
      plan: SUBSCRIPTION_BILLING_LIVE ? "Founder's Plan" : "Unavailable",
      leads: Number(row.leads ?? 0),
      estimates: Number(row.quotes ?? 0),
      followUps: Number(row.follow_ups ?? 0),
    }));
  });

export const getHqBilling = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireOwner(context.userId, context.bearerToken);
    return {
      connected: SUBSCRIPTION_BILLING_LIVE,
      plan: "Founder's Plan",
      priceCents: FOUNDERS_MONTHLY_CENTS,
      subscriptions: [] as [],
      invoices: [] as [],
      refunds: [] as [],
      reason: "Stripe is not connected. There are no paid, unpaid, failed, or refunded payment records to show.",
    };
  });

const categories = ["billing", "access", "product", "other"] as const;
const priorities = ["low", "normal", "high"] as const;
const statuses = ["open", "waiting", "resolved"] as const;

export const getHqCases = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireOwner(context.userId, context.bearerToken);
    const sql = await getSql();
    const rows = await sql<{
      id: string;
      user_id: string | null;
      subject: string;
      category: string;
      priority: string;
      status: string;
      notes: string;
      resolution: string;
      email: string | null;
      updated_at: string | Date;
    }>`
      select c.id, c.user_id, c.subject, c.category, c.priority, c.status, c.notes, c.resolution, u.email, c.updated_at
      from hq_cases c
      left join "user" u on u.id = c.user_id
      order by c.updated_at desc
      limit 50
    `;
    return rows.map((row) => ({
      id: row.id,
      userId: row.user_id,
      customer: row.email || "No customer linked",
      subject: row.subject,
      category: row.category,
      priority: row.priority,
      status: row.status,
      notes: row.notes,
      resolution: row.resolution,
      updatedAt: stamp(row.updated_at) ?? "",
    }));
  });

export const saveHqCase = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: {
    id?: string;
    userId?: string;
    subject?: string;
    category?: string;
    priority?: string;
    status?: string;
    notes?: string;
    resolution?: string;
  }) => {
    const subject = (data.subject ?? "").trim();
    if (subject.length < 3 || subject.length > 120) throw new Error("Subject must be 3 to 120 characters.");
    if (!categories.includes(data.category as (typeof categories)[number])) throw new Error("Choose a category.");
    if (!priorities.includes(data.priority as (typeof priorities)[number])) throw new Error("Choose a priority.");
    if (!statuses.includes(data.status as (typeof statuses)[number])) throw new Error("Choose a status.");
    const userId = (data.userId ?? "").trim();
    if (userId && !/^[A-Za-z0-9]{8,64}$/.test(userId)) throw new Error("That customer was not found.");
    return {
      id: (data.id ?? "").trim(),
      userId,
      subject,
      category: data.category as (typeof categories)[number],
      priority: data.priority as (typeof priorities)[number],
      status: data.status as (typeof statuses)[number],
      notes: (data.notes ?? "").trim().slice(0, 2000),
      resolution: (data.resolution ?? "").trim().slice(0, 2000),
    };
  })
  .handler(async ({ context, data }) => {
    await requireOwner(context.userId, context.bearerToken);
    const sql = await getSql();
    if (data.userId) {
      const found = await sql<{ id: string }>`select id from "user" where id = ${data.userId}`;
      if (!found[0]) throw new Error("That customer was not found. The case was not saved.");
    }
    const id = data.id || randomUUID();
    await sql`
      insert into hq_cases (id, user_id, subject, category, priority, status, notes, resolution)
      values (${id}, ${data.userId || null}, ${data.subject}, ${data.category}, ${data.priority}, ${data.status}, ${data.notes}, ${data.resolution})
      on conflict (id) do update set
        user_id = ${data.userId || null},
        subject = ${data.subject},
        category = ${data.category},
        priority = ${data.priority},
        status = ${data.status},
        notes = ${data.notes},
        resolution = ${data.resolution},
        updated_at = now()
    `;
    await audit(context.userId, data.id ? "hq_case_updated" : "hq_case_created", id);
    return { id };
  });

export const getHqAnalytics = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireOwner(context.userId, context.bearerToken);
    const sql = await getSql();
    const months = await sql<{ month: string; total: number }>`
      select to_char(date_trunc('month', "createdAt"), 'YYYY-MM') as month, count(*) as total
      from "user"
      group by 1
      order by 1
    `;
    const counts = await sql<{ businesses: number; leads: number; quotes: number; follow_ups: number; drafts: number; recent: number }>`
      select
        (select count(*) from businesses) as businesses,
        (select count(*) from leads) as leads,
        (select count(*) from quotes) as quotes,
        (select count(*) from follow_ups) as follow_ups,
        (select count(*) from ai_usage) as drafts,
        (select count(distinct "userId") from session where "updatedAt" > now() - interval '30 days') as recent
    `;
    const row = counts[0];
    return {
      registrations: months.map((item) => ({ month: item.month, total: Number(item.total) })),
      businesses: Number(row?.businesses ?? 0),
      leads: Number(row?.leads ?? 0),
      estimates: Number(row?.quotes ?? 0),
      followUps: Number(row?.follow_ups ?? 0),
      messageDrafts: Number(row?.drafts ?? 0),
      activeSessions30Days: Number(row?.recent ?? 0),
      retention: { state: "unavailable" as const, reason: "Customer retention needs billing history, and Stripe is not connected." },
      subscriptionGrowth: { state: "unavailable" as const, reason: "Subscription growth is unavailable until Stripe is connected." },
    };
  });

export const getHqSettings = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireOwner(context.userId, context.bearerToken);
    const sql = await getSql();
    const rows = await sql<{ key: string; value: string }>`select key, value from hq_settings`;
    const value = (key: string) => rows.find((row) => row.key === key)?.value ?? "";
    return {
      announcement: value("announcement"),
      supportPolicy: value("support_policy"),
      announcementPublished: false,
      flags: [
        { name: "Stripe billing", enabled: SUBSCRIPTION_BILLING_LIVE, note: "Off until production Stripe keys and webhooks are tested. This screen cannot turn it on." },
        { name: "Email delivery", enabled: false, note: "Resend is not connected. Support cases are not emailed." },
        { name: "Owner provisioning", enabled: false, note: "No one can grant platform_owner from this dashboard." },
      ],
    };
  });

export const saveHqSettings = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { announcement?: string; supportPolicy?: string }) => {
    const announcement = (data.announcement ?? "").trim();
    const supportPolicy = (data.supportPolicy ?? "").trim();
    if (announcement.length > 280) throw new Error("Announcement must be 280 characters or fewer.");
    if (supportPolicy.length > 1000) throw new Error("Support policy must be 1,000 characters or fewer.");
    return { announcement, supportPolicy };
  })
  .handler(async ({ context, data }) => {
    await requireOwner(context.userId, context.bearerToken);
    const sql = await getSql();
    for (const [key, value] of [["announcement", data.announcement], ["support_policy", data.supportPolicy]] as const) {
      await sql`
        insert into hq_settings (key, value) values (${key}, ${value})
        on conflict (key) do update set value = ${value}, updated_at = now()
      `;
    }
    await audit(context.userId, "hq_settings_saved");
    return { saved: true, publishedToWebsite: false };
  });

export const getHqActivity = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireOwner(context.userId, context.bearerToken);
    const sql = await getSql();
    const rows = await sql<{ id: string; action: string; target: string; created_at: string | Date; email: string }>`
      select a.id, a.action, a.target, a.created_at, u.email
      from hq_audit_log a
      join "user" u on u.id = a.actor_user_id
      order by a.created_at desc
      limit 40
    `;
    return rows.map((row) => ({
      id: row.id,
      action: row.action,
      target: row.target,
      email: row.email,
      createdAt: stamp(row.created_at) ?? "",
    }));
  });
