import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { postLoginPath } from "@/lib/auth/post-login";

/** Where a verified session may go. The client cannot supply a role. */
export const resolveWorkspaceEntry = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { requested?: unknown }) => ({
    requested: typeof data?.requested === "string" ? data.requested : "/app",
  }))
  .handler(async ({ data }) => {
    return {
      path: postLoginPath({
        requested: data.requested,
        role: "business_owner",
        mfaSatisfied: false,
      }),
    };
  });
