import { createServerFn } from "@tanstack/react-start";
import { verifiedBusinessMiddleware as authMiddleware } from "@/server/business-auth";
import { getSql, type Sql } from "@/lib/db";
import { clip, firstName, type DraftFacts } from "@/lib/draft-facts";
import { formatMoney } from "@/lib/money";
import { hasUnexpectedPrice, renderDemoDraft, stripMoney } from "@/lib/messages";
import { calculateQuote, explainQuote } from "@/lib/quotes";
import { buildSample } from "@/lib/sample";
import {
  DEFAULT_EXTRAS,
  DEFAULT_SERVICES,
  type Business,
  type Extra,
  type FollowUp,
  type FrequencyId,
  type Lead,
  type LeadStatus,
  type Quote,
  type QuoteBreakdown,
  type QuoteStatus,
  type ServiceRate,
  type Tone,
  frequencyById,
} from "@/lib/types";
import {
  businessSchema,
  draftSchema,
  followDoneSchema,
  followUpSchema,
  idSchema,
  leadSchema,
  parseInput,
  quoteSchema,
  quoteStatusSchema,
  type BusinessInput,
  type FollowUpInput,
  type LeadInput,
  type QuoteInput,
} from "@/lib/validators";

const DAILY_DRAFT_LIMIT = 40;

type BusinessRow = {
  id: string;
  companyName: string;
  ownerName: string;
  email: string;
  phone: string;
  serviceArea: string;
  hours: string;
  tone: Tone;
  services: unknown;
  extras: unknown;
  sampleLoaded: boolean;
};

type LeadRow = {
  id: string;
  name: string;
  email: string;
  phone: string;
  serviceId: string;
  serviceLabel: string;
  rooms: number | null;
  sqft: number | null;
  frequency: FrequencyId;
  notes: string;
  status: LeadStatus;
  lastContact: string | null;
  isSample: boolean;
  updatedAt: string;
};

type QuoteRow = {
  id: string;
  leadId: string | null;
  leadName: string | null;
  breakdown: unknown;
  totalCents: number;
  explanation: string;
  status: QuoteStatus;
  isSample: boolean;
  updatedAt: string;
};

type FollowRow = {
  id: string;
  leadId: string | null;
  leadName: string | null;
  title: string;
  dueDate: string;
  notes: string;
  done: boolean;
  isSample: boolean;
};

function asObject(value: unknown): unknown {
  if (typeof value === "string") {
    try {
      return JSON.parse(value);
    } catch {
      return null;
    }
  }
  return value;
}

function asServices(value: unknown): ServiceRate[] {
  const parsed = asObject(value);
  if (!Array.isArray(parsed) || parsed.length === 0) return DEFAULT_SERVICES.map((item) => ({ ...item }));
  return parsed as ServiceRate[];
}

function asExtras(value: unknown): Extra[] {
  const parsed = asObject(value);
  if (!Array.isArray(parsed)) return [];
  return parsed as Extra[];
}

function asBreakdown(value: unknown): QuoteBreakdown {
  const parsed = asObject(value);
  return parsed as QuoteBreakdown;
}

function mapBusiness(row: BusinessRow): Business {
  return {
    id: row.id,
    companyName: row.companyName,
    ownerName: row.ownerName,
    email: row.email,
    phone: row.phone,
    serviceArea: row.serviceArea,
    hours: row.hours,
    tone: row.tone,
    services: asServices(row.services),
    extras: asExtras(row.extras),
    sampleLoaded: row.sampleLoaded,
  };
}

function mapLead(row: LeadRow): Lead {
  return { ...row };
}

function mapQuote(row: QuoteRow): Quote {
  return { ...row, breakdown: asBreakdown(row.breakdown) };
}

function mapFollow(row: FollowRow): FollowUp {
  return { ...row };
}

async function ensureBusiness(sql: Sql, userId: string): Promise<Business> {
  const id = crypto.randomUUID();
  await sql`
    insert into businesses (
      id, user_id, company_name, owner_name, email, phone, service_area, hours, tone, services, extras
    ) values (
      ${id},
      ${userId},
      '',
      '',
      '',
      '',
      '',
      'Mon–Fri 8:00–17:00',
      'warm',
      ${JSON.stringify(DEFAULT_SERVICES)}::jsonb,
      ${JSON.stringify(DEFAULT_EXTRAS)}::jsonb
    )
    on conflict (user_id) do nothing
  `;
  const rows = await sql<BusinessRow>`
    select
      id,
      company_name as "companyName",
      owner_name as "ownerName",
      email,
      phone,
      service_area as "serviceArea",
      hours,
      tone,
      services,
      extras,
      sample_loaded as "sampleLoaded"
    from businesses
    where user_id = ${userId}
  `;
  const row = rows[0];
  if (!row) throw new Error("Could not open your workspace.");
  return mapBusiness(row);
}

async function readWorkspace(sql: Sql, userId: string) {
  const business = await ensureBusiness(sql, userId);
  const leads = (
    await sql<LeadRow>`
      select
        id, name, email, phone,
        service_id as "serviceId",
        service_label as "serviceLabel",
        rooms, sqft, frequency, notes, status,
        last_contact as "lastContact",
        is_sample as "isSample",
        updated_at::text as "updatedAt"
      from leads
      where user_id = ${userId}
      order by updated_at desc
      limit 300
    `
  ).map(mapLead);
  const quotes = (
    await sql<QuoteRow>`
      select
        q.id,
        q.lead_id as "leadId",
        l.name as "leadName",
        q.breakdown,
        q.total_cents as "totalCents",
        q.explanation,
        q.status,
        q.is_sample as "isSample",
        q.updated_at::text as "updatedAt"
      from quotes q
      left join leads l on l.id = q.lead_id and l.user_id = ${userId}
      where q.user_id = ${userId}
      order by q.updated_at desc
      limit 300
    `
  ).map(mapQuote);
  const followUps = (
    await sql<FollowRow>`
      select
        f.id,
        f.lead_id as "leadId",
        l.name as "leadName",
        f.title,
        f.due_date as "dueDate",
        f.notes,
        f.done,
        f.is_sample as "isSample"
      from follow_ups f
      left join leads l on l.id = f.lead_id and l.user_id = ${userId}
      where f.user_id = ${userId}
      order by f.done asc, f.due_date asc
      limit 300
    `
  ).map(mapFollow);
  return {
    business,
    leads,
    quotes,
    followUps,
    aiLive: Boolean(process.env.XAI_API_KEY),
  };
}

function uniqueIds(ids: string[], label: string) {
  if (new Set(ids).size !== ids.length) throw new Error(`Each ${label} needs its own id.`);
}

async function ownedLead(sql: Sql, userId: string, leadId: string | null) {
  if (!leadId) return null;
  const rows = await sql<{ id: string }>`
    select id from leads where id = ${leadId} and user_id = ${userId}
  `;
  if (!rows[0]) throw new Error("That lead is not in your workspace.");
  return rows[0].id;
}

export const getWorkspace = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    return readWorkspace(sql, context.userId);
  });

export const saveBusiness = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: BusinessInput) => parseInput(businessSchema, data))
  .handler(async ({ context, data }) => {
    uniqueIds(data.services.map((item) => item.id), "service");
    uniqueIds(data.extras.map((item) => item.id), "extra");
    const sql = await getSql();
    await ensureBusiness(sql, context.userId);
    await sql`
      update businesses set
        company_name = ${data.companyName},
        owner_name = ${data.ownerName},
        email = ${data.email},
        phone = ${data.phone},
        service_area = ${data.serviceArea},
        hours = ${data.hours},
        tone = ${data.tone},
        services = ${JSON.stringify(data.services)}::jsonb,
        extras = ${JSON.stringify(data.extras)}::jsonb,
        updated_at = now()
      where user_id = ${context.userId}
    `;
    return readWorkspace(sql, context.userId);
  });

export const upsertLead = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: LeadInput) => parseInput(leadSchema, data))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const business = await ensureBusiness(sql, context.userId);
    const service = business.services.find((item) => item.id === data.serviceId);
    if (!service) throw new Error("Choose a service from your rate card.");
    const lastContact = data.lastContact ? data.lastContact : null;
    if (data.id) {
      const rows = await sql<{ id: string }>`
        update leads set
          name = ${data.name},
          email = ${data.email},
          phone = ${data.phone},
          service_id = ${service.id},
          service_label = ${service.label},
          rooms = ${data.rooms},
          sqft = ${data.sqft},
          frequency = ${data.frequency},
          notes = ${data.notes},
          status = ${data.status},
          last_contact = ${lastContact},
          updated_at = now()
        where id = ${data.id} and user_id = ${context.userId}
        returning id
      `;
      if (!rows[0]) throw new Error("That lead is not in your workspace.");
    } else {
      await sql`
        insert into leads (
          id, user_id, name, email, phone, service_id, service_label, rooms, sqft,
          frequency, notes, status, last_contact, is_sample
        ) values (
          ${crypto.randomUUID()},
          ${context.userId},
          ${data.name},
          ${data.email},
          ${data.phone},
          ${service.id},
          ${service.label},
          ${data.rooms},
          ${data.sqft},
          ${data.frequency},
          ${data.notes},
          ${data.status},
          ${lastContact},
          false
        )
      `;
    }
    return readWorkspace(sql, context.userId);
  });

export const deleteLead = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { id: string }) => parseInput(idSchema, data))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string }>`
      delete from leads where id = ${data.id} and user_id = ${context.userId} returning id
    `;
    if (!rows[0]) throw new Error("That lead is not in your workspace.");
    return readWorkspace(sql, context.userId);
  });

async function writeQuote(sql: Sql, userId: string, data: QuoteInput) {
  const business = await ensureBusiness(sql, userId);
  const leadId = await ownedLead(sql, userId, data.leadId);
  let breakdown;
  try {
    breakdown = calculateQuote({
      services: business.services,
      extrasCatalog: business.extras,
      serviceId: data.serviceId,
      rooms: data.rooms,
      sqft: data.sqft,
      frequency: data.frequency,
      extraIds: data.extraIds,
      adjustmentCents: data.adjustmentCents,
    });
  } catch (error) {
    throw new Error(error instanceof Error ? error.message : "Could not calculate that estimate.");
  }
  const explanation = data.explanation.trim() || explainQuote(breakdown);
  const payload = JSON.stringify(breakdown);
  if (data.id) {
    const rows = await sql<{ id: string }>`
      update quotes set
        lead_id = ${leadId},
        breakdown = ${payload}::jsonb,
        total_cents = ${breakdown.totalCents},
        explanation = ${explanation},
        status = ${data.status},
        updated_at = now()
      where id = ${data.id} and user_id = ${userId}
      returning id
    `;
    if (!rows[0]) throw new Error("That estimate is not in your workspace.");
    return;
  }
  await sql`
    insert into quotes (
      id, user_id, lead_id, breakdown, total_cents, explanation, status, is_sample
    ) values (
      ${crypto.randomUUID()},
      ${userId},
      ${leadId},
      ${payload}::jsonb,
      ${breakdown.totalCents},
      ${explanation},
      ${data.status},
      false
    )
  `;
}

export const upsertQuote = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: QuoteInput) => parseInput(quoteSchema, data))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await writeQuote(sql, context.userId, data);
    return readWorkspace(sql, context.userId);
  });

export const setQuoteStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { id: string; status: QuoteStatus }) => parseInput(quoteStatusSchema, data))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string }>`
      update quotes set status = ${data.status}, updated_at = now()
      where id = ${data.id} and user_id = ${context.userId}
      returning id
    `;
    if (!rows[0]) throw new Error("That estimate is not in your workspace.");
    return readWorkspace(sql, context.userId);
  });

export const deleteQuote = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { id: string }) => parseInput(idSchema, data))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string }>`
      delete from quotes where id = ${data.id} and user_id = ${context.userId} returning id
    `;
    if (!rows[0]) throw new Error("That estimate is not in your workspace.");
    return readWorkspace(sql, context.userId);
  });

export const upsertFollowUp = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: FollowUpInput) => parseInput(followUpSchema, data))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const leadId = await ownedLead(sql, context.userId, data.leadId);
    if (data.id) {
      const rows = await sql<{ id: string }>`
        update follow_ups set
          lead_id = ${leadId},
          title = ${data.title},
          due_date = ${data.dueDate},
          notes = ${data.notes}
        where id = ${data.id} and user_id = ${context.userId}
        returning id
      `;
      if (!rows[0]) throw new Error("That reminder is not in your workspace.");
    } else {
      await sql`
        insert into follow_ups (id, user_id, lead_id, title, due_date, notes, done, is_sample)
        values (
          ${crypto.randomUUID()}, ${context.userId}, ${leadId}, ${data.title},
          ${data.dueDate}, ${data.notes}, false, false
        )
      `;
    }
    return readWorkspace(sql, context.userId);
  });

export const setFollowUpDone = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { id: string; done: boolean }) => parseInput(followDoneSchema, data))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string }>`
      update follow_ups set done = ${data.done}
      where id = ${data.id} and user_id = ${context.userId}
      returning id
    `;
    if (!rows[0]) throw new Error("That reminder is not in your workspace.");
    return readWorkspace(sql, context.userId);
  });

export const deleteFollowUp = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { id: string }) => parseInput(idSchema, data))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string }>`
      delete from follow_ups where id = ${data.id} and user_id = ${context.userId} returning id
    `;
    if (!rows[0]) throw new Error("That reminder is not in your workspace.");
    return readWorkspace(sql, context.userId);
  });

export const loadSample = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const business = await ensureBusiness(sql, context.userId);
    await sql`delete from follow_ups where user_id = ${context.userId} and is_sample = true`;
    await sql`delete from quotes where user_id = ${context.userId} and is_sample = true`;
    await sql`delete from leads where user_id = ${context.userId} and is_sample = true`;
    const profile = business.companyName.trim()
      ? business
      : {
          ...business,
          companyName: "Harbor & Pine Cleaning",
          ownerName: business.ownerName || "A. Parker",
          email: business.email || "hello@harborpine.example",
          phone: business.phone || "(404) 555-0148",
          serviceArea: business.serviceArea || "Decatur and East Atlanta",
          hours: business.hours || "Mon–Fri 8:00–17:00, Sat 9:00–13:00",
        };
    if (!business.companyName.trim()) {
      await sql`
        update businesses set
          company_name = ${profile.companyName},
          owner_name = ${profile.ownerName},
          email = ${profile.email},
          phone = ${profile.phone},
          service_area = ${profile.serviceArea},
          hours = ${profile.hours},
          sample_loaded = true,
          updated_at = now()
        where user_id = ${context.userId}
      `;
    } else {
      await sql`
        update businesses set sample_loaded = true, updated_at = now()
        where user_id = ${context.userId}
      `;
    }
    const sample = buildSample(profile, context.userId);
    for (const lead of sample.leads) {
      await sql`
        insert into leads (
          id, user_id, name, email, phone, service_id, service_label, rooms, sqft,
          frequency, notes, status, last_contact, is_sample
        ) values (
          ${lead.id}, ${context.userId}, ${lead.name}, ${lead.email}, ${lead.phone},
          ${lead.serviceId}, ${lead.serviceLabel}, ${lead.rooms}, ${lead.sqft},
          ${lead.frequency}, ${lead.notes}, ${lead.status}, ${lead.lastContact}, true
        )
      `;
    }
    for (const quote of sample.quotes) {
      await sql`
        insert into quotes (
          id, user_id, lead_id, breakdown, total_cents, explanation, status, is_sample
        ) values (
          ${quote.id}, ${context.userId}, ${quote.leadId}, ${JSON.stringify(quote.breakdown)}::jsonb,
          ${quote.totalCents}, ${quote.explanation}, ${quote.status}, true
        )
      `;
    }
    for (const item of sample.followUps) {
      await sql`
        insert into follow_ups (id, user_id, lead_id, title, due_date, notes, done, is_sample)
        values (
          ${item.id}, ${context.userId}, ${item.leadId}, ${item.title}, ${item.dueDate},
          ${item.notes}, ${item.done}, true
        )
      `;
    }
    return readWorkspace(sql, context.userId);
  });

export const clearSample = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await sql`delete from follow_ups where user_id = ${context.userId} and is_sample = true`;
    await sql`delete from quotes where user_id = ${context.userId} and is_sample = true`;
    await sql`delete from leads where user_id = ${context.userId} and is_sample = true`;
    await sql`
      update businesses set sample_loaded = false, updated_at = now()
      where user_id = ${context.userId}
    `;
    return readWorkspace(sql, context.userId);
  });

async function draftFromFacts(facts: DraftFacts): Promise<{ mode: "demo" | "grok"; text: string; notice: string }> {
  const demo = renderDemoDraft(facts);
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) {
    return {
      mode: "demo",
      text: demo,
      notice: "Demo draft — a live model is not connected. This text is a template filled with your saved business details. It was not written by an AI model.",
    };
  }
  const allowed = facts.quoteTotalLabel ? [facts.quoteTotalLabel] : [];
  try {
    const response = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${apiKey}`,
      },
      signal: AbortSignal.timeout(20000),
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0.3,
        max_tokens: 400,
        messages: [
          {
            role: "system",
            content:
              "You draft a short customer message for a residential cleaning business. Use only the JSON facts. Do not invent prices, discounts, dates, addresses, phone numbers, or policies. If quoteTotalLabel is present you may mention that exact string and no other amount of money. If it is null, do not mention any dollar amount or number that could be read as a price. Plain text only, under 140 words. Do not claim the message was sent.",
          },
          { role: "user", content: JSON.stringify(facts) },
        ],
      }),
    });
    if (!response.ok) {
      return {
        mode: "demo",
        text: demo,
        notice: "Live draft was unavailable, so this is the demo template instead. Nothing was sent.",
      };
    }
    const body = (await response.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const text = (body.choices?.[0]?.message?.content ?? "").trim().slice(0, 1500);
    if (!text || hasUnexpectedPrice(text, allowed)) {
      return {
        mode: "demo",
        text: demo,
        notice: "The live draft mentioned a price that is not on the saved estimate, so BookBloom kept the demo template. Nothing was sent.",
      };
    }
    return {
      mode: "grok",
      text,
      notice: "Drafted with Grok from your saved business details. Any price matches the estimate on file. Review it, then copy. BookBloom does not send it.",
    };
  } catch {
    return {
      mode: "demo",
      text: demo,
      notice: "Live draft was unavailable, so this is the demo template instead. Nothing was sent.",
    };
  }
}

export const draftMessage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { leadId: string; messageType: DraftFacts["messageType"] }) => parseInput(draftSchema, data))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const business = await ensureBusiness(sql, context.userId);
    const leads = await sql<LeadRow>`
      select
        id, name, email, phone,
        service_id as "serviceId",
        service_label as "serviceLabel",
        rooms, sqft, frequency, notes, status,
        last_contact as "lastContact",
        is_sample as "isSample",
        updated_at::text as "updatedAt"
      from leads
      where id = ${data.leadId} and user_id = ${context.userId}
    `;
    const lead = leads[0];
    if (!lead) throw new Error("Choose a lead from your workspace.");
    const usage = await sql<{ n: number }>`
      select count(*)::int as n from ai_usage
      where user_id = ${context.userId} and created_at > now() - interval '1 day'
    `;
    if ((usage[0]?.n ?? 0) >= DAILY_DRAFT_LIMIT) {
      throw new Error("Daily draft limit reached (40). Try again tomorrow.");
    }
    const quotes = await sql<{ totalCents: number; status: QuoteStatus }>`
      select total_cents as "totalCents", status
      from quotes
      where user_id = ${context.userId} and lead_id = ${lead.id}
      order by updated_at desc
      limit 1
    `;
    const quote = quotes[0];
    const facts: DraftFacts = {
      messageType: data.messageType,
      tone: business.tone,
      companyName: clip(stripMoney(business.companyName), 80),
      serviceArea: clip(stripMoney(business.serviceArea), 120),
      hours: clip(stripMoney(business.hours), 160),
      customerFirstName: firstName(lead.name),
      serviceLabel: clip(stripMoney(lead.serviceLabel), 60),
      frequencyLabel: frequencyById(lead.frequency)?.label ?? "One-time",
      notes: clip(stripMoney(lead.notes), 400),
      quoteTotalLabel: quote ? formatMoney(quote.totalCents) : null,
      quoteStatus: quote?.status ?? null,
    };
    const inputChars = JSON.stringify(facts).length;
    const result = await draftFromFacts(facts);
    await sql`
      insert into ai_usage (id, user_id, feature, mode, input_chars, output_chars)
      values (
        ${crypto.randomUUID()}, ${context.userId}, 'message_draft', ${result.mode},
        ${inputChars}, ${result.text.length}
      )
    `;
    return {
      mode: result.mode,
      text: result.text,
      label: result.mode === "grok" ? "Drafted with Grok" : "Demo draft — not a live model",
      notice: result.notice,
    };
  });
