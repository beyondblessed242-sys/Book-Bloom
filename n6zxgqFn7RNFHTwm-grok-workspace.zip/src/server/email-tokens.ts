import { createHash, randomBytes } from "node:crypto";
import { getSql } from "@/lib/db";

function tokenKey(token: string): string {
  return `email-verify:${createHash("sha256").update(token).digest("hex")}`;
}

export async function rememberEmailVerificationToken(token: string, ttlSeconds: number): Promise<void> {
  const sql = await getSql();
  const expires = new Date(Date.now() + ttlSeconds * 1000).toISOString();
  await sql`
    insert into verification (id, identifier, value, "expiresAt", "createdAt", "updatedAt")
    values (${randomBytes(16).toString("hex")}, ${tokenKey(token)}, ${"pending"}, ${expires}, now(), now())
  `;
}

export async function forgetEmailVerificationToken(token: string): Promise<void> {
  const sql = await getSql();
  await sql`delete from verification where identifier = ${tokenKey(token)}`;
}

/** Deletes the stored token. A second use finds nothing and must not verify the account. */
export async function consumeEmailVerificationToken(token: string): Promise<boolean> {
  const sql = await getSql();
  const rows = await sql<{ identifier: string }>`
    delete from verification
    where identifier = ${tokenKey(token)} and "expiresAt" > now()
    returning identifier
  `;
  return rows.length > 0;
}
