import { randomUUID } from "node:crypto";
import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { authMiddleware } from "@/lib/auth/middleware";
import { auth as betterAuth } from "@/lib/auth/server";
import { decodeProfilePhoto, notificationSchema, profileSchema, rejectRoleField, type NotificationInput, type ProfileInput } from "@/lib/account";
import { getSql } from "@/lib/db";
import { FOUNDERS_MONTHLY_CENTS, SUBSCRIPTION_BILLING_LIVE } from "@/lib/pricing";

const DRAFT_LIMIT = 40;

function headersFor(bearerToken?: string): Headers {
  const headers = new Headers(getRequest()?.headers);
  if (bearerToken) headers.set("Authorization", `Bearer ${bearerToken}`);
  return headers;
}

function photoUrl(mime: string | null, raw: unknown): string | null {
  if (!mime || raw == null) return null;
  const bytes = Buffer.isBuffer(raw) ? raw : Buffer.from(raw as Uint8Array);
  if (bytes.byteLength === 0) return null;
  return `data:${mime};base64,${bytes.toString("base64")}`;
}

async function assertPassword(userId: string, password: string) {
  const sql = await getSql();
  const rows = await sql<{ password: string }>`
    select password from account
    where "userId" = ${userId} and "providerId" = 'credential' and password is not null
  `;
  const hash = rows[0]?.password;
  if (!hash) throw new Error("This account has no password. Nothing was changed.");
  const context = await betterAuth.$context;
  const matches = await context.password.verify({ hash, password });
  if (!matches) throw new Error("Current password is incorrect. Nothing was changed.");
}

export const getAccountSummary = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<{
      email: string;
      emailVerified: boolean;
      createdAt: string;
      name: string;
      first_name: string | null;
      last_name: string | null;
      display_name: string | null;
      phone: string | null;
      timezone: string | null;
      language: string | null;
      photo_mime: string | null;
      photo_bytes: unknown;
    }>`
      select u.email, u."emailVerified", u."createdAt", u.name,
        p.first_name, p.last_name, p.display_name, p.phone, p.timezone, p.language, p.photo_mime, p.photo_bytes
      from "user" u
      left join account_profiles p on p.user_id = u.id
      where u.id = ${context.userId}
    `;
    const row = rows[0];
    if (!row) throw new Error("Account not found.");
    const password = await sql<{ ok: number }>`
      select 1 as ok from account
      where "userId" = ${context.userId} and "providerId" = 'credential' and password is not null
    `;
    const prefs = await sql<{
      follow_up_reminders: boolean;
      product_updates: boolean;
      subscription_notices: boolean;
      marketing: boolean;
    }>`
      select follow_up_reminders, product_updates, subscription_notices, marketing
      from notification_preferences where user_id = ${context.userId}
    `;
    const drafts = await sql<{ count: number }>`
      select count(*) as count from ai_usage
      where user_id = ${context.userId} and created_at > now() - interval '1 day'
    `;
    const deletion = await sql<{ requested_at: string }>`
      select requested_at from account_deletion_requests
      where user_id = ${context.userId} and status = 'requested'
      order by requested_at desc limit 1
    `;
    const owner = await sql<{ role: string }>`
      select role from admin_role_assignments where user_id = ${context.userId} and role = 'platform_owner'
    `;
    return {
      email: row.email,
      emailVerified: row.emailVerified,
      createdAt: row.createdAt,
      firstName: row.first_name ?? "",
      lastName: row.last_name ?? "",
      displayName: row.display_name || row.name,
      phone: row.phone ?? "",
      timezone: row.timezone || "America/New_York",
      language: "en" as const,
      photoUrl: photoUrl(row.photo_mime, row.photo_bytes),
      hasPassword: Boolean(password[0]),
      notifications: {
        followUpReminders: prefs[0]?.follow_up_reminders ?? true,
        productUpdates: prefs[0]?.product_updates ?? false,
        subscriptionNotices: prefs[0]?.subscription_notices ?? true,
        marketing: prefs[0]?.marketing ?? false,
      },
      subscription: {
        plan: "Founder's Plan",
        priceCents: FOUNDERS_MONTHLY_CENTS,
        status: SUBSCRIPTION_BILLING_LIVE ? "active" : "not_subscribed",
        billingLive: SUBSCRIPTION_BILLING_LIVE,
        nextBillingDate: null as string | null,
        draftLimit: DRAFT_LIMIT,
        draftsToday: Number(drafts[0]?.count ?? 0),
      },
      deletionRequestedAt: deletion[0]?.requested_at ?? null,
      canOpenHq: Boolean(owner[0]),
    };
  });

export const saveAccountProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: ProfileInput) => {
    rejectRoleField(data);
    return profileSchema.parse(data);
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      insert into account_profiles (user_id, first_name, last_name, display_name, phone, timezone, language)
      values (${context.userId}, ${data.firstName}, ${data.lastName}, ${data.displayName}, ${data.phone}, ${data.timezone}, 'en')
      on conflict (user_id) do update set
        first_name = excluded.first_name,
        last_name = excluded.last_name,
        display_name = excluded.display_name,
        phone = excluded.phone,
        timezone = excluded.timezone,
        language = 'en',
        updated_at = now()
    `;
    await sql`update "user" set name = ${data.displayName}, "updatedAt" = now() where id = ${context.userId}`;
    return { ok: true as const };
  });

export const saveAccountPhoto = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { dataUrl?: string; remove?: boolean }) => data)
  .handler(async ({ context, data }) => {
    rejectRoleField(data);
    const sql = await getSql();
    await sql`
      insert into account_profiles (user_id) values (${context.userId})
      on conflict (user_id) do nothing
    `;
    if (data.remove) {
      await sql`update account_profiles set photo_mime = null, photo_bytes = null, updated_at = now() where user_id = ${context.userId}`;
      return { ok: true as const };
    }
    if (!data.dataUrl) throw new Error("Choose a photo or remove the current one.");
    const photo = decodeProfilePhoto(data.dataUrl);
    await sql`
      update account_profiles
      set photo_mime = ${photo.mime}, photo_bytes = ${Buffer.from(photo.bytes)}, updated_at = now()
      where user_id = ${context.userId}
    `;
    return { ok: true as const };
  });

export const saveNotificationPreferences = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: NotificationInput) => {
    rejectRoleField(data);
    return notificationSchema.parse(data);
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      insert into notification_preferences (user_id, follow_up_reminders, product_updates, subscription_notices, marketing)
      values (${context.userId}, ${data.followUpReminders}, ${data.productUpdates}, ${data.subscriptionNotices}, ${data.marketing})
      on conflict (user_id) do update set
        follow_up_reminders = excluded.follow_up_reminders,
        product_updates = excluded.product_updates,
        subscription_notices = excluded.subscription_notices,
        marketing = excluded.marketing,
        updated_at = now()
    `;
    return { ok: true as const };
  });

export const listAccountSessions = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    try {
      const headers = headersFor(context.bearerToken);
      const current = await betterAuth.api.getSession({ headers });
      const sessions = await betterAuth.api.listSessions({ headers });
      return {
        error: null as string | null,
        sessions: (Array.isArray(sessions) ? sessions : []).map((session) => ({
          id: session.id,
          createdAt: session.createdAt,
          expiresAt: session.expiresAt,
          ipAddress: session.ipAddress ?? null,
          userAgent: session.userAgent ?? null,
          current: session.token === current?.session.token,
        })),
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Sessions could not be listed.";
      return { error: message, sessions: [] };
    }
  });

export const revokeOtherAccountSessions = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const headers = headersFor(context.bearerToken);
    await betterAuth.api.revokeOtherSessions({ headers });
    return { ok: true as const };
  });

export const exportAccountData = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const userId = context.userId;
    const [profile, business, leads, quotes, followUps, notifications] = await Promise.all([
      sql`select first_name, last_name, display_name, phone, timezone, language, photo_mime is not null as has_photo from account_profiles where user_id = ${userId}`,
      sql`select company_name, owner_name, email, phone, service_area, hours, tone, services, extras from businesses where user_id = ${userId}`,
      sql`select id, name, email, phone, service_label, rooms, sqft, frequency, notes, status, last_contact, is_sample from leads where user_id = ${userId}`,
      sql`select id, lead_id, total_cents, explanation, status, is_sample from quotes where user_id = ${userId}`,
      sql`select id, lead_id, title, due_date, notes, done, is_sample from follow_ups where user_id = ${userId}`,
      sql`select follow_up_reminders, product_updates, subscription_notices, marketing from notification_preferences where user_id = ${userId}`,
    ]);
    const payload = {
      exportedAt: new Date().toISOString(),
      profile: profile.map(plainRow),
      business: business.map(plainRow),
      leads: leads.map(plainRow),
      quotes: quotes.map(plainRow),
      followUps: followUps.map(plainRow),
      notifications: notifications.map(plainRow),
    };
    return payload;
  });

function plainRow(row: Record<string, unknown>): Record<string, string | number | boolean | null> {
  const out: Record<string, string | number | boolean | null> = {};
  for (const [key, value] of Object.entries(row)) {
    if (value == null) out[key] = null;
    else if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") out[key] = value;
    else if (value instanceof Date) out[key] = value.toISOString();
    else out[key] = JSON.stringify(value);
  }
  return out;
}

export const requestAccountDeletion = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { currentPassword?: string }) => {
    rejectRoleField(data);
    return { currentPassword: typeof data.currentPassword === "string" ? data.currentPassword : "" };
  })
  .handler(async ({ context, data }) => {
    if (!data.currentPassword) throw new Error("Enter your current password. Nothing was deleted.");
    await assertPassword(context.userId, data.currentPassword);
    const sql = await getSql();
    await sql`
      insert into account_deletion_requests (id, user_id) values (${randomUUID()}, ${context.userId})
    `;
    return { ok: true as const };
  });

export const correctUnverifiedEmail = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { newEmail?: string; currentPassword?: string }) => {
    rejectRoleField(data);
    return {
      newEmail: typeof data.newEmail === "string" ? data.newEmail.trim().toLowerCase() : "",
      currentPassword: typeof data.currentPassword === "string" ? data.currentPassword : "",
    };
  })
  .handler(async ({ context, data }) => {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.newEmail)) {
      throw new Error("Enter a valid email address. The address was not changed.");
    }
    if (!data.currentPassword) throw new Error("Enter your current password. The address was not changed.");
    await assertPassword(context.userId, data.currentPassword);
    const sql = await getSql();
    const current = await sql<{ email: string; emailVerified: boolean }>`
      select email, "emailVerified" from "user" where id = ${context.userId}
    `;
    const row = current[0];
    if (!row) throw new Error("Account not found. The address was not changed.");
    if (row.emailVerified === true) {
      throw new Error("This address is already verified. Use Password & Security to change it. Nothing was changed.");
    }
    if (row.email.toLowerCase() === data.newEmail) {
      throw new Error("That is already the address on this account. Nothing was changed.");
    }
    const taken = await sql<{ id: string }>`
      select id from "user" where lower(email) = ${data.newEmail} and id <> ${context.userId}
    `;
    if (taken[0]) throw new Error("That email is already registered. No second account was created.");
    await sql`
      update "user"
      set email = ${data.newEmail}, "emailVerified" = false, "updatedAt" = now()
      where id = ${context.userId} and "emailVerified" = false
    `;
    return { email: data.newEmail };
  });
