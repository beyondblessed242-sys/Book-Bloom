import { Link } from "@tanstack/react-router";
import { Logo } from "@/components/logo";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export function SiteHeader() {
  const { user, isPending } = useCurrentUserState();
  return (
    <header className="sticky top-0 z-30 border-b border-line bg-bg/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
        <Logo />
        <nav className="hidden items-center gap-5 text-sm text-muted md:flex" aria-label="Page">
          <a href="/#product">Product</a>
          <a href="/#how">How it works</a>
          <a href="/#pricing">Pricing</a>
          <a href="/#faq">FAQ</a>
        </nav>
        <div className="flex items-center gap-2">
          {isPending ? (
            <span className="h-11 w-28 animate-pulse rounded-full bg-accent-soft" aria-hidden="true" />
          ) : user ? (
            <Link to="/app" className="btn btn-primary">
              Open workspace
            </Link>
          ) : (
            <>
              <Link to="/demo" className="btn btn-ghost">
                Try Free Demo
              </Link>
              <Link to="/login" search={{ next: "/app", mode: "sign-in" }} className="btn btn-secondary desktop-only">
                Sign in
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
