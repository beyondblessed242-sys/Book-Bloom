import type { ReactNode } from "react";

export function Field({
  label,
  hint,
  error,
  children,
  action,
}: {
  label: string;
  hint?: string;
  error?: string;
  children: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="grid gap-1.5 text-sm">
      <div className="flex items-center justify-between gap-3">
        <span className="font-medium text-ink">{label}</span>
        {action}
      </div>
      <label className="grid">
        <span className="sr-only">{label}</span>
        {children}
      </label>
      {hint ? <span className="text-xs text-muted">{hint}</span> : null}
      {error ? <span className="text-xs text-warn">{error}</span> : null}
    </div>
  );
}

export function Notice({ tone = "info", children }: { tone?: "info" | "warn"; children: ReactNode }) {
  return (
    <p
      role="status"
      className={
        tone === "warn"
          ? "rounded-2xl border border-warn/30 bg-warn-soft px-4 py-3 text-sm text-warn"
          : "rounded-2xl border border-line bg-accent-soft px-4 py-3 text-sm text-accent"
      }
    >
      {children}
    </p>
  );
}
