import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { AccountMenu } from "@/components/account/account-menu";
import { Logo } from "@/components/logo";
import { Notice } from "@/components/field";
import { useWorkspace } from "./workspace";

export const SECTIONS = [
  { id: "overview", label: "Overview", href: "/app" },
  { id: "leads", label: "Leads", href: "/app/leads" },
  { id: "quotes", label: "Quotes", href: "/app/quotes" },
  { id: "messages", label: "Messages", href: "/app/messages" },
  { id: "follow-ups", label: "Follow-ups", href: "/app/follow-ups" },
  { id: "settings", label: "Settings", href: "/app/settings" },
  { id: "billing", label: "Billing", href: "/app/billing" },
] as const;

export type SectionId = (typeof SECTIONS)[number]["id"];

export function sectionFromPath(pathname: string): SectionId {
  const match = SECTIONS.find((item) => item.href !== "/app" && pathname.startsWith(item.href));
  return match?.id ?? "overview";
}

export function Shell({
  current,
  onNavigate,
  children,
}: {
  current: SectionId;
  onNavigate?: (id: SectionId) => void;
  children: ReactNode;
}) {
  const workspace = useWorkspace();
  const company = workspace.business.companyName || "Your cleaning business";
  const hasSample = workspace.mode === "demo" || workspace.leads.some((lead) => lead.isSample) || workspace.business.sampleLoaded;

  return (
    <div className="min-h-screen">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <div className="flex min-w-0 items-center gap-2 sm:gap-3">
            {workspace.mode === "demo" ? (
              <Link to="/" className="btn btn-ghost shrink-0 px-2.5 sm:px-3">
                <svg viewBox="0 0 20 20" className="size-4" aria-hidden="true">
                  <path d="M12.5 4.5 7 10l5.5 5.5" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Back to Home
              </Link>
            ) : null}
            <Logo to={workspace.mode === "demo" ? "/" : "/app"} />
            <span className="hidden text-sm text-muted sm:inline">{company}</span>
          </div>
          {workspace.mode === "live" ? (
            <AccountMenu />
          ) : (
            <Link to="/login" search={{ next: "/app", mode: "create" }} className="btn btn-secondary">
              Create account
            </Link>
          )}
        </div>
        <nav aria-label="Workspace" className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-3 pb-3">
          {SECTIONS.map((item) => {
            const active = item.id === current;
            const className = active ? "btn btn-primary" : "btn btn-ghost";
            if (onNavigate) {
              return (
                <button key={item.id} type="button" className={className} onClick={() => onNavigate(item.id)} aria-current={active ? "page" : undefined}>
                  {item.label}
                </button>
              );
            }
            return (
              <Link key={item.id} to={item.href} className={className} aria-current={active ? "page" : undefined}>
                {item.label}
              </Link>
            );
          })}
        </nav>
      </header>
      <main className="mx-auto grid max-w-6xl gap-4 px-4 py-6">
        {workspace.mode === "demo" ? (
          <Notice>Sample workspace. These people are fictional. Nothing is saved, and nothing is emailed or texted.</Notice>
        ) : hasSample ? (
          <Notice>Sample records are marked. They are fictional and stay inside your account until you remove them.</Notice>
        ) : null}
        {workspace.error ? (
          <Notice tone="warn">
            {workspace.error}{" "}
            <button type="button" className="underline" onClick={() => void workspace.reload()}>
              Retry
            </button>
          </Notice>
        ) : null}
        {workspace.loading ? <p className="text-muted">Loading your workspace…</p> : children}
      </main>
    </div>
  );
}
