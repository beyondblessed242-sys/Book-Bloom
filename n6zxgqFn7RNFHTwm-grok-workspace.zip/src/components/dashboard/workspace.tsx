import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import {
  clearSample,
  deleteFollowUp,
  deleteLead,
  deleteQuote,
  draftMessage,
  getWorkspace,
  loadSample,
  saveBusiness,
  setFollowUpDone,
  setQuoteStatus,
  upsertFollowUp,
  upsertLead,
  upsertQuote,
} from "@/server/bookbloom";
import { clip, firstName } from "@/lib/draft-facts";
import { formatMoney } from "@/lib/money";
import { renderDemoDraft, stripMoney } from "@/lib/messages";
import { calculateQuote, explainQuote } from "@/lib/quotes";
import { buildSample, sampleBusiness } from "@/lib/sample";
import { EMPTY_BUSINESS, type Business } from "@/lib/types";
import {
  parseInput,
  businessSchema,
  followUpSchema,
  leadSchema,
  quoteSchema,
  type BusinessInput,
  type FollowUpInput,
  type LeadInput,
  type QuoteInput,
} from "@/lib/validators";
import {
  type DraftResult,
  type FollowUp,
  type Lead,
  type MessageType,
  type Quote,
  type QuoteStatus,
  frequencyById,
} from "@/lib/types";

export type WorkspaceSnapshot = {
  business: Business;
  leads: Lead[];
  quotes: Quote[];
  followUps: FollowUp[];
  aiLive: boolean;
};

type WorkspaceApi = WorkspaceSnapshot & {
  mode: "demo" | "live";
  loading: boolean;
  saving: boolean;
  error: string | null;
  clearError: () => void;
  reload: () => Promise<void>;
  saveBusiness: (input: BusinessInput) => Promise<void>;
  upsertLead: (input: LeadInput) => Promise<void>;
  deleteLead: (id: string) => Promise<void>;
  upsertQuote: (input: QuoteInput) => Promise<void>;
  setQuoteStatus: (id: string, status: QuoteStatus) => Promise<void>;
  deleteQuote: (id: string) => Promise<void>;
  upsertFollowUp: (input: FollowUpInput) => Promise<void>;
  setFollowUpDone: (id: string, done: boolean) => Promise<void>;
  deleteFollowUp: (id: string) => Promise<void>;
  draftMessage: (leadId: string, messageType: MessageType) => Promise<DraftResult>;
  loadSample: () => Promise<void>;
  clearSample: () => Promise<void>;
};

const WorkspaceContext = createContext<WorkspaceApi | null>(null);

export function useWorkspace() {
  const value = useContext(WorkspaceContext);
  if (!value) throw new Error("Open a workspace before using this screen.");
  return value;
}

function errorText(error: unknown): string {
  if (error instanceof Error && error.message) return error.message;
  return "Something went wrong. Please try again.";
}

export function LiveWorkspace({ children }: { children: ReactNode }) {
  const [data, setData] = useState<WorkspaceSnapshot | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setError(null);
    const next = await getWorkspace();
    setData(next);
  }

  useEffect(() => {
    let cancelled = false;
    getWorkspace()
      .then((next) => {
        if (!cancelled) setData(next);
      })
      .catch((err: unknown) => {
        if (!cancelled) setError(errorText(err));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  async function commit(work: () => Promise<WorkspaceSnapshot>) {
    setSaving(true);
    setError(null);
    try {
      const next = await work();
      setData(next);
    } catch (err) {
      const message = errorText(err);
      setError(message);
      if (message === "Unauthorized" && typeof window !== "undefined") {
        window.location.href = "/login";
      }
      throw err;
    } finally {
      setSaving(false);
    }
  }

  const api: WorkspaceApi = {
    business: data?.business ?? emptyFallback(),
    leads: data?.leads ?? [],
    quotes: data?.quotes ?? [],
    followUps: data?.followUps ?? [],
    aiLive: data?.aiLive ?? false,
    mode: "live",
    loading,
    saving,
    error,
    clearError: () => setError(null),
    reload: () => load(),
    saveBusiness: (input) => commit(() => saveBusiness({ data: input })),
    upsertLead: (input) => commit(() => upsertLead({ data: input })),
    deleteLead: (id) => commit(() => deleteLead({ data: { id } })),
    upsertQuote: (input) => commit(() => upsertQuote({ data: input })),
    setQuoteStatus: (id, status) => commit(() => setQuoteStatus({ data: { id, status } })),
    deleteQuote: (id) => commit(() => deleteQuote({ data: { id } })),
    upsertFollowUp: (input) => commit(() => upsertFollowUp({ data: input })),
    setFollowUpDone: (id, done) => commit(() => setFollowUpDone({ data: { id, done } })),
    deleteFollowUp: (id) => commit(() => deleteFollowUp({ data: { id } })),
    draftMessage: (leadId, messageType) => draftMessage({ data: { leadId, messageType } }),
    loadSample: () => commit(() => loadSample()),
    clearSample: () => commit(() => clearSample()),
  };

  return <WorkspaceContext.Provider value={api}>{children}</WorkspaceContext.Provider>;
}

function emptyFallback(): Business {
  return EMPTY_BUSINESS;
}

export function DemoWorkspace({ children }: { children: ReactNode }) {
  const seeded = sampleBusiness();
  const starter = buildSample(seeded, "demo");
  const [business, setBusiness] = useState<Business>(seeded);
  const [leads, setLeads] = useState<Lead[]>(starter.leads);
  const [quotes, setQuotes] = useState<Quote[]>(starter.quotes);
  const [followUps, setFollowUps] = useState<FollowUp[]>(starter.followUps);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function run<T>(work: () => T): Promise<T> {
    setSaving(true);
    setError(null);
    try {
      return work();
    } catch (err) {
      setError(errorText(err));
      throw err;
    } finally {
      setSaving(false);
    }
  }

  const api: WorkspaceApi = {
    business,
    leads,
    quotes,
    followUps,
    aiLive: false,
    mode: "demo",
    loading: false,
    saving,
    error,
    clearError: () => setError(null),
    reload: async () => undefined,
    saveBusiness: (input) =>
      run(() => {
        const data = parseInput(businessSchema, input);
        setBusiness((current) => ({ ...current, ...data, sampleLoaded: current.sampleLoaded }));
      }),
    upsertLead: (input) =>
      run(() => {
        const data = parseInput(leadSchema, input);
        const service = business.services.find((item) => item.id === data.serviceId);
        if (!service) throw new Error("Choose a service from your rate card.");
        const next: Lead = {
          id: data.id ?? crypto.randomUUID(),
          name: data.name,
          email: data.email,
          phone: data.phone,
          serviceId: service.id,
          serviceLabel: service.label,
          rooms: data.rooms,
          sqft: data.sqft,
          frequency: data.frequency,
          notes: data.notes,
          status: data.status,
          lastContact: data.lastContact || null,
          isSample: data.id ? (leads.find((item) => item.id === data.id)?.isSample ?? false) : false,
          updatedAt: new Date().toISOString(),
        };
        setLeads((current) => {
          const exists = current.some((item) => item.id === next.id);
          return exists ? current.map((item) => (item.id === next.id ? next : item)) : [next, ...current];
        });
      }),
    deleteLead: (id) =>
      run(() => {
        setLeads((current) => current.filter((item) => item.id !== id));
        setQuotes((current) => current.map((item) => (item.leadId === id ? { ...item, leadId: null, leadName: null } : item)));
        setFollowUps((current) => current.filter((item) => item.leadId !== id));
      }),
    upsertQuote: (input) =>
      run(() => {
        const data = parseInput(quoteSchema, input);
        const breakdown = calculateQuote({
          services: business.services,
          extrasCatalog: business.extras,
          serviceId: data.serviceId,
          rooms: data.rooms,
          sqft: data.sqft,
          frequency: data.frequency,
          extraIds: data.extraIds,
          adjustmentCents: data.adjustmentCents,
        });
        const lead = data.leadId ? leads.find((item) => item.id === data.leadId) : undefined;
        if (data.leadId && !lead) throw new Error("That lead is not in this sample workspace.");
        const next: Quote = {
          id: data.id ?? crypto.randomUUID(),
          leadId: lead?.id ?? null,
          leadName: lead?.name ?? null,
          breakdown,
          totalCents: breakdown.totalCents,
          explanation: data.explanation.trim() || explainQuote(breakdown),
          status: data.status,
          isSample: data.id ? (quotes.find((item) => item.id === data.id)?.isSample ?? true) : false,
          updatedAt: new Date().toISOString(),
        };
        setQuotes((current) => {
          const exists = current.some((item) => item.id === next.id);
          return exists ? current.map((item) => (item.id === next.id ? next : item)) : [next, ...current];
        });
      }),
    setQuoteStatus: (id, status) =>
      run(() => {
        setQuotes((current) => current.map((item) => (item.id === id ? { ...item, status } : item)));
      }),
    deleteQuote: (id) => run(() => setQuotes((current) => current.filter((item) => item.id !== id))),
    upsertFollowUp: (input) =>
      run(() => {
        const data = parseInput(followUpSchema, input);
        const lead = data.leadId ? leads.find((item) => item.id === data.leadId) : undefined;
        if (data.leadId && !lead) throw new Error("That lead is not in this sample workspace.");
        const next: FollowUp = {
          id: data.id ?? crypto.randomUUID(),
          leadId: lead?.id ?? null,
          leadName: lead?.name ?? null,
          title: data.title,
          dueDate: data.dueDate,
          notes: data.notes,
          done: data.id ? (followUps.find((item) => item.id === data.id)?.done ?? false) : false,
          isSample: data.id ? (followUps.find((item) => item.id === data.id)?.isSample ?? true) : false,
        };
        setFollowUps((current) => {
          const exists = current.some((item) => item.id === next.id);
          return exists ? current.map((item) => (item.id === next.id ? next : item)) : [next, ...current];
        });
      }),
    setFollowUpDone: (id, done) =>
      run(() => setFollowUps((current) => current.map((item) => (item.id === id ? { ...item, done } : item)))),
    deleteFollowUp: (id) => run(() => setFollowUps((current) => current.filter((item) => item.id !== id))),
    draftMessage: (leadId, messageType) =>
      run(() => {
        const lead = leads.find((item) => item.id === leadId);
        if (!lead) throw new Error("Choose a lead from this sample workspace.");
        const quote = quotes.find((item) => item.leadId === lead.id);
        const text = renderDemoDraft({
          messageType,
          tone: business.tone,
          companyName: clip(stripMoney(business.companyName), 80),
          serviceArea: clip(stripMoney(business.serviceArea), 120),
          hours: clip(stripMoney(business.hours), 160),
          customerFirstName: firstName(lead.name),
          serviceLabel: clip(stripMoney(lead.serviceLabel), 60),
          frequencyLabel: frequencyById(lead.frequency)?.label ?? "One-time",
          notes: clip(stripMoney(lead.notes), 400),
          quoteTotalLabel: quote ? formatMoney(quote.totalCents) : null,
          quoteStatus: quote?.status ?? null,
        });
        return {
          mode: "demo" as const,
          text,
          label: "Demo draft — not a live model",
          notice:
            "Sample workspace. This is a template filled with fictional details, not a live model. Nothing is saved or sent.",
        };
      }),
    loadSample: () =>
      run(() => {
        const profile = business.companyName.trim() ? business : sampleBusiness();
        const next = buildSample(profile, "demo");
        if (!business.companyName.trim()) setBusiness(profile);
        setLeads(next.leads);
        setQuotes(next.quotes);
        setFollowUps(next.followUps);
      }),
    clearSample: () =>
      run(() => {
        setLeads((current) => current.filter((item) => !item.isSample));
        setQuotes((current) => current.filter((item) => !item.isSample));
        setFollowUps((current) => current.filter((item) => !item.isSample));
        setBusiness((current) => ({ ...current, sampleLoaded: false }));
      }),
  };

  return <WorkspaceContext.Provider value={api}>{children}</WorkspaceContext.Provider>;
}
