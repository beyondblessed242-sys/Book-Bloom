import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Field, Notice } from "@/components/field";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { centsToInput, parseDollarsToCents } from "@/lib/money";
import { TONES, type Business, type Tone } from "@/lib/types";
import { useWorkspace } from "./workspace";

type RateDraft = { id: string; label: string; base: string; perRoom: string; perSqft: string };
type ExtraDraft = { id: string; name: string; price: string };

function fromBusiness(business: Business) {
  return {
    companyName: business.companyName,
    ownerName: business.ownerName,
    email: business.email,
    phone: business.phone,
    serviceArea: business.serviceArea,
    hours: business.hours,
    tone: business.tone,
    services: business.services.map((item) => ({
      id: item.id,
      label: item.label,
      base: centsToInput(item.baseCents),
      perRoom: centsToInput(item.perRoomCents),
      perSqft: centsToInput(item.perSqftCents),
    })),
    extras: business.extras.map((item) => ({
      id: item.id,
      name: item.name,
      price: centsToInput(item.cents),
    })),
  };
}

function nextId(label: string, taken: string[]) {
  const base = label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 24) || "item";
  let id = base;
  let n = 2;
  while (taken.includes(id)) id = `${base.slice(0, 20)}-${n++}`;
  return id;
}

export function SettingsPanel() {
  const workspace = useWorkspace();
  return <SettingsForm key={JSON.stringify(workspace.business)} />;
}

function SettingsForm() {
  const workspace = useWorkspace();
  const user = useCurrentUser();
  const [form, setForm] = useState(() => fromBusiness(workspace.business));
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setSaved(false);
    const services = [];
    for (const service of form.services) {
      const baseCents = parseDollarsToCents(service.base);
      const perRoomCents = parseDollarsToCents(service.perRoom);
      const perSqftCents = parseDollarsToCents(service.perSqft);
      if (baseCents == null || perRoomCents == null || perSqftCents == null) {
        setError("Rate amounts need to look like 89.00 or 0.08.");
        return;
      }
      services.push({ id: service.id, label: service.label, baseCents, perRoomCents, perSqftCents });
    }
    const extras = [];
    for (const extra of form.extras) {
      const cents = parseDollarsToCents(extra.price);
      if (cents == null) {
        setError("Extra prices need to look like 35.00.");
        return;
      }
      extras.push({ id: extra.id, name: extra.name, cents });
    }
    try {
      await workspace.saveBusiness({ ...form, tone: form.tone, services, extras });
      setError(null);
      setSaved(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save settings.");
    }
  }

  function patchService(index: number, patch: Partial<RateDraft>) {
    setForm((current) => ({
      ...current,
      services: current.services.map((item, i) => (i === index ? { ...item, ...patch } : item)),
    }));
  }

  function patchExtra(index: number, patch: Partial<ExtraDraft>) {
    setForm((current) => ({
      ...current,
      extras: current.extras.map((item, i) => (i === index ? { ...item, ...patch } : item)),
    }));
  }

  return (
    <form className="grid gap-5" onSubmit={(event) => void save(event)}>
      <div>
        <h1 className="font-display text-3xl">Settings</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted">
          Suggested rates are a starting point, not a promise of what you should charge. Set any rate to 0.00 if you do not use that measure. Both rooms and square feet are added when a quote includes both.
        </p>
      </div>
      {workspace.mode === "live" ? (
        <Notice>Signed in as {user?.primaryEmail ?? user?.displayName ?? "your account"}. That sign-in address is separate from the public contact email below. Personal name, password, and notifications are in <Link to="/account/profile" className="text-accent">My Profile</Link>.</Notice>
      ) : null}
      <section className="card grid gap-3 p-5">
        <h2 className="font-display text-xl">Business profile</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Company name">
            <input className="field-input" value={form.companyName} onChange={(event) => setForm({ ...form, companyName: event.target.value })} />
          </Field>
          <Field label="Your name">
            <input className="field-input" value={form.ownerName} onChange={(event) => setForm({ ...form, ownerName: event.target.value })} />
          </Field>
          <Field label="Public contact email">
            <input className="field-input" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} />
          </Field>
          <Field label="Phone">
            <input className="field-input" value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} />
          </Field>
        </div>
        <Field label="Service area">
          <input className="field-input" value={form.serviceArea} onChange={(event) => setForm({ ...form, serviceArea: event.target.value })} />
        </Field>
        <Field label="Business hours">
          <input className="field-input" value={form.hours} onChange={(event) => setForm({ ...form, hours: event.target.value })} />
        </Field>
      </section>
      <section className="card grid gap-3 p-5">
        <h2 className="font-display text-xl">Response tone</h2>
        <div className="grid gap-2">
          {TONES.map((tone) => (
            <label key={tone.id} className="flex min-h-11 items-center gap-2 text-sm">
              <input type="radio" name="tone" checked={form.tone === tone.id} onChange={() => setForm({ ...form, tone: tone.id as Tone })} />
              <span><span className="font-medium">{tone.label}.</span> <span className="text-muted">{tone.hint}</span></span>
            </label>
          ))}
        </div>
      </section>
      <section className="card grid gap-4 p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-display text-xl">Rate card</h2>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() =>
              setForm((current) => ({
                ...current,
                services: [
                  ...current.services,
                  { id: nextId("service", current.services.map((item) => item.id)), label: "New service", base: "0.00", perRoom: "0.00", perSqft: "0.00" },
                ],
              }))
            }
          >
            Add service
          </button>
        </div>
        {form.services.map((service, index) => (
          <div key={service.id} className="grid gap-2 rounded-2xl border border-line p-3">
            <Field label="Service name">
              <input className="field-input" value={service.label} onChange={(event) => patchService(index, { label: event.target.value })} />
            </Field>
            <div className="grid gap-2 sm:grid-cols-3">
              <Field label="Base ($)">
                <input className="field-input" value={service.base} onChange={(event) => patchService(index, { base: event.target.value })} />
              </Field>
              <Field label="Per room ($)">
                <input className="field-input" value={service.perRoom} onChange={(event) => patchService(index, { perRoom: event.target.value })} />
              </Field>
              <Field label="Per sq ft ($)">
                <input className="field-input" value={service.perSqft} onChange={(event) => patchService(index, { perSqft: event.target.value })} />
              </Field>
            </div>
            {form.services.length > 1 ? (
              <button type="button" className="btn btn-ghost w-fit" onClick={() => setForm((current) => ({ ...current, services: current.services.filter((_, i) => i !== index) }))}>
                Remove service
              </button>
            ) : null}
          </div>
        ))}
      </section>
      <section className="card grid gap-4 p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-display text-xl">Extras</h2>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() =>
              setForm((current) => ({
                ...current,
                extras: [...current.extras, { id: nextId("extra", current.extras.map((item) => item.id)), name: "New extra", price: "0.00" }],
              }))
            }
          >
            Add extra
          </button>
        </div>
        {form.extras.length === 0 ? <p className="text-sm text-muted">No extras. Quotes will only use the service rates.</p> : null}
        {form.extras.map((extra, index) => (
          <div key={extra.id} className="grid gap-2 sm:grid-cols-[1fr_10rem_auto] sm:items-end">
            <Field label="Name">
              <input className="field-input" value={extra.name} onChange={(event) => patchExtra(index, { name: event.target.value })} />
            </Field>
            <Field label="Price ($)">
              <input className="field-input" value={extra.price} onChange={(event) => patchExtra(index, { price: event.target.value })} />
            </Field>
            <button type="button" className="btn btn-ghost" onClick={() => setForm((current) => ({ ...current, extras: current.extras.filter((_, i) => i !== index) }))}>
              Remove
            </button>
          </div>
        ))}
      </section>
      {error ? <p className="text-sm text-warn" role="alert">{error}</p> : null}
      {saved ? <p className="text-sm text-accent" role="status">Saved.</p> : null}
      <button className="btn btn-primary w-fit" type="submit" disabled={workspace.saving}>{workspace.saving ? "Saving…" : "Save settings"}</button>
      <section className="card grid gap-3 p-5">
        <h2 className="font-display text-xl">Sample workspace</h2>
        <p className="text-sm text-muted">
          Loads fictional leads for Harbor & Pine Cleaning, all using example.com addresses. If your company name is still blank, the sample profile fills it too. Your own leads are kept. Removing the sample deletes only rows marked sample.
        </p>
        <div className="flex flex-wrap gap-2">
          <button type="button" className="btn btn-secondary" onClick={() => void workspace.loadSample()}>Load sample data</button>
          <button type="button" className="btn btn-ghost" onClick={() => void workspace.clearSample()}>Remove sample data</button>
        </div>
      </section>
    </form>
  );
}
