import { useMemo, useState } from "react";
import { Field } from "@/components/field";
import { Modal } from "@/components/modal";
import { formatDay, isOverdue, todayISO } from "@/lib/dates";
import type { FollowUp } from "@/lib/types";
import { useWorkspace } from "./workspace";

type Filter = "open" | "overdue" | "upcoming" | "done";

export function FollowUpsPanel() {
  const workspace = useWorkspace();
  const today = todayISO();
  const [filter, setFilter] = useState<Filter>("open");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ id: undefined as string | undefined, leadId: "", title: "", dueDate: today, notes: "" });
  const [formError, setFormError] = useState<string | null>(null);

  const rows = useMemo(() => {
    return workspace.followUps.filter((item) => {
      if (filter === "done") return item.done;
      if (filter === "overdue") return isOverdue(item.dueDate, item.done, today);
      if (filter === "upcoming") return !item.done && item.dueDate >= today;
      return !item.done;
    });
  }, [workspace.followUps, filter, today]);

  function edit(item?: FollowUp) {
    setFormError(null);
    setForm(
      item
        ? { id: item.id, leadId: item.leadId ?? "", title: item.title, dueDate: item.dueDate, notes: item.notes }
        : { id: undefined, leadId: workspace.leads[0]?.id ?? "", title: "", dueDate: today, notes: "" },
    );
    setOpen(true);
  }

  async function save(event: React.FormEvent) {
    event.preventDefault();
    try {
      await workspace.upsertFollowUp({
        id: form.id,
        leadId: form.leadId || null,
        title: form.title,
        dueDate: form.dueDate,
        notes: form.notes,
      });
      setOpen(false);
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "Could not save that reminder.");
    }
  }

  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl">Follow-ups</h1>
          <p className="mt-1 text-sm text-muted">Reminders stay in this dashboard. BookBloom will not text or email them for you.</p>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => edit()}>Add reminder</button>
      </div>
      <div className="flex gap-2 overflow-x-auto" role="tablist" aria-label="Filter reminders">
        {([
          ["open", "Open"],
          ["overdue", "Overdue"],
          ["upcoming", "Upcoming"],
          ["done", "Done"],
        ] as const).map(([id, label]) => (
          <button key={id} type="button" className={filter === id ? "btn btn-primary" : "btn btn-ghost"} onClick={() => setFilter(id)} aria-pressed={filter === id}>
            {label}
          </button>
        ))}
      </div>
      {rows.length === 0 ? (
        <p className="text-sm text-muted">Nothing in this filter.</p>
      ) : (
        <ul className="grid gap-3">
          {rows.map((item) => {
            const overdue = isOverdue(item.dueDate, item.done, today);
            return (
              <li key={item.id} className={overdue ? "card bg-warn-soft p-4" : "card p-4"}>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="font-medium">{item.title}</p>
                    <p className="mt-1 text-sm text-muted">
                      {item.leadName || "No lead"} · {formatDay(item.dueDate)}
                      {item.isSample ? " · Sample" : ""}
                      {overdue ? " · Overdue" : ""}
                    </p>
                    {item.notes ? <p className="mt-1 text-sm">{item.notes}</p> : null}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button type="button" className="btn btn-secondary" onClick={() => void workspace.setFollowUpDone(item.id, !item.done)}>
                      {item.done ? "Reopen" : "Mark done"}
                    </button>
                    <button type="button" className="btn btn-ghost" onClick={() => edit(item)}>Edit</button>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
      <Modal title={form.id ? "Edit reminder" : "Add reminder"} open={open} onClose={() => setOpen(false)}>
        <form className="grid gap-3" onSubmit={(event) => void save(event)}>
          <Field label="Reminder">
            <input className="field-input" required value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} />
          </Field>
          <Field label="Lead">
            <select className="field-input" value={form.leadId} onChange={(event) => setForm({ ...form, leadId: event.target.value })}>
              <option value="">No lead</option>
              {workspace.leads.map((lead) => (
                <option key={lead.id} value={lead.id}>{lead.name}</option>
              ))}
            </select>
          </Field>
          <Field label="Due date">
            <input className="field-input" type="date" required value={form.dueDate} onChange={(event) => setForm({ ...form, dueDate: event.target.value })} />
          </Field>
          <Field label="Notes">
            <textarea className="field-input" value={form.notes} onChange={(event) => setForm({ ...form, notes: event.target.value })} />
          </Field>
          {formError ? <p className="text-sm text-warn">{formError}</p> : null}
          <div className="flex flex-wrap gap-2">
            <button className="btn btn-primary" type="submit" disabled={workspace.saving}>{workspace.saving ? "Saving…" : "Save reminder"}</button>
            {form.id ? (
              <button
                type="button"
                className="btn btn-warn"
                onClick={() => {
                  void workspace.deleteFollowUp(form.id!).then(() => setOpen(false)).catch((error: unknown) => {
                    setFormError(error instanceof Error ? error.message : "Could not delete that reminder.");
                  });
                }}
              >
                Delete
              </button>
            ) : null}
          </div>
        </form>
      </Modal>
    </div>
  );
}
