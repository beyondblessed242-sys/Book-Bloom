import { formatDay, isDue, todayISO } from "@/lib/dates";
import { LEAD_STATUSES } from "@/lib/types";
import { useWorkspace } from "./workspace";

export function OverviewPanel() {
  const { leads, quotes, followUps, business } = useWorkspace();
  const today = todayISO();
  const due = followUps.filter((item) => isDue(item.dueDate, item.done, today));
  const drafts = quotes.filter((item) => item.status === "draft");
  const max = Math.max(1, ...LEAD_STATUSES.map((status) => leads.filter((lead) => lead.status === status.id).length));

  return (
    <div className="grid gap-4">
      <div>
        <h1 className="font-display text-3xl text-ink">Overview</h1>
        <p className="mt-1 text-muted">
          {business.companyName ? business.companyName : "Add your company name in Settings."} Rates on file are yours to edit. Nothing on this page sends a message.
        </p>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="Leads" value={String(leads.length)} hint="In this workspace" />
        <Stat label="Pending estimates" value={String(drafts.length)} hint="Still marked draft" />
        <Stat label="Follow-ups due" value={String(due.length)} hint="Today or overdue" />
      </div>
      <section className="card p-5">
        <h2 className="font-display text-xl">Pipeline</h2>
        <ul className="mt-4 grid gap-3">
          {LEAD_STATUSES.map((status) => {
            const count = leads.filter((lead) => lead.status === status.id).length;
            return (
              <li key={status.id} className="grid grid-cols-[7rem_1fr_2rem] items-center gap-3 text-sm">
                <span>{status.label}</span>
                <span className="h-2 overflow-hidden rounded-full bg-bg">
                  <span className="block h-full rounded-full bg-accent" style={{ width: `${(count / max) * 100}%` }} />
                </span>
                <span className="tabular-nums text-muted">{count}</span>
              </li>
            );
          })}
        </ul>
      </section>
      <section className="card p-5">
        <h2 className="font-display text-xl">Reminders</h2>
        {due.length === 0 ? (
          <p className="mt-3 text-sm text-muted">No follow-ups due. Add one from the Follow-ups tab when you want a nudge inside the dashboard.</p>
        ) : (
          <ul className="mt-3 grid gap-2">
            {due.map((item) => (
              <li key={item.id} className="flex flex-wrap items-baseline justify-between gap-2 rounded-xl bg-bg px-3 py-2 text-sm">
                <span>{item.title}</span>
                <span className="text-muted">{item.leadName ? `${item.leadName} · ` : ""}{formatDay(item.dueDate)}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function Stat({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <article className="card p-5">
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-1 font-display text-4xl tabular-nums text-ink">{value}</p>
      <p className="mt-1 text-xs text-muted">{hint}</p>
    </article>
  );
}
