import { Notice } from "@/components/field";
import { foundersPriceLabel } from "@/lib/pricing";

const INCLUDED = [
  "One business profile and rate card",
  "Lead records with search and status",
  "Estimates calculated from your rates",
  "Editable message drafts you copy yourself",
  "Follow-up reminders inside the dashboard",
];

export function BillingPanel({ checkout = false }: { checkout?: boolean }) {
  return (
    <div className="grid gap-4">
      <div>
        <h1 className="font-display text-3xl">Billing</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted">
          The Founder’s Plan is a proposed price. Payments are not connected, so this page cannot start a subscription.
        </p>
      </div>
      {checkout ? (
        <Notice tone="warn">
          This page does not activate a subscription. BookBloom has no payment processor connected, so nothing was charged and your account was not upgraded. Visiting a success address does not grant paid access.
        </Notice>
      ) : null}
      <article className="card max-w-xl p-6">
        <p className="pill">Proposed</p>
        <h2 className="mt-4 font-display text-3xl">Founder’s Plan</h2>
        <p className="mt-2 font-display text-5xl tabular-nums">{foundersPriceLabel()}<span className="text-2xl text-muted">/month</span></p>
        <p className="mt-2 text-sm text-muted">Shown for planning. Not billed. Not a live checkout.</p>
        <ul className="mt-5 grid gap-2 text-sm">
          {INCLUDED.map((item) => (
            <li key={item} className="border-b border-line pb-2">{item}</li>
          ))}
        </ul>
        <div className="mt-5 rounded-2xl bg-bg p-4 text-sm text-muted">
          Stripe is not configured. There is no card form, no trial, and no upgrade button. When payments are added, they will be tested before any subscription can start.
        </div>
      </article>
    </div>
  );
}
