import { useMemo, useState } from "react";
import { Field } from "@/components/field";
import { Modal } from "@/components/modal";
import { centsToInput, formatMoney, parseDollarsToCents } from "@/lib/money";
import { calculateQuote, explainQuote } from "@/lib/quotes";
import { FREQUENCIES, QUOTE_STATUSES, type FrequencyId, type Quote, type QuoteStatus } from "@/lib/types";
import { useWorkspace } from "./workspace";

type FormState = {
  id?: string;
  leadId: string;
  serviceId: string;
  rooms: string;
  sqft: string;
  frequency: FrequencyId;
  extraIds: string[];
  adjustment: string;
  explanation: string;
  explanationTouched: boolean;
  status: QuoteStatus;
};

export function QuotesPanel() {
  const workspace = useWorkspace();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<FormState | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const preview = useMemo(() => {
    if (!form) return null;
    const adjustment = parseDollarsToCents(form.adjustment, true);
    if (adjustment == null) return { error: "Adjustment must be a dollar amount." as string, quote: null };
    try {
      const quote = calculateQuote({
        services: workspace.business.services,
        extrasCatalog: workspace.business.extras,
        serviceId: form.serviceId,
        rooms: Number(form.rooms || 0),
        sqft: Number(form.sqft || 0),
        frequency: form.frequency,
        extraIds: form.extraIds,
        adjustmentCents: adjustment,
      });
      return { error: null, quote };
    } catch (error) {
      return { error: error instanceof Error ? error.message : "Could not calculate.", quote: null };
    }
  }, [form, workspace.business]);

  function start(existing?: Quote) {
    const first = workspace.business.services[0];
    const base: FormState = existing
      ? {
          id: existing.id,
          leadId: existing.leadId ?? "",
          serviceId: existing.breakdown.serviceId,
          rooms: String(existing.breakdown.rooms || ""),
          sqft: String(existing.breakdown.sqft || ""),
          frequency: existing.breakdown.frequency,
          extraIds: existing.breakdown.extras.map((item) => item.id),
          adjustment: centsToInput(existing.breakdown.adjustmentCents),
          explanation: existing.explanation,
          explanationTouched: true,
          status: existing.status,
        }
      : {
          leadId: "",
          serviceId: first?.id ?? "",
          rooms: "",
          sqft: "",
          frequency: "one-time",
          extraIds: [],
          adjustment: "0.00",
          explanation: "",
          explanationTouched: false,
          status: "draft",
        };
    setForm(base);
    setFormError(null);
    setOpen(true);
  }

  function update(patch: Partial<FormState>, fromLead = false) {
    setForm((current) => {
      if (!current) return current;
      const next = { ...current, ...patch };
      if (!fromLead && (patch.serviceId || patch.rooms || patch.sqft || patch.frequency || patch.extraIds || patch.adjustment)) {
        next.explanationTouched = current.explanationTouched;
      }
      return next;
    });
  }

  function applyLead(leadId: string) {
    const lead = workspace.leads.find((item) => item.id === leadId);
    if (!lead) {
      update({ leadId: "" });
      return;
    }
    update({
      leadId,
      serviceId: lead.serviceId,
      rooms: lead.rooms == null ? "" : String(lead.rooms),
      sqft: lead.sqft == null ? "" : String(lead.sqft),
      frequency: lead.frequency,
      explanationTouched: false,
    });
  }

  const explanation = form && preview?.quote
    ? form.explanationTouched
      ? form.explanation
      : explainQuote(preview.quote)
    : form?.explanation ?? "";

  async function save(event: React.FormEvent) {
    event.preventDefault();
    if (!form || !preview?.quote) {
      setFormError(preview?.error ?? "Check the estimate.");
      return;
    }
    try {
      await workspace.upsertQuote({
        id: form.id,
        leadId: form.leadId || null,
        serviceId: form.serviceId,
        rooms: preview.quote.rooms,
        sqft: preview.quote.sqft,
        frequency: form.frequency,
        extraIds: form.extraIds,
        adjustmentCents: preview.quote.adjustmentCents,
        explanation,
        status: form.status,
      });
      setOpen(false);
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "Could not save that estimate.");
    }
  }

  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl">Quotes</h1>
          <p className="mt-1 max-w-2xl text-sm text-muted">
            Totals come from your rate card. A model can help explain them later, but it cannot set the price. Recurring discounts apply to the cleaning subtotal. Extras stay full price.
          </p>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => start()}>New estimate</button>
      </div>
      {workspace.quotes.length === 0 ? (
        <div className="card p-6 text-sm text-muted">No estimates yet. Build one from the rate card in Settings.</div>
      ) : (
        <ul className="grid gap-3">
          {workspace.quotes.map((quote) => (
            <li key={quote.id}>
              <button type="button" className="card flex w-full flex-wrap items-center justify-between gap-3 p-4 text-left" onClick={() => start(quote)}>
                <span>
                  <span className="font-medium">{quote.leadName || "No lead linked"}</span>
                  <span className="mt-1 block text-sm text-muted">
                    {quote.breakdown.serviceLabel} · {quote.breakdown.frequencyLabel}
                    {quote.isSample ? " · Sample" : ""}
                  </span>
                </span>
                <span className="text-right">
                  <span className="block font-display text-2xl tabular-nums">{formatMoney(quote.totalCents)}</span>
                  <span className="pill">{QUOTE_STATUSES.find((item) => item.id === quote.status)?.label}</span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
      <Modal title={form?.id ? "Edit estimate" : "New estimate"} open={open} onClose={() => setOpen(false)}>
        {form ? (
          <form className="grid gap-3" onSubmit={(event) => void save(event)}>
            <Field label="Lead" hint="Optional. Choosing one fills rooms and service.">
              <select className="field-input" value={form.leadId} onChange={(event) => applyLead(event.target.value)}>
                <option value="">No lead</option>
                {workspace.leads.map((lead) => (
                  <option key={lead.id} value={lead.id}>{lead.name}</option>
                ))}
              </select>
            </Field>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Service">
                <select className="field-input" value={form.serviceId} onChange={(event) => update({ serviceId: event.target.value, explanationTouched: false })}>
                  {workspace.business.services.map((service) => (
                    <option key={service.id} value={service.id}>{service.label}</option>
                  ))}
                </select>
              </Field>
              <Field label="Frequency">
                <select className="field-input" value={form.frequency} onChange={(event) => update({ frequency: event.target.value as FrequencyId, explanationTouched: false })}>
                  {FREQUENCIES.map((item) => (
                    <option key={item.id} value={item.id}>{item.label}</option>
                  ))}
                </select>
              </Field>
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              <Field label="Rooms">
                <input className="field-input" inputMode="numeric" value={form.rooms} onChange={(event) => update({ rooms: event.target.value, explanationTouched: false })} />
              </Field>
              <Field label="Square feet">
                <input className="field-input" inputMode="numeric" value={form.sqft} onChange={(event) => update({ sqft: event.target.value, explanationTouched: false })} />
              </Field>
              <Field label="Owner adjustment" hint="Use a minus for a discount you chose.">
                <input className="field-input" value={form.adjustment} onChange={(event) => update({ adjustment: event.target.value, explanationTouched: false })} />
              </Field>
            </div>
            {workspace.business.extras.length > 0 ? (
              <fieldset className="grid gap-2">
                <legend className="text-sm font-medium">Approved extras</legend>
                {workspace.business.extras.map((extra) => (
                  <label key={extra.id} className="flex min-h-11 items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={form.extraIds.includes(extra.id)}
                      onChange={(event) => {
                        const extraIds = event.target.checked
                          ? [...form.extraIds, extra.id]
                          : form.extraIds.filter((id) => id !== extra.id);
                        update({ extraIds, explanationTouched: false });
                      }}
                    />
                    {extra.name} · {formatMoney(extra.cents)}
                  </label>
                ))}
              </fieldset>
            ) : null}
            <Field label="Status" hint="Marked sent only updates your tracker. You still send the message yourself.">
              <select className="field-input" value={form.status} onChange={(event) => update({ status: event.target.value as QuoteStatus })}>
                {QUOTE_STATUSES.map((item) => (
                  <option key={item.id} value={item.id}>{item.label}</option>
                ))}
              </select>
            </Field>
            {preview?.quote ? (
              <div className="rounded-2xl bg-bg p-4 text-sm">
                <p className="font-display text-3xl tabular-nums">{formatMoney(preview.quote.totalCents)}</p>
                <ul className="mt-2 grid gap-1 text-muted">
                  <li>Base {formatMoney(preview.quote.baseCents)}</li>
                  <li>Rooms {formatMoney(preview.quote.roomsCents)}</li>
                  <li>Square feet {formatMoney(preview.quote.sqftCents)}</li>
                  <li>After frequency {formatMoney(preview.quote.frequencyCents)}</li>
                  <li>Extras {formatMoney(preview.quote.extrasCents)}</li>
                  <li>Adjustment {formatMoney(preview.quote.adjustmentCents)}</li>
                </ul>
              </div>
            ) : null}
            <Field label="Explanation" hint="Starts from the math. You can edit the wording. The total above does not change if you rewrite this.">
              <textarea
                className="field-input"
                value={explanation}
                onChange={(event) => update({ explanation: event.target.value, explanationTouched: true })}
              />
            </Field>
            {preview?.error || formError ? <p className="text-sm text-warn">{formError || preview?.error}</p> : null}
            <div className="flex flex-wrap gap-2">
              <button className="btn btn-primary" type="submit" disabled={workspace.saving || !preview?.quote}>
                {workspace.saving ? "Saving…" : "Save estimate"}
              </button>
              {form.id ? (
                <button
                  type="button"
                  className="btn btn-warn"
                  onClick={() => {
                    void workspace.deleteQuote(form.id!).then(() => setOpen(false)).catch((error: unknown) => {
                      setFormError(error instanceof Error ? error.message : "Could not delete that estimate.");
                    });
                  }}
                >
                  Delete
                </button>
              ) : null}
            </div>
          </form>
        ) : null}
      </Modal>
    </div>
  );
}
