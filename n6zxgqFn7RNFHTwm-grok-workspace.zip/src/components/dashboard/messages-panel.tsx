import { useState } from "react";
import { Field, Notice } from "@/components/field";
import { MESSAGE_TYPES, type MessageType } from "@/lib/types";
import { useWorkspace } from "./workspace";

export function MessagesPanel() {
  const workspace = useWorkspace();
  const [leadId, setLeadId] = useState(workspace.leads[0]?.id ?? "");
  const [messageType, setMessageType] = useState<MessageType>("initial");
  const [text, setText] = useState("");
  const [label, setLabel] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);

  async function generate() {
    setError(null);
    setCopied(false);
    if (!leadId) {
      setError("Add a lead first.");
      return;
    }
    setBusy(true);
    try {
      const result = await workspace.draftMessage(leadId, messageType);
      setText(result.text);
      setLabel(result.label);
      setNotice(result.notice);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not draft that message.");
    } finally {
      setBusy(false);
    }
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
    } catch {
      setError("Could not copy. Select the text and copy it manually.");
    }
  }

  return (
    <div className="grid gap-4">
      <div>
        <h1 className="font-display text-3xl">Message assistant</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted">
          Drafts use the company details, tone, and estimate you saved. They do not include the customer’s email or phone. You copy the text and send it yourself.
        </p>
      </div>
      {!workspace.aiLive || workspace.mode === "demo" ? (
        <Notice>Demo drafts are templates, not a live model. If a server key is connected on a real account, drafts are labeled “Drafted with Grok”.</Notice>
      ) : (
        <Notice>Grok is available for drafts you request. Prices are limited to the estimate on file. Each draft is logged toward a daily cap of 40.</Notice>
      )}
      {workspace.leads.length === 0 ? (
        <div className="card p-6 text-sm text-muted">Add a lead before drafting a message.</div>
      ) : (
        <div className="card grid gap-4 p-5">
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Lead">
              <select className="field-input" value={leadId} onChange={(event) => setLeadId(event.target.value)}>
                {workspace.leads.map((lead) => (
                  <option key={lead.id} value={lead.id}>{lead.name}{lead.isSample ? " (sample)" : ""}</option>
                ))}
              </select>
            </Field>
            <Field label="Message type">
              <select className="field-input" value={messageType} onChange={(event) => setMessageType(event.target.value as MessageType)}>
                {MESSAGE_TYPES.map((item) => (
                  <option key={item.id} value={item.id}>{item.label}</option>
                ))}
              </select>
            </Field>
          </div>
          <p className="text-xs text-muted">{MESSAGE_TYPES.find((item) => item.id === messageType)?.hint}</p>
          <button type="button" className="btn btn-primary w-fit" disabled={busy} onClick={() => void generate()}>
            {busy ? "Drafting…" : "Draft message"}
          </button>
          {label ? <p className="text-sm font-medium">{label}</p> : null}
          {notice ? <Notice>{notice}</Notice> : null}
          <Field label="Draft" hint="Edit before you copy. This box is not sent anywhere.">
            <textarea className="field-input" value={text} onChange={(event) => setText(event.target.value)} />
          </Field>
          {error ? <p className="text-sm text-warn" role="alert">{error}</p> : null}
          <div className="flex flex-wrap items-center gap-3">
            <button type="button" className="btn btn-secondary" disabled={!text} onClick={() => void copy()}>
              {copied ? "Copied" : "Copy"}
            </button>
            <span className="text-sm text-muted" aria-live="polite">{copied ? "On your clipboard. Send it from your own email or phone." : ""}</span>
          </div>
        </div>
      )}
    </div>
  );
}
