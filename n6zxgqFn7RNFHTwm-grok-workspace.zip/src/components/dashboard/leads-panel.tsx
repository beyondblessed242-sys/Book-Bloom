import { useMemo, useState } from "react";
import { Field } from "@/components/field";
import { Modal } from "@/components/modal";
import { formatDay } from "@/lib/dates";
import { FREQUENCIES, LEAD_STATUSES, type FrequencyId, type Lead, type LeadStatus, statusLabel } from "@/lib/types";
import { useWorkspace } from "./workspace";

const emptyForm = {
  id: undefined as string | undefined,
  name: "",
  email: "",
  phone: "",
  serviceId: "standard",
  rooms: "",
  sqft: "",
  frequency: "one-time" as FrequencyId,
  notes: "",
  status: "new" as LeadStatus,
  lastContact: "",
};

export function LeadsPanel() {
  const workspace = useWorkspace();
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<LeadStatus | "all">("all");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [formError, setFormError] = useState<string | null>(null);

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return workspace.leads.filter((lead) => {
      if (status !== "all" && lead.status !== status) return false;
      if (!q) return true;
      return [lead.name, lead.email, lead.phone, lead.serviceLabel, lead.notes].join(" ").toLowerCase().includes(q);
    });
  }, [workspace.leads, query, status]);

  function edit(lead?: Lead) {
    setFormError(null);
    if (!lead) {
      setForm({ ...emptyForm, serviceId: workspace.business.services[0]?.id ?? "standard" });
    } else {
      setForm({
        id: lead.id,
        name: lead.name,
        email: lead.email,
        phone: lead.phone,
        serviceId: lead.serviceId,
        rooms: lead.rooms == null ? "" : String(lead.rooms),
        sqft: lead.sqft == null ? "" : String(lead.sqft),
        frequency: lead.frequency,
        notes: lead.notes,
        status: lead.status,
        lastContact: lead.lastContact ?? "",
      });
    }
    setOpen(true);
  }

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setFormError(null);
    const rooms = form.rooms.trim() === "" ? null : Number(form.rooms);
    const sqft = form.sqft.trim() === "" ? null : Number(form.sqft);
    if (rooms != null && (!Number.isInteger(rooms) || rooms < 0)) {
      setFormError("Rooms must be a whole number.");
      return;
    }
    if (sqft != null && (!Number.isInteger(sqft) || sqft < 0)) {
      setFormError("Square footage must be a whole number.");
      return;
    }
    try {
      await workspace.upsertLead({
        id: form.id,
        name: form.name,
        email: form.email,
        phone: form.phone,
        serviceId: form.serviceId,
        rooms,
        sqft,
        frequency: form.frequency,
        notes: form.notes,
        status: form.status,
        lastContact: form.lastContact || null,
      });
      setOpen(false);
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "Could not save that lead.");
    }
  }

  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl">Leads</h1>
          <p className="mt-1 text-sm text-muted">Contact details stay in your account. BookBloom does not email or text them.</p>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => edit()}>
          Add lead
        </button>
      </div>
      <div className="grid gap-3 sm:grid-cols-[1fr_12rem]">
        <Field label="Search">
          <input className="field-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Name, phone, service, notes" />
        </Field>
        <Field label="Status">
          <select className="field-input" value={status} onChange={(event) => setStatus(event.target.value as LeadStatus | "all")}>
            <option value="all">All statuses</option>
            {LEAD_STATUSES.map((item) => (
              <option key={item.id} value={item.id}>{item.label}</option>
            ))}
          </select>
        </Field>
      </div>
      {workspace.leads.length === 0 ? (
        <div className="card p-6">
          <p className="font-medium">No leads yet.</p>
          <p className="mt-1 text-sm text-muted">Add someone you are talking to, or load the fictional sample workspace from Settings.</p>
        </div>
      ) : rows.length === 0 ? (
        <p className="text-sm text-muted">No leads match that search.</p>
      ) : (
        <ul className="grid gap-3">
          {rows.map((lead) => (
            <li key={lead.id}>
              <button type="button" className="card flex w-full flex-col gap-2 p-4 text-left" onClick={() => edit(lead)}>
                <span className="flex flex-wrap items-center gap-2">
                  <span className="font-medium">{lead.name}</span>
                  <span className="pill">{statusLabel(lead.status)}</span>
                  {lead.isSample ? <span className="pill pill-muted">Sample</span> : null}
                </span>
                <span className="text-sm text-muted">
                  {lead.serviceLabel} · {FREQUENCIES.find((item) => item.id === lead.frequency)?.label}
                  {lead.rooms != null ? ` · ${lead.rooms} rooms` : ""}
                  {lead.sqft != null ? ` · ${lead.sqft} sq ft` : ""}
                </span>
                <span className="text-sm text-muted">
                  {lead.phone || "No phone"} · {lead.email || "No email"} · Last contact {formatDay(lead.lastContact)}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
      <Modal title={form.id ? "Edit lead" : "Add lead"} open={open} onClose={() => setOpen(false)}>
        <form className="grid gap-3" onSubmit={(event) => void save(event)}>
          <Field label="Name">
            <input className="field-input" required value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} />
          </Field>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Email">
              <input className="field-input" type="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} />
            </Field>
            <Field label="Phone">
              <input className="field-input" value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} />
            </Field>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Service">
              <select className="field-input" value={form.serviceId} onChange={(event) => setForm({ ...form, serviceId: event.target.value })}>
                {workspace.business.services.map((service) => (
                  <option key={service.id} value={service.id}>{service.label}</option>
                ))}
              </select>
            </Field>
            <Field label="Status">
              <select className="field-input" value={form.status} onChange={(event) => setForm({ ...form, status: event.target.value as LeadStatus })}>
                {LEAD_STATUSES.map((item) => (
                  <option key={item.id} value={item.id}>{item.label}</option>
                ))}
              </select>
            </Field>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <Field label="Rooms" hint="Leave blank if unknown">
              <input className="field-input" inputMode="numeric" value={form.rooms} onChange={(event) => setForm({ ...form, rooms: event.target.value })} />
            </Field>
            <Field label="Square feet">
              <input className="field-input" inputMode="numeric" value={form.sqft} onChange={(event) => setForm({ ...form, sqft: event.target.value })} />
            </Field>
            <Field label="Frequency">
              <select className="field-input" value={form.frequency} onChange={(event) => setForm({ ...form, frequency: event.target.value as FrequencyId })}>
                {FREQUENCIES.map((item) => (
                  <option key={item.id} value={item.id}>{item.label}</option>
                ))}
              </select>
            </Field>
          </div>
          <Field label="Last contact">
            <input className="field-input" type="date" value={form.lastContact} onChange={(event) => setForm({ ...form, lastContact: event.target.value })} />
          </Field>
          <Field label="Notes">
            <textarea className="field-input" value={form.notes} onChange={(event) => setForm({ ...form, notes: event.target.value })} />
          </Field>
          {formError ? <p className="text-sm text-warn">{formError}</p> : null}
          <div className="flex flex-wrap gap-2">
            <button type="submit" className="btn btn-primary" disabled={workspace.saving}>{workspace.saving ? "Saving…" : "Save lead"}</button>
            {form.id ? (
              <button
                type="button"
                className="btn btn-warn"
                onClick={() => {
                  void workspace.deleteLead(form.id!).then(() => setOpen(false)).catch((error: unknown) => {
                    setFormError(error instanceof Error ? error.message : "Could not delete that lead.");
                  });
                }}
              >
                Delete
              </button>
            ) : null}
          </div>
        </form>
      </Modal>
    </div>
  );
}
