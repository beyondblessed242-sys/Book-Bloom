import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Logo } from "@/components/logo";
import { AccountMenu } from "./account-menu";

const NAV = [
  { href: "/account/profile", label: "Profile" },
  { href: "/account/security", label: "Security" },
  { href: "/account/notifications", label: "Notifications" },
  { href: "/account/subscription", label: "Subscription" },
  { href: "/account/privacy", label: "Account Management" },
] as const;

export function AccountShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  return (
    <div className="min-h-screen">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
          <Logo to="/app" />
          <AccountMenu />
        </div>
      </header>
      <div className="mx-auto grid max-w-6xl gap-6 px-4 py-6 md:grid-cols-[200px_1fr]">
        <nav aria-label="Account" className="flex gap-2 overflow-x-auto md:flex-col">
          {NAV.map((item) => (
            <Link
              key={item.href}
              to={item.href}
              className={pathname === item.href ? "btn btn-primary shrink-0" : "btn btn-ghost shrink-0"}
              aria-current={pathname === item.href ? "page" : undefined}
            >
              {item.label}
            </Link>
          ))}
          <Link to="/app/settings" className="btn btn-ghost shrink-0">Business settings</Link>
        </nav>
        <div className="grid gap-4">{children}</div>
      </div>
    </div>
  );
}
