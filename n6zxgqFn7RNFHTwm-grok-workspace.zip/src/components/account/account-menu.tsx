import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { authEnabled, signOut } from "@/lib/auth/client";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { initials } from "@/lib/account";
import { getAccountSummary } from "@/server/account";

const LINKS = [
  { href: "/account/profile", label: "My Profile" },
  { href: "/account/security", label: "Password & Security" },
  { href: "/account/notifications", label: "Notifications" },
  { href: "/account/subscription", label: "My Subscription" },
  { href: "/account/help", label: "Help & Support" },
] as const;

export function AccountMenu() {
  const sessionUser = useCurrentUser();
  const [open, setOpen] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const [name, setName] = useState(sessionUser?.displayName ?? "");
  const [photo, setPhoto] = useState<string | null>(sessionUser?.profileImageUrl ?? null);
  const [hq, setHq] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    function load() {
      void getAccountSummary()
        .then((summary) => {
          if (cancelled) return;
          setName(summary.displayName);
          setPhoto(summary.photoUrl);
          setHq(summary.canOpenHq);
        })
        .catch(() => undefined);
    }
    load();
    window.addEventListener("bookbloom-account", load);
    return () => {
      cancelled = true;
      window.removeEventListener("bookbloom-account", load);
    };
  }, []);

  useEffect(() => {
    if (!open) return;
    function onPointer(event: MouseEvent) {
      if (!menuRef.current?.contains(event.target as Node)) setOpen(false);
    }
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", onPointer);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onPointer);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  if (!sessionUser) return null;
  const label = name || sessionUser.displayName || sessionUser.primaryEmail || "Account";
  const mark = initials(label, sessionUser.primaryEmail ?? "");

  return (
    <div className="relative" ref={menuRef}>
      <button
        type="button"
        className="flex max-w-[14rem] items-center gap-2 rounded-full border border-line bg-bg py-1 pl-1 pr-3 text-left"
        aria-expanded={open}
        aria-haspopup="menu"
        onClick={() => setOpen((value) => !value)}
      >
        {photo ? (
          <img src={photo} alt="" className="size-8 rounded-full object-cover" />
        ) : (
          <span className="grid size-8 place-items-center rounded-full bg-accent text-xs font-medium text-bg">{mark}</span>
        )}
        <span className="truncate text-sm font-medium">{label}</span>
      </button>
      {open ? (
        <div role="menu" className="absolute right-0 z-40 mt-2 w-60 rounded-2xl border border-line bg-surface p-2 shadow-lg">
          {hq ? (
            <Link to="/hq" role="menuitem" className="block rounded-xl px-3 py-2 text-sm text-accent" onClick={() => setOpen(false)}>
              BookBloom HQ
            </Link>
          ) : null}
          {LINKS.map((item) => (
            <Link key={item.href} to={item.href} role="menuitem" className="block rounded-xl px-3 py-2 text-sm hover:bg-accent-soft" onClick={() => setOpen(false)}>
              {item.label}
            </Link>
          ))}
          {authEnabled ? (
            <button
              type="button"
              role="menuitem"
              className="block w-full rounded-xl px-3 py-2 text-left text-sm hover:bg-accent-soft"
              disabled={signingOut}
              onClick={() => {
                setSigningOut(true);
                void signOut("/").catch(() => setSigningOut(false));
              }}
            >
              {signingOut ? "Signing out…" : "Sign Out"}
            </button>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
