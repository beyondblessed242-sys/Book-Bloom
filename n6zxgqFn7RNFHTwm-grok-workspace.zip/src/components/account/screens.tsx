import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { PasswordField } from "@/components/auth/password-field";
import { Field, Notice } from "@/components/field";
import { TIMEZONES, initials, type NotificationInput, type ProfileInput } from "@/lib/account";
import { changeAccountPassword } from "@/lib/email-session";
import { confirmAuthenticator, startAuthenticator } from "@/lib/mfa-client";
import { foundersPriceLabel } from "@/lib/pricing";
import { passwordError, passwordRules } from "@/lib/password-policy";
import {
  exportAccountData,
  getAccountSummary,
  listAccountSessions,
  requestAccountDeletion,
  revokeOtherAccountSessions,
  saveAccountPhoto,
  saveAccountProfile,
  saveNotificationPreferences,
} from "@/server/account";

type Summary = Awaited<ReturnType<typeof getAccountSummary>>;

function useSummary() {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  function reload() {
    setLoading(true);
    return getAccountSummary()
      .then((value) => {
        setSummary(value);
        setError(null);
      })
      .catch((err: unknown) => setError(err instanceof Error ? err.message : "Could not load your account."))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    void reload();
  }, []);

  return { summary, error, loading, reload };
}

export function ProfileScreen() {
  const { summary, error, loading, reload } = useSummary();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState<ProfileInput | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [warn, setWarn] = useState(false);
  const [busy, setBusy] = useState(false);

  function startEdit() {
    if (!summary) return;
    setForm({
      firstName: summary.firstName,
      lastName: summary.lastName,
      displayName: summary.displayName,
      phone: summary.phone,
      timezone: summary.timezone as ProfileInput["timezone"],
    });
    setEditing(true);
    setMessage(null);
  }

  async function save(event: React.FormEvent) {
    event.preventDefault();
    if (!form) return;
    setBusy(true);
    setMessage(null);
    try {
      await saveAccountProfile({ data: form });
      window.dispatchEvent(new CustomEvent("bookbloom-account"));
      setEditing(false);
      setWarn(false);
      setMessage("Profile saved.");
      await reload();
    } catch (err) {
      setWarn(true);
      setMessage(err instanceof Error ? err.message : "Could not save your profile.");
    } finally {
      setBusy(false);
    }
  }

  async function onPhoto(file: File | null) {
    if (!file) return;
    if (file.size > 400_000) {
      setWarn(true);
      setMessage("Photo must be under 400 KB.");
      return;
    }
    const dataUrl = await fileToDataUrl(file);
    setBusy(true);
    try {
      await saveAccountPhoto({ data: { dataUrl } });
      window.dispatchEvent(new CustomEvent("bookbloom-account"));
      setWarn(false);
      setMessage("Photo saved.");
      await reload();
    } catch (err) {
      setWarn(true);
      setMessage(err instanceof Error ? err.message : "Could not save that photo.");
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <p className="text-muted">Loading your profile…</p>;
  if (error || !summary) return <Notice tone="warn">{error ?? "Could not load your profile."}</Notice>;
  const mark = initials(summary.displayName, summary.email);

  return (
    <form className="grid gap-4" onSubmit={(event) => void save(event)}>
      <div>
        <h1 className="font-display text-3xl">My Profile</h1>
        <p className="mt-1 text-sm text-muted">Personal details for your sign-in. Business rates stay in Business settings.</p>
      </div>
      {message ? <Notice tone={warn ? "warn" : "info"}>{message}</Notice> : null}
      <section className="card grid gap-4 p-5">
        <div className="flex flex-wrap items-center gap-4">
          {summary.photoUrl ? (
            <img src={summary.photoUrl} alt="" className="size-16 rounded-full object-cover" />
          ) : (
            <span className="grid size-16 place-items-center rounded-full bg-accent text-lg text-bg">{mark}</span>
          )}
          <div className="flex flex-wrap gap-2">
            <label className="btn btn-secondary cursor-pointer">
              Upload photo
              <input
                className="sr-only"
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={(event) => void onPhoto(event.target.files?.[0] ?? null)}
              />
            </label>
            {summary.photoUrl ? (
              <button
                type="button"
                className="btn btn-ghost"
                disabled={busy}
                onClick={() => {
                  setBusy(true);
                  void saveAccountPhoto({ data: { remove: true } })
                    .then(() => {
                      window.dispatchEvent(new CustomEvent("bookbloom-account"));
                      return reload();
                    })
                    .then(() => {
                      setWarn(false);
                      setMessage("Photo removed.");
                    })
                    .catch((err: unknown) => {
                      setWarn(true);
                      setMessage(err instanceof Error ? err.message : "Could not remove the photo.");
                    })
                    .finally(() => setBusy(false));
                }}
              >
                Remove photo
              </button>
            ) : null}
          </div>
        </div>
        <p className="text-xs text-muted">JPEG, PNG, or WebP, up to 400 KB. The photo is stored for your account only.</p>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="First name">
            <input className="field-input" disabled={!editing} value={editing ? form?.firstName ?? "" : summary.firstName} onChange={(event) => setForm({ ...form!, firstName: event.target.value })} />
          </Field>
          <Field label="Last name">
            <input className="field-input" disabled={!editing} value={editing ? form?.lastName ?? "" : summary.lastName} onChange={(event) => setForm({ ...form!, lastName: event.target.value })} />
          </Field>
          <Field label="Display name">
            <input className="field-input" disabled={!editing} value={editing ? form?.displayName ?? "" : summary.displayName} onChange={(event) => setForm({ ...form!, displayName: event.target.value })} />
          </Field>
          <Field label="Phone number">
            <input className="field-input" disabled={!editing} value={editing ? form?.phone ?? "" : summary.phone} onChange={(event) => setForm({ ...form!, phone: event.target.value })} />
          </Field>
          <Field label="Preferred timezone">
            <select className="field-input" disabled={!editing} value={editing ? form?.timezone ?? summary.timezone : summary.timezone} onChange={(event) => setForm({ ...form!, timezone: event.target.value as ProfileInput["timezone"] })}>
              {TIMEZONES.map((zone) => (
                <option key={zone} value={zone}>{zone}</option>
              ))}
            </select>
          </Field>
          <Field label="Display language" hint="Only English is available.">
            <input className="field-input" value="English" disabled />
          </Field>
        </div>
        <div className="grid gap-1 rounded-2xl border border-line bg-bg p-4 text-sm">
          <p>Registered email: {summary.email}</p>
          <p className="text-muted">Account created: {new Date(summary.createdAt).toLocaleDateString()}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {editing ? (
            <>
              <button className="btn btn-primary" type="submit" disabled={busy}>{busy ? "Saving…" : "Save Changes"}</button>
              <button className="btn btn-ghost" type="button" onClick={() => { setEditing(false); setForm(null); }}>Cancel</button>
            </>
          ) : (
            <button className="btn btn-primary" type="button" onClick={startEdit}>Edit Profile</button>
          )}
        </div>
      </section>
    </form>
  );
}

export function SecurityScreen() {
  const { summary, error, loading } = useSummary();
  const [currentPassword, setCurrentPassword] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNext, setShowNext] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [warn, setWarn] = useState(false);
  const [busy, setBusy] = useState(false);
  const [sessions, setSessions] = useState<Awaited<ReturnType<typeof listAccountSessions>> | null>(null);
  const [mfaPassword, setMfaPassword] = useState("");
  const [mfaCode, setMfaCode] = useState("");
  const [totpUri, setTotpUri] = useState<string | null>(null);
  const [backupCodes, setBackupCodes] = useState<string[] | null>(null);
  const [qr, setQr] = useState<string | null>(null);

  useEffect(() => {
    void listAccountSessions().then(setSessions).catch((err: unknown) => {
      setSessions({ error: err instanceof Error ? err.message : "Sessions could not be listed.", sessions: [] });
    });
  }, []);

  useEffect(() => {
    if (!totpUri) return;
    let cancel = false;
    void import("qrcode").then(async (mod) => {
      const url = await mod.default.toDataURL(totpUri, { margin: 1, width: 180 });
      if (!cancel) setQr(url);
    }).catch(() => {
      if (!cancel) setQr(null);
    });
    return () => {
      cancel = true;
    };
  }, [totpUri]);

  async function beginMfa(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    try {
      const started = await startAuthenticator(mfaPassword);
      setTotpUri(started.totpURI);
      setBackupCodes(started.backupCodes);
      setWarn(false);
      setMessage("Scan the code, then enter the 6-digit code to finish. Save the backup codes now. They are not shown again.");
    } catch (err) {
      setWarn(true);
      setMessage(err instanceof Error ? err.message : "Authenticator setup did not start.");
    } finally {
      setBusy(false);
    }
  }

  async function finishMfa(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    try {
      await confirmAuthenticator(mfaCode.replace(/\s/g, ""));
      setWarn(false);
      setMessage("Authenticator enrolled. A code from that app is required the next time this account signs in with a password.");
      setTotpUri(null);
      setMfaCode("");
      setMfaPassword("");
    } catch (err) {
      setWarn(true);
      setMessage(err instanceof Error ? err.message : "That authenticator code was not accepted.");
    } finally {
      setBusy(false);
    }
  }

  async function savePassword(event: React.FormEvent) {
    event.preventDefault();
    const problem = passwordError(password);
    if (problem) {
      setWarn(true);
      setMessage(problem);
      return;
    }
    if (password !== confirm) {
      setWarn(true);
      setMessage("Those passwords do not match.");
      return;
    }
    setBusy(true);
    try {
      await changeAccountPassword({ currentPassword, newPassword: password });
      setCurrentPassword("");
      setPassword("");
      setConfirm("");
      setWarn(false);
      setMessage("Password updated. It is stored by the sign-in service, not in a BookBloom profile table.");
    } catch (err) {
      setWarn(true);
      setMessage(err instanceof Error ? err.message : "Could not change the password.");
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <p className="text-muted">Loading security…</p>;
  if (error || !summary) return <Notice tone="warn">{error ?? "Could not load security settings."}</Notice>;

  return (
    <div className="grid gap-4">
      <div>
        <h1 className="font-display text-3xl">Password & Security</h1>
        <p className="mt-1 text-sm text-muted">Password changes use the sign-in service. BookBloom does not keep a second copy of your password.</p>
      </div>
      {message ? <Notice tone={warn ? "warn" : "info"}>{message}</Notice> : null}
      <section className="card grid gap-3 p-5">
        <h2 className="font-display text-xl">Change password</h2>
        {summary.hasPassword ? (
          <form className="grid gap-3" onSubmit={(event) => void savePassword(event)}>
            <PasswordField label="Current password" value={currentPassword} onChange={setCurrentPassword} autoComplete="current-password" shown={showCurrent} onToggle={() => setShowCurrent((value) => !value)} />
            <PasswordField label="New password" value={password} onChange={setPassword} autoComplete="new-password" shown={showNext} onToggle={() => setShowNext((value) => !value)} />
            <ul className="grid gap-1 text-xs">
              {passwordRules(password).map((rule) => (
                <li key={rule.id} className={rule.met ? "text-accent" : "text-muted"}>{rule.met ? "Met" : "Needed"} — {rule.label}</li>
              ))}
            </ul>
            <PasswordField label="Confirm new password" value={confirm} onChange={setConfirm} autoComplete="new-password" shown={showConfirm} onToggle={() => setShowConfirm((value) => !value)} error={confirm && confirm !== password ? "Those passwords do not match." : undefined} />
            <button className="btn btn-primary w-fit" type="submit" disabled={busy}>{busy ? "Saving…" : "Save Password"}</button>
          </form>
        ) : (
          <p className="text-sm text-muted">This account signs in with Google or X and has no password here. A password is not required.</p>
        )}
        <p className="text-sm text-muted">Email-based password recovery is temporarily unavailable. If you know your current password, you can change it here.</p>
      </section>
      <section className="card grid gap-3 p-5">
        <h2 className="font-display text-xl">Email address</h2>
        <p className="text-sm">Current email: {summary.email}</p>
        <p className="text-sm text-muted">Changing the email address needs a confirmation message, which is temporarily unavailable. The address was not changed.</p>
      </section>
      <section className="card grid gap-3 p-5">
        <h2 className="font-display text-xl">Authenticator app</h2>
        <p className="text-sm text-muted">This uses an authenticator app, not email. Enrolling it does not make this account an administrator.</p>
        {summary.hasPassword ? (
          <form className="grid gap-3" onSubmit={(event) => void beginMfa(event)}>
            <PasswordField label="Current password" value={mfaPassword} onChange={setMfaPassword} autoComplete="current-password" shown={false} onToggle={() => undefined} />
            <button className="btn btn-secondary w-fit" type="submit" disabled={busy}>Start authenticator setup</button>
          </form>
        ) : (
          <p className="text-sm text-muted">Add a password to this account before enrolling an authenticator.</p>
        )}
        {qr ? <img src={qr} alt="Authenticator setup QR code" className="h-44 w-44 rounded-2xl border border-line bg-white p-2" /> : null}
        {totpUri ? <p className="break-all text-xs text-muted">Manual key: {totpUri}</p> : null}
        {backupCodes ? (
          <ul className="grid gap-1 text-sm">
            {backupCodes.map((code) => <li key={code} className="font-mono">{code}</li>)}
          </ul>
        ) : null}
        {totpUri ? (
          <form className="grid gap-3" onSubmit={(event) => void finishMfa(event)}>
            <Field label="6-digit code">
              <input className="field-input" inputMode="numeric" autoComplete="one-time-code" value={mfaCode} onChange={(event) => setMfaCode(event.target.value)} required />
            </Field>
            <button className="btn btn-primary w-fit" type="submit" disabled={busy}>Confirm authenticator</button>
          </form>
        ) : null}
      </section>
      <section className="card grid gap-3 p-5">
        <h2 className="font-display text-xl">Sessions</h2>
        {sessions?.error ? <Notice tone="warn">{sessions.error} Session tokens are not shown.</Notice> : null}
        {sessions && sessions.sessions.length === 0 && !sessions.error ? <p className="text-sm text-muted">No session list was returned.</p> : null}
        <ul className="grid gap-2 text-sm">
          {sessions?.sessions.map((session) => (
            <li key={session.id} className="rounded-2xl border border-line px-3 py-2">
              {session.current ? "This session" : "Other session"} · started {new Date(session.createdAt).toLocaleString()}
              {session.ipAddress ? ` · ${session.ipAddress}` : ""}
            </li>
          ))}
        </ul>
        <button
          type="button"
          className="btn btn-secondary w-fit"
          onClick={() => {
            setBusy(true);
            void revokeOtherAccountSessions()
              .then(() => listAccountSessions())
              .then((value) => {
                setSessions(value);
                setWarn(false);
                setMessage("Other sessions were signed out.");
              })
              .catch((err: unknown) => {
                setWarn(true);
                setMessage(err instanceof Error ? err.message : "Could not sign out other sessions.");
              })
              .finally(() => setBusy(false));
          }}
        >
          Sign out other sessions
        </button>
      </section>
    </div>
  );
}

export function NotificationsScreen() {
  const { summary, error, loading, reload } = useSummary();
  const [form, setForm] = useState<NotificationInput | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [warn, setWarn] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (summary) setForm(summary.notifications);
  }, [summary]);

  async function save(event: React.FormEvent) {
    event.preventDefault();
    if (!form) return;
    setBusy(true);
    try {
      await saveNotificationPreferences({ data: form });
      setWarn(false);
      setMessage("Preferences saved. Email and SMS are not being sent.");
      await reload();
    } catch (err) {
      setWarn(true);
      setMessage(err instanceof Error ? err.message : "Could not save preferences.");
    } finally {
      setBusy(false);
    }
  }

  if (loading || !form) return <p className="text-muted">Loading notification settings…</p>;
  if (error) return <Notice tone="warn">{error}</Notice>;

  const rows: { key: keyof NotificationInput; label: string; detail: string }[] = [
    { key: "followUpReminders", label: "In-app follow-up reminders", detail: "Saved for your account. The Follow-ups page still lists due items. No email or SMS is sent." },
    { key: "productUpdates", label: "Product updates", detail: "Preference only. Product email is not being sent." },
    { key: "subscriptionNotices", label: "Subscription notifications", detail: "Preference only. Billing email is not being sent because payments are not active." },
    { key: "marketing", label: "Optional marketing", detail: "Off until you turn it on. Marketing email is not being sent." },
  ];

  return (
    <form className="grid gap-4" onSubmit={(event) => void save(event)}>
      <div>
        <h1 className="font-display text-3xl">Notifications</h1>
        <p className="mt-1 text-sm text-muted">These are preferences. They do not mean a message was delivered.</p>
      </div>
      {message ? <Notice tone={warn ? "warn" : "info"}>{message}</Notice> : null}
      <section className="card grid gap-3 p-5">
        <p className="text-sm">Account security messages stay required. There is no switch to turn those off, and they are not being emailed until mail delivery is configured.</p>
        {rows.map((row) => (
          <label key={row.key} className="grid gap-1 rounded-2xl border border-line px-3 py-3 text-sm">
            <span className="flex items-center gap-3 font-medium">
              <input type="checkbox" className="size-4 accent-[var(--color-accent)]" checked={form[row.key]} onChange={(event) => setForm({ ...form, [row.key]: event.target.checked })} />
              {row.label}
            </span>
            <span className="text-muted">{row.detail}</span>
          </label>
        ))}
        <button className="btn btn-primary w-fit" type="submit" disabled={busy}>{busy ? "Saving…" : "Save preferences"}</button>
      </section>
    </form>
  );
}

export function SubscriptionScreen() {
  const { summary, error, loading } = useSummary();
  if (loading) return <p className="text-muted">Loading subscription…</p>;
  if (error || !summary) return <Notice tone="warn">{error ?? "Could not load subscription."}</Notice>;
  const sub = summary.subscription;
  return (
    <div className="grid gap-4">
      <div>
        <h1 className="font-display text-3xl">My Subscription</h1>
        <p className="mt-1 text-sm text-muted">One proposed plan. Nothing on this page charges a card or grants paid access.</p>
      </div>
      <article className="card max-w-xl p-6">
        <p className="pill">Not subscribed</p>
        <h2 className="mt-4 font-display text-3xl">{sub.plan}</h2>
        <p className="mt-2 font-display text-5xl tabular-nums">{foundersPriceLabel()}<span className="text-2xl text-muted">/month</span></p>
        <dl className="mt-4 grid gap-2 text-sm">
          <div className="flex justify-between gap-4"><dt className="text-muted">Status</dt><dd>Billing is not active</dd></div>
          <div className="flex justify-between gap-4"><dt className="text-muted">Next billing date</dt><dd>None</dd></div>
          <div className="flex justify-between gap-4"><dt className="text-muted">Message drafts today</dt><dd>{sub.draftsToday} of {sub.draftLimit}</dd></div>
        </dl>
        <p className="mt-4 text-sm text-muted">Stripe is not configured, so there is no upgrade button and no payment history.</p>
        <Link to="/app/billing" className="btn btn-secondary mt-4">View billing details</Link>
      </article>
    </div>
  );
}

export function PrivacyScreen() {
  const { summary, error, loading, reload } = useSummary();
  const [password, setPassword] = useState("");
  const [shown, setShown] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [warn, setWarn] = useState(false);
  const [busy, setBusy] = useState(false);

  async function download() {
    setBusy(true);
    try {
      const data = await exportAccountData();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "bookbloom-account.json";
      link.click();
      URL.revokeObjectURL(url);
      setWarn(false);
      setMessage("A copy of your account data was downloaded. It does not include your password.");
    } catch (err) {
      setWarn(true);
      setMessage(err instanceof Error ? err.message : "Could not export your account.");
    } finally {
      setBusy(false);
    }
  }

  async function requestDelete(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    try {
      await requestAccountDeletion({ data: { currentPassword: password } });
      setPassword("");
      setWarn(false);
      setMessage("Deletion was requested. Your business records were not erased.");
      await reload();
    } catch (err) {
      setWarn(true);
      setMessage(err instanceof Error ? err.message : "Deletion was not requested.");
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <p className="text-muted">Loading account management…</p>;
  if (error || !summary) return <Notice tone="warn">{error ?? "Could not load account management."}</Notice>;

  return (
    <div className="grid gap-4">
      <div>
        <h1 className="font-display text-3xl">Account Management</h1>
        <p className="mt-1 text-sm text-muted">You can export or request deletion only for the account you are signed in to.</p>
      </div>
      {message ? <Notice tone={warn ? "warn" : "info"}>{message}</Notice> : null}
      {summary.deletionRequestedAt ? <Notice>A deletion request is already on file from {new Date(summary.deletionRequestedAt).toLocaleString()}. Records have not been erased.</Notice> : null}
      <section className="card grid gap-3 p-5">
        <h2 className="font-display text-xl">Download your information</h2>
        <p className="text-sm text-muted">Includes your profile, business settings, leads, estimates, and follow-ups. Passwords are not included.</p>
        <button type="button" className="btn btn-secondary w-fit" disabled={busy} onClick={() => void download()}>Download account copy</button>
      </section>
      <section className="card grid gap-3 p-5">
        <h2 className="font-display text-xl">Request deletion</h2>
        <p className="text-sm text-muted">Requesting deletion does not immediately erase leads, estimates, or follow-ups. Billing is not active, so there is no subscription to cancel. Another customer's account cannot be deleted from here.</p>
        {summary.hasPassword ? (
          <form className="grid gap-3" onSubmit={(event) => void requestDelete(event)}>
            <PasswordField label="Current password" value={password} onChange={setPassword} autoComplete="current-password" shown={shown} onToggle={() => setShown((value) => !value)} />
            <button className="btn btn-warn w-fit" type="submit" disabled={busy}>{busy ? "Requesting…" : "Request account deletion"}</button>
          </form>
        ) : (
          <p className="text-sm text-muted">This account has no password to confirm a deletion request. Nothing was deleted.</p>
        )}
      </section>
    </div>
  );
}

export function HelpScreen() {
  return (
    <div className="grid gap-4">
      <div>
        <h1 className="font-display text-3xl">Help & Support</h1>
        <p className="mt-1 text-sm text-muted">Support email and live chat are not connected. This page does not open a ticket.</p>
      </div>
      <section className="card grid gap-2 p-5 text-sm">
        <p>Use the workspace to manage leads, estimates, and drafts. Drafts are not sent for you.</p>
        <p>Personal account settings are separate from business rates.</p>
        <p><Link to="/terms" className="text-accent">Terms of Service</Link> · <Link to="/privacy" className="text-accent">Privacy Policy</Link></p>
      </section>
    </div>
  );
}

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Could not read that photo."));
    reader.readAsDataURL(file);
  });
}
