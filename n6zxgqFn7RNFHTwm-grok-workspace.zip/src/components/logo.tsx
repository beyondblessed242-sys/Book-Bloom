import { Link } from "@tanstack/react-router";

export function Logo({ to = "/" }: { to?: "/" | "/app" | "/demo" }) {
  return (
    <Link to={to} className="inline-flex items-center gap-2.5 no-underline">
      <svg viewBox="0 0 32 32" className="size-8" aria-hidden="true">
        <rect width="32" height="32" rx="10" className="fill-accent" />
        <path
          d="M16 6.5c1.8 2.6 2.2 4.6.2 7.2-2.2-2.4-2.6-4.4-.2-7.2zm0 11.6c1.8 2.6 2.2 4.6.2 7.2-2.2-2.4-2.6-4.4-.2-7.2zM6.5 16c2.6-1.8 4.6-2.2 7.2-.2-2.4 2.2-4.4 2.6-7.2.2zm11.8 0c2.6-1.8 4.6-2.2 7.2-.2-2.4 2.2-4.4 2.6-7.2.2z"
          className="fill-bg"
        />
      </svg>
      <span className="font-display text-xl tracking-tight text-ink">
        BookBloom <span className="text-accent">AI</span>
      </span>
    </Link>
  );
}
