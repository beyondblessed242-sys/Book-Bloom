import type { ReactNode } from "react";
import { Field } from "@/components/field";

export function PasswordField({
  label,
  value,
  onChange,
  autoComplete,
  shown,
  onToggle,
  error,
  hint,
  action,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  autoComplete: "new-password" | "current-password";
  shown: boolean;
  onToggle: () => void;
  error?: string;
  hint?: string;
  action?: ReactNode;
}) {
  return (
    <Field label={label} hint={hint} error={error} action={action}>
      <span className="password-field">
        <input
          className="field-input"
          type={shown ? "text" : "password"}
          autoComplete={autoComplete}
          required
          value={value}
          aria-invalid={error ? true : undefined}
          onChange={(event) => onChange(event.target.value)}
        />
        <button type="button" className="password-toggle" aria-pressed={shown} onClick={onToggle}>
          {shown ? "Hide" : "Show"}
        </button>
      </span>
    </Field>
  );
}
