import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { CalendarClock, Calculator, Check, ChevronDown, MessageSquareText, ReceiptText, Sparkles, Store, Users } from "lucide-react";
import { SiteHeader } from "@/components/site-header";
import { formatMoney } from "@/lib/money";
import { foundersPriceLabel, SUBSCRIPTION_BILLING_LIVE } from "@/lib/pricing";
import { calculateQuote, explainQuote } from "@/lib/quotes";
import { DEFAULT_EXTRAS, DEFAULT_SERVICES, FREQUENCIES, type FrequencyId, type QuoteBreakdown } from "@/lib/types";

const FRIDGE = DEFAULT_EXTRAS.find((item) => item.id === "fridge");

const FEATURES = [
  {
    title: "Lead Management",
    body: "Keep customer inquiries, contact details, and booking opportunities organized in one place.",
    icon: Users,
  },
  {
    title: "Smart Estimates",
    body: "Create professional cleaning estimates using your own services, rates, and add-ons.",
    icon: ReceiptText,
  },
  {
    title: "Follow-Up Tracker",
    body: "See which clients need a response so promising inquiries don't get overlooked.",
    icon: CalendarClock,
  },
  {
    title: "AI Message Assistant",
    body: "Prepare polished, personalized replies and follow-ups in your business's voice.",
    icon: MessageSquareText,
  },
];

const STEPS = [
  {
    n: "01",
    title: "Set Up Your Business",
    body: "Add your services, pricing, and business details so BookBloom can personalize your experience.",
    icon: Store,
  },
  {
    n: "02",
    title: "Create Smart Estimates",
    body: "Turn customer inquiries into professional cleaning estimates using your own rates and services.",
    icon: Calculator,
  },
  {
    n: "03",
    title: "Let AI Do the Writing",
    body: "Generate personalized customer replies and follow-up messages in seconds, ready for your review and approval.",
    icon: Sparkles,
  },
];

const PLAN_FEATURES = [
  "Organized customer leads and inquiries",
  "Professional estimates using your rates",
  "AI-generated customer response drafts",
  "Follow-up reminders and tracking",
  "Personalized business profile",
  "Access to all currently available core dashboard features",
];

const FAQS = [
  {
    q: "What is BookBloom AI?",
    a: "BookBloom is an AI-powered workspace for cleaning businesses. It helps you organize leads, prepare professional estimates, create customer message drafts, and keep track of follow-ups.",
  },
  {
    q: "Do I need technical experience to use BookBloom?",
    a: "No. BookBloom is designed to be simple and easy to use, even if you're new to AI tools.",
  },
  {
    q: "How does BookBloom create cleaning estimates?",
    a: "You enter your services, rates, and available extras. BookBloom calculates estimates based on those saved prices, and you can review the results before sharing them with customers.",
  },
  {
    q: "Does BookBloom automatically contact customers?",
    a: "Not yet. BookBloom prepares customer replies and follow-up messages for you to review, copy, and send. Automated messaging is a feature being considered for a future release.",
  },
  {
    q: "Can I customize the AI messages?",
    a: "Yes. You can set your business's preferred communication style and edit generated drafts before sending them.",
  },
  {
    q: "How much does BookBloom cost?",
    a: `The proposed Founder's Plan is ${foundersPriceLabel()} per month. Subscriptions are not yet active, and joining early access does not initiate a charge.`,
  },
  {
    q: "Is my business information private?",
    a: "BookBloom is designed to separate business workspaces and restrict access to authorized users. These privacy and access controls must be tested before accepting real customer information.",
  },
  {
    q: "Can I try BookBloom before subscribing?",
    a: "Yes. Explore the free demo to see the available features using sample business information.",
  },
];

export function HomePage() {
  return (
    <div>
      <SiteHeader />
      <main>
        <section className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-14 md:grid-cols-2 md:py-20">
          <div>
            <p className="text-xs font-medium tracking-[0.14em] text-accent sm:text-sm">YOUR AI-POWERED CLEANING BUSINESS ASSISTANT</p>
            <h1 className="mt-3 font-display text-5xl leading-[1.05] text-ink md:text-6xl">More bookings. Less busywork.</h1>
            <p className="mt-5 max-w-xl text-lg text-muted">
              Manage leads, create accurate estimates, and prepare professional customer follow-ups with one simple AI-powered workspace. Spend less time on admin and more time growing your cleaning business.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/demo" className="btn btn-primary">Try Free Demo</Link>
              <a href="#pricing" className="btn btn-secondary">View Pricing</a>
            </div>
          </div>
          <EstimatePreview />
        </section>

        <section id="product" className="mx-auto max-w-6xl scroll-mt-20 px-4 py-16 md:py-20">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="font-display text-4xl leading-tight md:text-5xl">Meet Your New AI Business Assistant</h2>
              <p className="mt-4 text-lg text-muted">Less time managing paperwork and messages. More time focusing on your customers.</p>
            </div>
            <ul className="mt-12 grid gap-4 md:grid-cols-2 md:gap-5">
              {FEATURES.map((feature) => {
                const Icon = feature.icon;
                return (
                  <li key={feature.title} className="feature-card card p-6 sm:p-7">
                    <span className="grid size-11 place-items-center rounded-2xl bg-accent-soft text-accent">
                      <Icon className="size-5" strokeWidth={1.75} aria-hidden="true" />
                    </span>
                    <h3 className="mt-5 text-lg font-medium">{feature.title}</h3>
                    <p className="mt-2 max-w-md text-sm leading-relaxed text-muted">{feature.body}</p>
                  </li>
                );
              })}
            </ul>
        </section>

        <section id="how" className="mx-auto max-w-6xl scroll-mt-20 px-4 py-16 md:py-20">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="font-display text-4xl leading-tight md:text-5xl">How BookBloom Works</h2>
            <p className="mt-4 text-lg text-muted">
              Running your cleaning business just got easier. Get organized, create estimates, and prepare customer messages in three simple steps.
            </p>
          </div>
          <ol className="mt-12 grid items-stretch gap-4 md:grid-cols-3 md:gap-5">
            {STEPS.map((step) => {
              const Icon = step.icon;
              return (
                <li key={step.n} className="feature-card card flex h-full flex-col p-6 sm:p-7">
                  <span className="grid size-11 place-items-center rounded-2xl bg-accent-soft text-accent">
                    <Icon className="size-5" strokeWidth={1.75} aria-hidden="true" />
                  </span>
                  <p className="mt-5 font-display text-2xl text-accent">{step.n}</p>
                  <h3 className="mt-2 text-lg font-medium">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{step.body}</p>
                </li>
              );
            })}
          </ol>
        </section>

        <section id="pricing" className="mx-auto max-w-6xl scroll-mt-20 px-4 py-16 md:py-20">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-xs font-medium tracking-[0.14em] text-accent sm:text-sm">SIMPLE, TRANSPARENT PRICING</p>
            <h2 className="mt-3 font-display text-4xl leading-tight md:text-5xl">A Smarter Way to Run Your Cleaning Business</h2>
            <p className="mt-4 text-lg text-muted">Everything you need to stay organized, impress potential customers, and keep your business moving.</p>
          </div>
          <article className="feature-card card mx-auto mt-12 max-w-lg p-6 sm:p-8">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <h3 className="font-display text-3xl">Founder's Plan</h3>
              <p className="pill">Early Access</p>
            </div>
            <p className="mt-5 font-display text-5xl tabular-nums">
              {foundersPriceLabel()}
              <span className="text-2xl text-muted">/month</span>
            </p>
            <p className="mt-3 text-sm leading-relaxed text-muted">One simple workspace to manage customers, estimates, and AI-powered communication.</p>
            <ul className="mt-6 grid gap-3">
              {PLAN_FEATURES.map((feature) => (
                <li key={feature} className="flex items-start gap-3 text-sm">
                  <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-accent-soft text-accent">
                    <Check className="size-3.5" strokeWidth={2.5} aria-hidden="true" />
                  </span>
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            <Link to="/login" search={{ next: "/app/billing", mode: "create" }} className="btn btn-primary mt-8 w-full">
              {SUBSCRIPTION_BILLING_LIVE ? "Get Started" : "Join Early Access"}
            </Link>
            <p className="mt-3 text-center text-sm text-muted">Early access — subscription payments are not yet enabled.</p>
          </article>
        </section>

        <section id="faq" className="mx-auto max-w-3xl scroll-mt-20 px-4 py-16 md:py-20">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-xs font-medium tracking-[0.14em] text-accent sm:text-sm">FREQUENTLY ASKED QUESTIONS</p>
            <h2 className="mt-3 font-display text-4xl leading-tight md:text-5xl">Questions? We've Got Answers.</h2>
            <p className="mt-4 text-lg text-muted">Everything you need to know about making BookBloom part of your cleaning business.</p>
          </div>
          <FaqList />
        </section>

        <section className="mx-auto max-w-3xl px-4 pb-20 text-center">
          <h2 className="font-display text-4xl leading-tight md:text-5xl">Ready to simplify your business?</h2>
          <p className="mx-auto mt-4 max-w-xl text-lg text-muted">Spend less time managing the details and more time growing your business.</p>
          <Link to="/demo" className="btn btn-primary mt-8">Try Free Demo</Link>
        </section>
      </main>
      <footer className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-8 text-sm text-muted">
          <p>BookBloom AI · a workspace for cleaning businesses.</p>
          <span className="flex gap-4">
            <Link to="/terms">Terms</Link>
            <Link to="/privacy">Privacy</Link>
          </span>
        </div>
      </footer>
    </div>
  );
}

function FaqList() {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <div className="mt-10 grid gap-3">
      {FAQS.map((item, index) => {
        const isOpen = open === index;
        const panelId = `faq-panel-${index}`;
        return (
          <article key={item.q} className="card overflow-hidden">
            <h3>
              <button
                type="button"
                className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left text-base font-medium"
                aria-expanded={isOpen}
                aria-controls={panelId}
                onClick={() => setOpen(isOpen ? null : index)}
              >
                <span>{item.q}</span>
                <ChevronDown className={`faq-chevron size-5 shrink-0 text-accent ${isOpen ? "rotate-180" : ""}`} aria-hidden="true" />
              </button>
            </h3>
            <div id={panelId} className="faq-panel" data-open={isOpen} role="region" aria-hidden={!isOpen}>
              <div>
                <p className="px-5 pb-5 text-sm leading-relaxed text-muted">{item.a}</p>
              </div>
            </div>
          </article>
        );
      })}
    </div>
  );
}

function customerNote(quote: QuoteBreakdown): string {
  return [
    `Thank you for asking about a ${quote.serviceLabel.toLowerCase()}.`,
    explainQuote(quote),
    "This sample quote uses illustrative demo rates. Nothing has been booked or billed.",
  ].join(" ");
}

function quoteDocument(quote: QuoteBreakdown, note: string): string {
  const lines = [
    "BookBloom AI — sample customer quote",
    "Illustrative demo pricing. Not an invoice. Not billed.",
    "",
    `Service: ${quote.serviceLabel}`,
    `Frequency: ${quote.frequencyLabel}`,
    `Rooms: ${quote.rooms}`,
    `Base: ${formatMoney(quote.baseCents)}`,
  ];
  if (quote.rooms > 0) {
    lines.push(`Rooms: ${quote.rooms} × ${formatMoney(quote.perRoomCents)} = ${formatMoney(quote.roomsCents)}`);
  }
  if (quote.sqft > 0) {
    lines.push(`Square feet: ${quote.sqft.toLocaleString("en-US")} × ${formatMoney(quote.perSqftCents)} = ${formatMoney(quote.sqftCents)}`);
  }
  if (quote.multiplierBps !== 10000) {
    lines.push(`Cleaning portion after frequency: ${formatMoney(quote.frequencyCents)}`);
  }
  for (const extra of quote.extras) lines.push(`${extra.name}: ${formatMoney(extra.cents)}`);
  lines.push("", `Total: ${formatMoney(quote.totalCents)}`, "", note.trim());
  return lines.join("\n");
}

function EstimatePreview() {
  const [serviceId, setServiceId] = useState("standard");
  const [rooms, setRooms] = useState(3);
  const [frequency, setFrequency] = useState<FrequencyId>("biweekly");
  const [fridge, setFridge] = useState(false);
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [note, setNote] = useState("");
  const [noteEdited, setNoteEdited] = useState(false);
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState<string | null>(null);
  const quote = useMemo(
    () =>
      calculateQuote({
        services: DEFAULT_SERVICES,
        extrasCatalog: DEFAULT_EXTRAS,
        serviceId,
        rooms,
        sqft: 0,
        frequency,
        extraIds: fridge && FRIDGE ? [FRIDGE.id] : [],
        adjustmentCents: 0,
      }),
    [serviceId, rooms, frequency, fridge],
  );
  const seededNote = useMemo(() => customerNote(quote), [quote]);

  useEffect(() => {
    if (quoteOpen && !noteEdited) setNote(seededNote);
  }, [quoteOpen, noteEdited, seededNote]);

  function generateQuote() {
    setQuoteOpen(true);
    setCopied(false);
    setCopyError(null);
    if (!noteEdited) setNote(seededNote);
    window.setTimeout(() => {
      document.getElementById("sample-quote")?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }, 40);
  }

  async function copyQuote() {
    setCopyError(null);
    try {
      await navigator.clipboard.writeText(quoteDocument(quote, note));
      setCopied(true);
    } catch {
      setCopied(false);
      setCopyError("Clipboard is unavailable. Select the note and copy it yourself. Nothing was sent.");
    }
  }

  return (
    <div className="card p-5 sm:p-6">
      <p className="pill">Illustrative demo</p>
      <h2 className="mt-3 font-display text-3xl leading-tight">Create an Estimate in Seconds</h2>
      <p className="mt-2 text-sm text-muted">See how BookBloom turns your service rates into clear, professional estimates.</p>
      <p className="mt-5 text-xs font-medium tracking-wide text-accent">Sample rate card · not your prices and not a live invoice</p>
      <p className="mt-2 font-display text-4xl tabular-nums">{formatMoney(quote.totalCents)}</p>
      <p className="mt-1 text-sm text-muted">{quote.serviceLabel} · {quote.frequencyLabel}</p>
      <div className="mt-5 grid gap-3">
        <label className="grid gap-1 text-sm">
          Service
          <select className="field-input" value={serviceId} onChange={(event) => setServiceId(event.target.value)}>
            {DEFAULT_SERVICES.map((service) => (
              <option key={service.id} value={service.id}>{service.label}</option>
            ))}
          </select>
        </label>
        <div className="flex items-center justify-between gap-3">
          <span className="text-sm">Rooms</span>
          <span className="flex items-center gap-2">
            <button type="button" className="btn btn-secondary" onClick={() => setRooms((value) => Math.max(0, value - 1))} aria-label="Fewer rooms">−</button>
            <span className="w-6 text-center tabular-nums">{rooms}</span>
            <button type="button" className="btn btn-secondary" onClick={() => setRooms((value) => Math.min(12, value + 1))} aria-label="More rooms">+</button>
          </span>
        </div>
        <label className="grid gap-1 text-sm">
          Frequency
          <select className="field-input" value={frequency} onChange={(event) => setFrequency(event.target.value as FrequencyId)}>
            {FREQUENCIES.map((item) => (
              <option key={item.id} value={item.id}>{item.label}</option>
            ))}
          </select>
        </label>
        {FRIDGE ? (
          <button
            type="button"
            className={fridge ? "btn btn-primary" : "btn btn-secondary"}
            aria-pressed={fridge}
            onClick={() => setFridge((value) => !value)}
          >
            {`${fridge ? "Added" : "Add"} ${FRIDGE.name} · ${formatMoney(FRIDGE.cents)}`}
          </button>
        ) : null}
      </div>
      <button type="button" className="btn btn-primary mt-5 w-full" onClick={generateQuote}>
        Generate Customer Quote
      </button>
      <p className="mt-3 text-xs text-muted">The total updates from the sample rate card. Weekly and biweekly rates discount the cleaning portion only. Add-ons stay full price.</p>
      {quoteOpen ? (
        <article id="sample-quote" className="rise-in mt-5 rounded-2xl border border-line bg-bg p-4" aria-live="polite">
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div>
              <p className="text-xs font-medium tracking-wide text-accent">Demo quote · illustrative pricing</p>
              <h3 className="mt-1 font-display text-2xl">Customer quote</h3>
            </div>
            <p className="font-display text-3xl tabular-nums">{formatMoney(quote.totalCents)}</p>
          </div>
          <dl className="mt-4 grid gap-2 text-sm">
            <QuoteLine label="Service" value={quote.serviceLabel} />
            <QuoteLine label="Frequency" value={quote.frequencyLabel} />
            <QuoteLine label="Base" value={formatMoney(quote.baseCents)} />
            {quote.rooms > 0 ? (
              <QuoteLine label="Rooms" value={`${quote.rooms} × ${formatMoney(quote.perRoomCents)} = ${formatMoney(quote.roomsCents)}`} />
            ) : null}
            {quote.multiplierBps !== 10000 ? (
              <QuoteLine label="After frequency" value={formatMoney(quote.frequencyCents)} />
            ) : null}
            {quote.extras.map((extra) => (
              <QuoteLine key={extra.id} label={extra.name} value={formatMoney(extra.cents)} />
            ))}
            <QuoteLine label="Total" value={formatMoney(quote.totalCents)} />
          </dl>
          <label className="mt-4 grid gap-1 text-sm">
            Quote note
            <textarea
              className="field-input"
              value={note}
              onChange={(event) => {
                setNote(event.target.value);
                setNoteEdited(true);
                setCopied(false);
              }}
              aria-describedby="quote-note-hint"
            />
          </label>
          <p id="quote-note-hint" className="mt-2 text-xs text-muted">
            {noteEdited
              ? "The total still comes from the calculator. Your note stays as you edited it."
              : "The note follows the calculator. Edit it if you want different wording. The price does not change when you edit the words."}
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <button type="button" className="btn btn-secondary" onClick={() => void copyQuote()}>
              {copied ? "Copied" : "Copy quote"}
            </button>
            {noteEdited ? (
              <button
                type="button"
                className="btn btn-ghost"
                onClick={() => {
                  setNoteEdited(false);
                  setNote(seededNote);
                  setCopied(false);
                }}
              >
                Refresh note from total
              </button>
            ) : null}
          </div>
          {copyError ? <p className="mt-2 text-sm text-warn" role="alert">{copyError}</p> : null}
          <p className="mt-3 text-xs text-muted">Demo mode. This quote is not saved, not emailed, and not a paid booking.</p>
        </article>
      ) : null}
    </div>
  );
}

function QuoteLine({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-line pb-2">
      <dt className="text-muted">{label}</dt>
      <dd className="text-right font-medium tabular-nums">{value}</dd>
    </div>
  );
}
