-- Bind an admin authenticator proof to one session. A new sign-in must pass MFA again.
alter table admin_mfa_proofs add column if not exists session_key text;
