-- Personal account settings. Separate from the business workspace.
-- The server only reads and writes the signed-in user id. There is no role column.

create table if not exists account_profiles (
  user_id      text primary key,
  first_name   text not null default '',
  last_name    text not null default '',
  display_name text not null default '',
  phone        text not null default '',
  timezone     text not null default 'America/New_York',
  language     text not null default 'en',
  photo_mime   text,
  photo_bytes  bytea,
  updated_at   timestamptz not null default now()
);

create table if not exists notification_preferences (
  user_id               text primary key,
  follow_up_reminders   boolean not null default true,
  product_updates       boolean not null default false,
  subscription_notices  boolean not null default true,
  marketing             boolean not null default false,
  updated_at            timestamptz not null default now()
);

create table if not exists account_deletion_requests (
  id           text primary key,
  user_id      text not null,
  requested_at timestamptz not null default now(),
  status       text not null default 'requested' check (status in ('requested', 'cancelled'))
);

create index if not exists account_deletion_user_idx on account_deletion_requests (user_id, requested_at desc);

-- Role assignments are server-written only. This migration does not insert any administrator.
create table if not exists admin_role_assignments (
  user_id    text primary key,
  role       text not null check (role = 'super_admin'),
  created_at timestamptz not null default now()
);

alter table account_profiles enable row level security;
alter table notification_preferences enable row level security;
alter table account_deletion_requests enable row level security;
alter table admin_role_assignments enable row level security;

drop policy if exists account_profiles_tenant on account_profiles;
create policy account_profiles_tenant on account_profiles
  using (user_id = current_setting('app.user_id', true))
  with check (user_id = current_setting('app.user_id', true));

drop policy if exists notification_preferences_tenant on notification_preferences;
create policy notification_preferences_tenant on notification_preferences
  using (user_id = current_setting('app.user_id', true))
  with check (user_id = current_setting('app.user_id', true));

drop policy if exists account_deletion_tenant on account_deletion_requests;
create policy account_deletion_tenant on account_deletion_requests
  using (user_id = current_setting('app.user_id', true))
  with check (user_id = current_setting('app.user_id', true));

drop policy if exists admin_role_read_own on admin_role_assignments;
create policy admin_role_read_own on admin_role_assignments
  using (user_id = current_setting('app.user_id', true));
