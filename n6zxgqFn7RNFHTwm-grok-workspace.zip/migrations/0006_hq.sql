-- BookBloom HQ records. This file does not assign an owner.

alter table admin_role_assignments drop constraint if exists admin_role_assignments_role_check;
alter table admin_role_assignments
  add constraint admin_role_assignments_role_check
  check (role in ('super_admin', 'platform_owner'));

create table if not exists hq_cases (
  id          text primary key,
  user_id     text,
  subject     text not null,
  category    text not null check (category in ('billing', 'access', 'product', 'other')),
  priority    text not null check (priority in ('low', 'normal', 'high')),
  status      text not null check (status in ('open', 'waiting', 'resolved')),
  notes       text not null default '',
  resolution  text not null default '',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists hq_settings (
  key         text primary key,
  value       text not null,
  updated_at  timestamptz not null default now()
);

create table if not exists hq_audit_log (
  id            text primary key,
  actor_user_id text not null,
  action        text not null,
  target        text not null default '',
  created_at    timestamptz not null default now()
);

alter table hq_cases enable row level security;
alter table hq_settings enable row level security;
alter table hq_audit_log enable row level security;
