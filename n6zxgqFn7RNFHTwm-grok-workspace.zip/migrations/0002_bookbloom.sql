-- BookBloom AI tenant schema.
-- One business workspace per signed-in user. Every user-owned table has user_id.
--
-- Row Level Security policies are created for a future restricted DB role.
-- The app connection is the database owner, which bypasses RLS unless it is
-- forced — and forcing it breaks pooled connections that cannot keep a session
-- variable. Isolation that actually runs is therefore the server function
-- layer: authMiddleware supplies the verified user id, and every statement
-- filters on user_id. Do not query these tables without that predicate.

create table if not exists businesses (
  id            text primary key,
  user_id       text not null unique,
  company_name  text not null default '',
  owner_name    text not null default '',
  email         text not null default '',
  phone         text not null default '',
  service_area  text not null default '',
  hours         text not null default '',
  tone          text not null default 'warm' check (tone in ('warm', 'professional', 'concise')),
  services      jsonb not null default '[]'::jsonb,
  extras        jsonb not null default '[]'::jsonb,
  sample_loaded boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists leads (
  id            text primary key,
  user_id       text not null,
  name          text not null,
  email         text not null default '',
  phone         text not null default '',
  service_id    text not null,
  service_label text not null,
  rooms         integer check (rooms is null or (rooms >= 0 and rooms <= 40)),
  sqft          integer check (sqft is null or (sqft >= 0 and sqft <= 20000)),
  frequency     text not null check (frequency in ('one-time', 'weekly', 'biweekly', 'monthly')),
  notes         text not null default '',
  status        text not null default 'new' check (status in ('new', 'contacted', 'quoted', 'booked', 'lost')),
  last_contact  date,
  is_sample     boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index if not exists leads_user_idx on leads (user_id, updated_at desc);

create table if not exists quotes (
  id           text primary key,
  user_id      text not null,
  lead_id      text references leads (id) on delete set null,
  breakdown    jsonb not null,
  total_cents  integer not null,
  explanation  text not null default '',
  status       text not null default 'draft' check (status in ('draft', 'approved', 'sent')),
  is_sample    boolean not null default false,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create index if not exists quotes_user_idx on quotes (user_id, updated_at desc);

create table if not exists follow_ups (
  id         text primary key,
  user_id    text not null,
  lead_id    text references leads (id) on delete cascade,
  title      text not null,
  due_date   date not null,
  notes      text not null default '',
  done       boolean not null default false,
  is_sample  boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists follow_ups_user_due_idx on follow_ups (user_id, due_date);

create table if not exists ai_usage (
  id            text primary key,
  user_id       text not null,
  feature       text not null,
  mode          text not null,
  input_chars   integer not null,
  output_chars  integer not null,
  created_at    timestamptz not null default now()
);

create index if not exists ai_usage_user_time_idx on ai_usage (user_id, created_at desc);

-- Policies exist so a non-owner role can be locked to one tenant later.
-- current_setting(..., true) returns '' when the variable is missing, which
-- matches nothing. The table owner still bypasses these policies.

alter table businesses enable row level security;
alter table leads enable row level security;
alter table quotes enable row level security;
alter table follow_ups enable row level security;
alter table ai_usage enable row level security;

drop policy if exists businesses_tenant on businesses;
create policy businesses_tenant on businesses
  using (user_id = current_setting('app.user_id', true))
  with check (user_id = current_setting('app.user_id', true));

drop policy if exists leads_tenant on leads;
create policy leads_tenant on leads
  using (user_id = current_setting('app.user_id', true))
  with check (user_id = current_setting('app.user_id', true));

drop policy if exists quotes_tenant on quotes;
create policy quotes_tenant on quotes
  using (user_id = current_setting('app.user_id', true))
  with check (user_id = current_setting('app.user_id', true));

drop policy if exists follow_ups_tenant on follow_ups;
create policy follow_ups_tenant on follow_ups
  using (user_id = current_setting('app.user_id', true))
  with check (user_id = current_setting('app.user_id', true));

drop policy if exists ai_usage_tenant on ai_usage;
create policy ai_usage_tenant on ai_usage
  using (user_id = current_setting('app.user_id', true))
  with check (user_id = current_setting('app.user_id', true));
