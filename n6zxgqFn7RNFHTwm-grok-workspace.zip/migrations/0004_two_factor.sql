-- Authenticator MFA. No administrator rows are inserted.

alter table "user" add column if not exists "twoFactorEnabled" boolean not null default false;

create table if not exists "twoFactor" (
  "id" text not null primary key,
  "secret" text not null,
  "backupCodes" text not null,
  "userId" text not null references "user" ("id") on delete cascade,
  "verified" boolean not null default false,
  "failedVerificationCount" integer not null default 0,
  "lockedUntil" timestamptz
);

create index if not exists "twoFactor_userId_idx" on "twoFactor" ("userId");

-- Short-lived proof that this user completed an authenticator challenge.
-- It does not grant a role. There is no client write policy.
create table if not exists admin_mfa_proofs (
  user_id text primary key,
  expires_at timestamptz not null
);

alter table admin_mfa_proofs enable row level security;
